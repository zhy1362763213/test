local skynet = require "skynet"
local queue = require "skynet.queue"
local redishelper = require "redishelper"
local keysutils   = require "keysutils"
local dateutils   = require "dateutils"
local utils       = require "utils"
local redis       = require 'skynet.db.redis'
local mongo       = require 'skynet.db.mongo'
local settings    = require "settings"
local clublogic   = require "clublogic"

local skynet_node_name = ...
require "skynet.manager"
require "functions"

local CMD = {}

local db = {}
local rediscli = {}

local clubs = {}
local users = {}

local luaqueue = queue()


local function getServer(cluid)
    local club = clubs[cluid]
    local serverid = club.serverid
    return utils.getserver(serverid)
end

local function loadallclub()
    local page = 1
    while true do
        local s = (page - 1) * 100
        local ret = db[settings.club_mongodb_key.cname]:find():sort({ id = 1 }):skip(s):limit(100)
        if not ret:hasNext() then
            break
        end
        while ret:hasNext() do
            local club = ret:next()
            club._id = nil
            clubs[club.id] = club
            local ret1 = db[settings.club_member_mongodb_key.cname]:find({clubid = club.id}):sort({ id = 1 })
            while ret1:hasNext() do
                local member = ret1:next()
                member._id = nil
                users[member.uid] = member
            end
        end
        page = page + 1
    end
end

function CMD.create(clubid, club)
    local c = clubs[clubid]
    assert(c == nil, "create club error clubid = "..clubid)
    clubs[clubid] = club
    return "ok"
end


function CMD.save(clubid, club)
    local c = clubs[clubid]
    assert(c ~= nil, "club not found clubid = "..clubid)
    for k,v in pairs(club) do
        c[k] = v
    end
    local ok = db[settings.club_mongodb_key.cname]:update({["$set"]=club}, {id=clubid}, true)
    return "ok"
end


function CMD.saveuser(uid, user)
    local u = users[uid]
    assert(u == nil, "saveuser error uid = "..uid)
    users[uid] = user
    return "ok"
end



function CMD.incrclubexp(clubid)
    local club = clubs[clubid]
    assert(club~=nil, "俱乐部不存在")
    club.exp = club.exp + 30
    local lv = club.lv
    local cnf = clublogic.getconfbylv(lv)
    if club.exp >= cnf.exp then
        club.lv = club.lv + 1
        club.exp = math.max(0, club.exp-cnf.exp)
        local ok = db[settings.club_mongodb_key.cname]:update({["$set"]={exp=club.exp, lv=club.lv}}, {id=clubid}, true)
    else
        local ok = db[settings.club_mongodb_key.cname]:update({["$inc"]={exp=30}}, {id=clubid}, true)
    end
    return "ok"
end

--bossid 加1
function CMD.incrbossid(clubid)
    local club = clubs[clubid]
    assert(club~=nil, "俱乐部不存在")
    club.bossid = clubid.bossid + 1
    skynet.fork(function()
        local ok = db[settings.club_mongodb_key.cname]:upsert({["$inc"]={bossid=1}}, {id=clubid}, true)
        DEBUG("incrbossid upsert ok = ", ok)
    end)
    return "ok"
end


--加载俱乐部信息
function CMD.loadclubinfo(uid)
    local user = users[uid]
    if not user then
        return nil
    end
    local clubid = user.clubid
    local club = clubs[clubid]
    local cnf = clublogic.getconfbylv(club.lv)
    club.size = cnf.size
    club.max_exp = cnf.exp
    return club
end

function CMD.loadclubbyclubid(clubid)
    local club = clubs[clubid]
    local cnf = clublogic.getconfbylv(club.lv)
    club.size = cnf.size
    club.max_exp = cnf.exp
    return club
end

local function getplayers(clubid)
    local members = {}
    for userid, v in pairs(users) do
        if v.clubid == clubid then
            table.insert(members, v.uid)
        end
    end
    return members
end

function CMD.getrank(uid, serverid)
    local ranks = {}
    for clubid, club in pairs(clubs) do
        DEBUG("getrank club = ", DUMP(club))
        if tonumber(club.serverid) == tonumber(serverid) then
            local players = getplayers(clubid)
            local ok, zhanli = pcall(skynet.call, ".usercenterd", "lua", "getzhanlitotal", players)
            if not ok then
                zhanli = 0
            end
            local cnf = clublogic.getconfbylv(club.lv)
            club.size = cnf.size
            club.member_count = #players
            club.zhanli = zhanli
            table.insert(ranks, club)
        end
    end
    if #ranks <= 0 then
        return ranks, 0
    end

    local myrank = 0
    table.sort( ranks, function(a, b) return a.zhanli > b.zhanli end)
    local user = users[uid]
    if user then
        for i,v in ipairs(ranks) do
            if v.id == user.clubid then
                myrank = i
                break
            end
        end
    end
    return table.slice(ranks, 1, 100), myrank
end

--加载签到信息
function CMD.loadsignin(uid)
    local user = users[uid]
    local clubid = user.clubid
    local k = keysutils.club_signin_key(settings.appname, clubid, dateutils.getday())
    local is_signin = rediscli:zrank(k, uid) or 0
    return is_signin
end

function CMD.loadresearch(uid)
    local user = users[uid]
    local clubid = user.clubid
    local k = keysutils.club_research_key(settings.appname, uid)
    local researchs = rediscli:zrevrange(k, 0, -1, "WITHSCORES")
    return utils.redis_pack(researchs)
end

--加载俱乐部成员
function CMD.loadclubmembernum(clubid)
    local n = 0
    for userid, v in pairs(users) do
        if v.clubid == clubid then
            n = n + 1
        end
    end
    return n
end

--获取推荐俱乐部
function CMD.loadrecomclub(server)
    local recoms = {}

    for clubid, club in pairs(clubs) do
        local myserver = getServer(cluid)
        if myserver == server then
            local cnf = clublogic.getconfbylv(club.lv)
            club.size = cnf.size
            local n = CMD.loadclubmembernum(clubid)
            if club.size > n then
                club.max_exp = cnf.exp
                table.insert(recoms, club)
            end
        end
    end
    if #recoms > 0 then
        for i=1, 7 do
            recoms = table.shuffle(recoms)
        end
        recoms = table.slice(recoms, 1, 10)
    end
    return recoms
end


--搜索俱乐部
function CMD.searchclub(server, text)
    local recoms = {}
    for clubid, club in pairs(clubs) do
        local myserver = getServer(clubid)
        if myserver == server then
            if clubid == checknumber(text) or club.name == text then
                local cnf = clublogic.getconfbylv(club.lv)
                club.size = cnf.size
                club.max_exp = cnf.exp
                table.insert(recoms, club)
            end
        end
    end
    return recoms
end

--加载俱乐部成员
function CMD.loadclubmembers(clubid)
    local members = {}
    for userid, v in pairs(users) do
        if v.clubid == clubid then
            table.insert(members, v)
        end
    end
    return members
end


function CMD.signin(clubid, uid, signin_day)
    local k = keysutils.club_signin_key(settings.appname, clubid, dateutils.getday())
    rediscli:zadd(k, signin_day, uid)
    CMD.incrclubexp(clubid)
    return "ok"
end

function CMD.getsendmailnum(clubid, uid, signin_day)
    local k = keysutils.club_sendmailnum_key(settings.appname, clubid, dateutils.getday())
    return rediscli:get(k) or 0
end

function CMD.addsendmailnum(clubid)
    local k = keysutils.club_sendmailnum_key(settings.appname, clubid, dateutils.getday())
    return rediscli:incr(k)
end


-- --科技升级
-- function CMD.researchlvup(uid, id, lv)
--     local k = keysutils.club_research_key(appname, uid)
--     return redishelper.exec("zincrby", uid, k, lv, id)
-- end

-- --科技重置
-- function CMD.reset(uid, params)
--     local data = {}
--     for k, v in pairs(params) do
--         table.insert(data, v)
--         table.insert(data, k)
--     end
--     local k = keysutils.club_research_key(settings.appname, uid)
--     return redishelper.exec("zadd", uid, k, table.unpack(data))
-- end

--给我自己发送邮件
function CMD.sendmail2user(uid, clubid, bossid)
    skynet.fork(function()
        local id = skynet.call(".id_service", "lua", "genid", "mail")
        local mail = {
            id=id,
            tp="system",
            sender="系统",
            receiver=uid,
            status=0, --未读
            title="咸神试炼击败奖励",
            content="您已在咸神试练中成功完成对BOSS的最后一击，恭喜您获得以下最后一击奖励。",
            rewards = {
                {key="juntuanbi", value=3000}
            },
            created_at=dateutils.get_datetime()
        }
        skynet.send(".maild", "lua", "sendmail", uid, mail)
    end)
    return "ok"
end

--发送邮件给排行榜
function CMD.sendmail2rank(clubid, bossid)
    skynet.fork(function()
        local k = keysutils.club_bossharmrank_key(settings.appname, clubid, bossid)
        local res = rediscli:zrevrange(k, 0, -1, "WITHSCORES")
        local ret = utils.redis_pack(res)
        local rank = 1
        for k,v in pairs(ret) do
            local uid = math.floor(k)
            local id = skynet.call(".id_service", "lua", "genid", "mail")
            local mail = {
                id=id,
                tp="system",
                sender="系统",
                receiver=uid,
                status=0, --未读
                title="咸神试炼排名奖励",
                content="咸神试练中的boss已被击败，恭喜您获得第"..rank.."名的奖励",
                rewards = {
                    {key="juntuanbi", value=1200}
                },
                created_at=dateutils.get_datetime()
            }
            rank = rank + 1
            skynet.send(".maild", "lua", "sendmail", uid, mail)
        end
    end)
    return "ok"
end

--攻打boss
function CMD.attackboss(uid, clubid, bossid, harm)
    local k = keysutils.club_bossharm_key(settings.appname, clubid, bossid)
    local hm = rediscli:get(k)
    if tonumber(hm) >= 10000 then
        return  false, "俱乐部boss已经被击败" --重复击败
    end
    local k1 = keysutils.club_bossharmrank_key(settings.appname, clubid, bossid)
    rediscli:zincrby(k1, harm, uid)
    local hm = rediscli:incr(k, harm)
    if tonumber(hm) >= 10000 then
        CMD.incrbossid(clubid) --俱乐部bossID 加1
        CMD.sendmail2user(uid, clubid, bossid)
        CMD.sendmail2rank(clubid, bossid)
        return  true, "俱乐部boss已击败" --我击败
    end
    return true, "攻打boss成功"
end

--攻打boss排行
function CMD.loadharmrank(uid, clubid)
    local club = clubs[clubid]
    local bossid = club.bossid
    local k = keysutils.club_bossharm_key(settings.appname, clubid, bossid)
    local rank = rediscli:zrank(k, uid)
    local k = keysutils.club_bossharmrank_key(settings.appname, clubid, bossid)
    local res = rediscli:zrevrange(k, 0, -1, "WITHSCORES")
    return rank, utils.redis_pack(res)
end


skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(luaqueue(f, ...))
    end)

    --链接mongo
    local mongoconf     = settings.db_cnf[skynet_node_name].mongodb_cnf
    local client = mongo.client(mongoconf)

    if not client then
        error("usercenterd mongo 数据库连接失败")
    end

    local tname = settings.mongodb_tb.game
    db = client:getDB(tname)
    if not db then
        error("mongo 连接失败")
    end

    rediscli = redis.connect(settings.db_cnf[skynet_node_name].redisdb_cnf)

    if not rediscli then
        error(" rediscli 连接失败")
    end

    skynet.fork(function()
        while true do
            if true then
                db = client:getDB(tname)
                rediscli:ping()
                skynet.sleep(1000)
            end
        end
    end)

    local server_ids = settings.nodes[skynet_node_name].server_ids
    loadallclub()
    collectgarbage()
    skynet.register('.' .. SERVICE_NAME)
end)
