local skynet     = require "skynet"
local mysql      = require "skynet.db.mysql"
local cjson      = require "cjson"
local datacenter = require "skynet.datacenter"
local mqhelper   = require "mqhelper"
local redis      = require "skynet.db.redis"
local mongo      = require "skynet.db.mongo"
local settings   = require "settings"
local utils      = require "utils"
local lordlogic     = require "lordlogic"
local herologic     = require "herologic"
local equipmentlogic= require "equipmentlogic"
local clublogic     = require "clublogic"
local artifactlogic = require "artifactlogic"
local dateutils     = require "dateutils"
local keysutils     = require "keysutils"
local yanguanconf   = require "yanguanconf"
local mongohelper   = require "mongohelper"
local skynet_node_name = ...

require "functions"
require "skynet.manager"

math.randomseed(tostring(os.time()):reverse():sub(1, 6))

local CMD = {}
local db
local rediscli

local users = {}
local heros = {}
local artifacts = {}
local bags  = {}
local saltpots = {}

local allranks = {}
local userrank = {}

local function getServer(uid)
    local user = users[uid]
    local serverid = user.serverid
    return utils.getserver(serverid)
end

local function loadalluser()
    local page = 1
    while true do
        local s = (page - 1) * 100
        local ret = db[settings.user_mongodb_key.cname]:find():sort({ uid = 1 }):skip(s):limit(100)
        if not ret:hasNext() then
            break
        end
        while ret:hasNext() do
            local u = ret:next()
            users[u.uid] = u
        end
        page = page + 1
    end
end

local function loadallhero()
    local page = 1
    while true do
        local s = (page - 1) * 50
        local ret = db[settings.hero_mongodb_key.cname]:find():sort({ uid = 1 }):skip(s):limit(50)
        if not ret:hasNext() then
            break
        end
        while ret:hasNext() do
            local r = ret:next()
            heros[r.uid] = heros[r.uid] or {}
            table.insert(heros[r.uid], r)
        end
        page = page + 1
    end
end

--加载所有鱼灵
local function loadallartifact()
    local page = 1
    while true do
        local s = (page - 1) * 100
        local ret = db[settings.artifact_mongodb_key.cname]:find():sort({ uid = 1 }):skip(s):limit(100)
        if not ret:hasNext() then
            break
        end
        while ret:hasNext() do
            local art = ret:next()
            art._id = nil
            -- DEBUG("loadallartifact art = ", cjson.encode(art))
            artifacts[art.uid] = artifacts[art.uid] or {}
            table.insert(artifacts[art.uid], art)
        end
        page = page + 1
    end
end


local function loadallbag()
    local page = 1
    while true do
        local s = (page - 1) * 100
        local ret = db[settings.bag_mongodb_key.cname]:find():sort({ uid = 1 }):skip(s):limit(100)
        if not ret:hasNext() then
            break
        end
        while ret:hasNext() do
            local u = ret:next()
            bags[u.uid] = u
        end
        page = page + 1
    end
end

local pattern = "(%d+)-(%d+)-(%d+) (%d+):(%d+):(%d+)"

function CMD.login(uid)
    local u = users[uid]
    if not u then
        local ret = db[settings.user_mongodb_key.cname]:findOne({ uid = uid })
        assert(ret ~= nil, "loaduser from mongo fail uid = "..uid)
        u = ret
        users[ret.uid] = ret
    end

    local frist_login = false
    if not u.last_login_time or u.last_login_time == "" then
        u.login_day = u.login_day or 0
        u.login_day = u.login_day + 1
        frist_login = true
    else
        local t1 = dateutils.cal_daynum_by_datetime(u.last_login_time, pattern)
        local t2 = dateutils.cal_daynum_by_datetime(dateutils.get_datetime(), pattern)
        if t1 ~= t2 then
            u.login_day = u.login_day or 0
            u.login_day = u.login_day + 1
            frist_login = true
        end
    end

    u.online_status = 1
    u.last_login_time = dateutils.get_datetime()

    local account_status = 0
    if u.account_status and u.account_status == 1 then
        if u.freeze_date and u.freeze_date ~= "" then
            if os.time() < dateutils.get_timestamp_by_datetime(u.freeze_date, pattern) then
                account_status = 1
            end
        end
    end

    local ok = mqhelper.exec("upsert", uid, settings.user_mongodb_key.tname, settings.user_mongodb_key.cname, {["$set"]=u}, {uid=uid})
    return account_status, frist_login
end


function CMD.loaduser(uid)
    local u = users[uid]
    if not u then
        local ret = db[settings.user_mongodb_key.cname]:findOne({ uid = uid })
        assert(ret ~= nil, "loaduser from mongo fail uid = "..uid)
        u = ret
        users[ret.uid] = ret
    end
    return u
end

function CMD.get_account_status(uid)
    local u = users[uid]
    if not u then
        return 0
    end
    local account_status = 0
    if u.account_status and u.account_status == 1 then
        if u.freeze_date and u.freeze_date ~= "" then
            if os.time() < dateutils.get_timestamp_by_datetime(u.freeze_date, pattern) then
                account_status = 1
            end
        end
    end
    return account_status
end

function CMD.saveuser(uid, param)
    local u = users[uid]
    assert(u ~= nil, "user not found uid = "..uid)
    for k,v in pairs(param) do
        u[k] = v
    end
    return "ok"
end


function CMD.loadbag(uid)
    local bag = bags[uid]
    if not bag then
        local ret = db[settings.bag_mongodb_key.cname]:findOne({ uid = uid })
        if ret then
            bags[ret.uid] = ret
            bag = ret
        end
    end
    return bag
end

--获取鱼灵
function CMD.loadartifact(uid)
    local temps = artifacts[uid]
    if not temps then
        local ret = db[settings.artifact_mongodb_key.cname]:find({ uid = uid })
        local rets = {}
        while ret:hasNext() do
            local art = ret:next()
            art._id = nil

            table.insert(rets, art)
        end
        artifacts[uid] = rets
        temps = rets
    end
    return temps
end

function CMD.saveartifact(uid, param)
    local arts = artifacts[uid]
    DEBUG("saveartifact arts = ", cjson.encode(arts))
    local artid = param.artid
    local found = false
    for i,v in ipairs(arts) do
        if v.artid == artid and v.star == param.star then
            found = true
            for k1, v1 in pairs(v) do
                if param[k1] then
                    v[k1] = param[k1]
                end
            end
        end
    end
    if not found then
        table.insert(arts, param)
    end
    return "ok"
end

function CMD.savebag(uid, param)
    local b = bags[uid]
    for k,v in pairs(param) do
        b[k] = v
    end
    return "ok"
end


function CMD.loadhero(uid)
    local temps = heros[uid]
    if not temps then
        local ret = db[settings.hero_mongodb_key.cname]:find({ uid = uid })
        local rets = {}
        while ret:hasNext() do
            table.insert(rets, ret:next())
        end
        heros[uid] = rets
        temps = rets
    end
    return temps
end


function CMD.loaduserlineup(uid)
    local lineup = {}
    lineup.lord = CMD.getuserinfo(uid)
    local t = heros[uid]
    local temps = {}
    for i, v in ipairs(t) do
        if checkint(v.pos) > 0 then
            table.insert(temps, v)
        end
    end
    lineup.heros = temps
    return lineup
end


function CMD.savehero(uid, param)
    local tmps = heros[uid]
    local id = param.id
    local found = false
    for i,v in ipairs(tmps) do
        if v.id == id then
            found = true
            for k1,v1 in pairs(v) do
                if param[k1] then
                    v[k1] = param[k1]
                end
            end
        end
    end
    if not found then
        table.insert(tmps, param)
    end
    return "ok"
end

local function loadsaltpot()
    local page = 1
    while true do
        local s = (page - 1) * 100
        local ret = db[settings.saltpot_mongodb_key.cname]:find():sort({ uid = 1 }):skip(s):limit(100)
        if not ret:hasNext() then
            break
        end
        while ret:hasNext() do
            local v = ret:next()
            saltpots[v.uid] = v
        end
        page = page + 1
    end
end


function CMD.getuserbyid(userid)
    local user = users[userid]
    if not user then
        return nil
    end
    local u = {}
    u.uid = users[userid].uid
    u.avatar = user.avatar
    u.nickname = user.nickname
    u.serverid = user.serverid
    u.max_level = user.max_level
    u.zhanli = CMD.getuserzhanli(userid)
    --TODO:获取俱乐部/勋章墙
    u.lineup = CMD.getlineup(userid)
    return u
end


function CMD.getmyusers(unionid)
    local myusers = {}
    for i, mu in pairs(users) do
        if mu.unionid == unionid then
            local u = {}
            u.avatar = mu.avatar
            u.nickname = mu.nickname
            u.serverid = mu.serverid
            u.max_level = mu.max_level
            u.default = mu.default
            u.zhanli = CMD.getuserzhanli(checkint(mu.uid))
            table.insert(myusers, u)
        end
    end

    return myusers
end

local function getequipmentatk(eqps)
     local atk = 0
     for k,v in pairs(eqps) do
        atk = atk + equipmentlogic.getatk(k, v.lv)
     end
     return atk
end


local function getequipmenthp(eqps)
     local atk = 0
     for k,v in pairs(eqps) do
         atk = atk + equipmentlogic.gethp(k, v.lv)
     end
     return atk
end

local function getequipmentdef(eqps)
     local atk = 0
     for k,v in pairs(eqps) do
         atk = atk + equipmentlogic.getdef(k, v.lv)
     end
     return atk
end

local function getequipmentspeed(eqps)
     local atk = 0
     for k,v in pairs(eqps) do
         atk = atk + equipmentlogic.getspeed(k, v.lv)
     end
     return atk
end

local function calsetattr(hero)
    local eqps = hero.equipment
    local sets = {}
    for k,v in pairs(eqps) do
        local color = equipmentlogic.getcolor(v.lv)
        sets[color] = sets[color] or 0
        sets[color] = sets[color] + 1
    end
    local ext = 0
    for k,v in pairs(sets) do
        local attrs = equipmentlogic.getsetattr(k, v)
        for i,v in ipairs(attrs) do
            ext = ext + v.hp_ratio
        end
    end
    return ext
end

local function getartid(artid, star)
    return math.floor(artid * 1000 + star)
end

local function gethaloattrs(uid)
    local temps = {}
    local myheros = heros[uid] or {}
    for k,v in pairs(myheros) do
        -- DEBUG("gethaloattrs v = ", cjson.encode(v))
        local cfg = herologic.getconf(v.heroid)
        if v.pos > 0 and cfg.color == 3 then
            local club = cfg.club
            temps[club] = temps[club] or 0
            temps[club] = temps[club] + 1
        end
    end
    local function found(temps)
        for k,v in pairs(temps) do
            if v >= 3 then
                return k, v
            end
        end
    end
    local club, num = found(temps)
    if club and num then
        local attrs = herologic.gethaloattrs(club, num)
        return attrs
    end
end

local function gethaloext(tp, uid)
    local attrs = gethaloattrs(uid)
    local ext = 0
    if attrs ~= nil then
        for _, attr in ipairs(attrs) do
            local n = attr[tp] or 0
            ext = ext + n
        end
    end
    return ext
end



local function getatk(hero)
    -- DEBUG("getatk hero = ", cjson.encode(hero))
    local born_atk = herologic.getbornatk(hero.heroid)
    local lord_atk = lordlogic.getatk(users[hero.uid].lv)
    local shuijing_atk = 0
    local eqp_atk = getequipmentatk(hero.equipment)
    local yuling_atk = 0
    if hero.yuling then
        yuling_atk = artifactlogic.getattrabs("atk", getartid(hero.yuling.artid, hero.yuling.star))
    end
    local lvup_atk = herologic.getlvupext("atk", hero.heroid) * (hero.lv-1)
    local lord_ext = lordlogic.getlordorderext("atk_ratio", users[hero.uid].stage)
    local shuijing_ext = 0
    local yuling_ext = 0
    local yuling_limit_ext = 0
    if hero.yuling then
        yuling_ext = artifactlogic.getattrabs("atk_ratio", getartid(hero.yuling.artid, hero.yuling.star))
        yuling_limit_ext = artifactlogic.getlimitattrext("atk_ratio", hero.heroid, getartid(hero.yuling.artid, hero.yuling.star))
    end
    local stageup_ext = herologic.getstageupattrext("atk_ratio", hero.stage)
    local starup_ext = herologic.getstarupattrext("atk_ratio", hero.star)
    local club_ext = clublogic.getclubresearchattrnum(hero.work, 0, "atk_ratio", {0,0,0,0,0,0,0,0})
    local skill_ext = herologic.getskillext("atk_ratio", hero.heroid, hero.stage, hero.skill or {})
    local halo_ext = gethaloext("atk_ratio", hero.uid)
    return utils.round((born_atk + lord_atk + shuijing_atk + eqp_atk + yuling_atk + lvup_atk) * (1 + lord_ext) * (1 + shuijing_ext) * (1 + yuling_ext) * (1 + yuling_limit_ext) * (1 + stageup_ext) * (1 + starup_ext) * (1 + club_ext) * (1 + skill_ext) * (1 + halo_ext))
end


local function gethp(hero)
    local born_hp = herologic.getbornhp(hero.heroid)
    local lord_hp = lordlogic.gethp(users[hero.uid].lv)
    local shuijing_hp = 0
    local eqp_hp = getequipmenthp(hero.equipment)
    local yuling_hp = 0
    if hero.yuling then
        yuling_hp = artifactlogic.getattrabs("hp", getartid(hero.yuling.artid, hero.yuling.star))
    end
    local lvup_hp = herologic.getlvupext("hp", hero.heroid) * (hero.lv-1)
    local lord_ext = lordlogic.getlordorderext("hp_ratio", users[hero.uid].stage)
    local shuijing_ext = 0
    local set_ext = calsetattr(hero)
    local yuling_ext = 0
    local yuling_limit_ext = 0
    if hero.yuling then
         yuling_ext = artifactlogic.getattrext("hp_ratio", getartid(hero.yuling.artid, hero.yuling.star))
         yuling_limit_ext = artifactlogic.getlimitattrext("hp_ratio", hero.heroid, getartid(hero.yuling.artid, hero.yuling.star))
    end
    local stageup_ext = herologic.getstageupattrext("hp_ratio", hero.stage)
    local starup_ext = herologic.getstarupattrext("hp_ratio", hero.star)
    local club_ext = clublogic.getclubresearchattrnum(hero.work, 0, "hp_ratio", {0,0,0,0,0,0,0,0})
    local skill_ext = herologic.getskillext("hp_ratio", hero.heroid, hero.stage, hero.skill or {})
    local halo_ext = gethaloext("hp_ratio", hero.uid)
    return utils.round((born_hp + lord_hp + shuijing_hp + eqp_hp + yuling_hp + lvup_hp) * (1 + lord_ext) * (1 + shuijing_ext) * (1 + set_ext) * (1 + yuling_ext) * (1 + yuling_limit_ext) * (1 + stageup_ext) * (1 + starup_ext) * (1 + club_ext) * (1 + skill_ext) * (1 + halo_ext))
end

local function getdef(hero)
    local born_def = herologic.getborndef(hero.heroid)
    local lord_def = lordlogic.getdef(users[hero.uid].lv)
    local shuijing_def = 0
    local eqp_def = getequipmentdef(hero.equipment)
    local yuling_def = 0
    if hero.yuling then
        yuling_def = artifactlogic.getattrabs("def", getartid(hero.yuling.artid, hero.yuling.star))
    end
    local lvup_def = herologic.getlvupext("def", hero.heroid) * (hero.lv-1)
    local lord_ext = lordlogic.getlordorderext("def_ratio", users[hero.uid].stage)
    local shuijing_ext = 0
    local yuling_ext = 0
    local yuling_limit_ext = 0
    if hero.yuling then
        yuling_ext = artifactlogic.getattrext("def_ratio", getartid(hero.yuling.artid, hero.yuling.star))
        yuling_limit_ext = artifactlogic.getlimitattrext("def_ratio", hero.heroid, getartid(hero.yuling.artid, hero.yuling.star))
    end
    local stageup_ext = herologic.getstageupattrext("def_ratio", hero.stage)
    local starup_ext = herologic.getstarupattrext("def_ratio", hero.star)
    local club_ext = clublogic.getclubresearchattrnum(hero.work, 0, "def_ratio", {0,0,0,0,0,0,0,0})
    local skill_ext = herologic.getskillext("def_ratio", hero.heroid, hero.stage, hero.skill or {})
    return utils.round((born_def + lord_def + shuijing_def + eqp_def + yuling_def + lvup_def) * (1 + lord_ext) * (1 + shuijing_ext) * (1 + yuling_ext) * (1 + yuling_limit_ext) * (1 + stageup_ext) * (1 + starup_ext) * (1 + club_ext) * (1 + skill_ext))
end


local function getspeed(hero)
    local bornspeed = herologic.getbornspeed(hero.heroid)
    local shuijingspeed = 0
    local yulingspeed = 0
    if hero.yuling then
        yulingspeed = artifactlogic.getattrabs("spd", getartid(hero.yuling.artid, hero.yuling.star))
    end
    local lvupspeed = herologic.getlvupext("spd", hero.heroid) * (hero.lv-1)
    local skillspeed = herologic.getskillext("spd", hero.heroid, hero.stage, hero.skill or {})
    local skillspeed_ext = herologic.getskillext("spd_ratio", hero.heroid, hero.stage, hero.skill or {})
    return utils.round((bornspeed + shuijingspeed + yulingspeed + lvupspeed + skillspeed) * (1 + skillspeed_ext))
end

function CMD.getherozhanli(myhero)
    local r1 = getatk(myhero) * 1
    local r2 = gethp(myhero) * 0.21
    local r3 = getdef(myhero) * 0.74
    local r4 = getspeed(myhero) * 1
    return utils.round(r1 + r2 + r3 + r4)
end


function CMD.getuserzhanli(uid)
    local zhanli = 0
    local myheros = heros[uid] or {}
    for _, myhero in ipairs(myheros) do
        if myhero.pos > 0 then
            zhanli = zhanli + CMD.getherozhanli(myhero)
        end
    end
    return zhanli
end

-- --获取排行榜
-- function CMD.getallrank(uid)
--     local serverid = users[uid].serverid
--     local myserver = utils.getserver(serverid)
--     local temp = {}
--     for userid, u in pairs(users) do
--         local serverid = users[userid].serverid
--         local server = utils.getserver(serverid)
--         if myserver == server then
--             table.insert(temp, {uid=u.uid, nickname=u.nickname, avatar=u.avatar, zhanli=CMD.getuserzhanli(u.uid), max_level=u.max_level })
--         end
--     end
--     table.sort( temp, function(a, b)
--         if a.max_level == b.max_level then
--             return tonumber(a.zhanli) > tonumber(b.zhanli)
--         end
--         return a.max_level > b.max_level
--     end)
--     local myrank = 0
--     local ranks = {}
--     local rank = 0
--     for i, v in ipairs(temp) do
--         if i < 100 then
--             rank = rank + 1
--             v.rank = rank
--             table.insert(ranks, v)

--             if myrank ~= 0 then
--                 break
--             end
--         end
--         if v.uid == uid then
--             myrank = i
--             if #ranks >= 100 then
--                 break
--             end
--         end
--     end
--     return ranks, myrank
-- end

--获取排行榜
function CMD.getallrank(uid)
    local serverid = users[uid].serverid
    local myserver = utils.getserver(serverid)
    return allranks[myserver] or {}, userrank[uid] or 0
end

-- --获取我的排名
-- function CMD.getmyrank(uid)
--     local serverid = users[uid].serverid
--     local myserver = utils.getserver(serverid)
--     local temp = {}
--     for userid, u in pairs(users) do
--         local serverid = users[userid].serverid
--         local server = utils.getserver(serverid)
--         if myserver == server then
--             table.insert(temp, {uid=u.uid, nickname=u.nickname, avatar=u.avatar, zhanli=CMD.getuserzhanli(u.uid), max_level=u.max_level })
--         end
--     end
--     table.sort( temp, function(a, b)
--         if a.max_level == b.max_level then
--             return tonumber(a.zhanli) > tonumber(b.zhanli)
--         end
--         return a.max_level > b.max_level
--     end)
--     for i, v in ipairs(temp) do
--         if v.uid == uid then
--             return i
--         end
--     end
--     return 0
-- end

function CMD.getmyrank(uid)
    return userrank[uid] or 0
end

--定时更新排行榜
local function updaterank()
    DEBUG("run updaterank")
    local temps = {}
    for userid, u in pairs(users) do
        local serverid = u.serverid
        local server = utils.getserver(serverid)

        if not temps[server] then
            temps[server] = {}
        end
        table.insert(temps[server], {uid=u.uid, nickname=u.nickname, avatar=u.avatar, zhanli=CMD.getuserzhanli(u.uid), max_level=u.max_level })
    end
    for server, temp in pairs(temps) do
        table.sort( temp, function(a, b)
            if a.max_level == b.max_level then
                return tonumber(a.zhanli) > tonumber(b.zhanli)
            end
            return a.max_level > b.max_level
        end)
        local ranks = {}
        for i, v in ipairs(temp) do
            if i <= 100 then
                v.rank = i
                table.insert(ranks, v)
            end
            if i <= 100 then
                userrank[v.uid] = i
            else
                userrank[v.uid] = 0
            end
        end
        allranks[server] = ranks
    end

end

--获取盐罐排行榜
function CMD.getsaltpotrank(uid)
    local serverid = users[uid].serverid
    local myserver = utils.getserver(serverid)
    local temp = {}
    for userid, u in pairs(users) do
        local serverid = users[userid].serverid
        local server = utils.getserver(serverid)
        if myserver == server then
            table.insert(temp, {uid=u.uid, nickname=u.nickname, avatar=u.avatar, zhanli=CMD.getuserzhanli(u.uid), max_level=u.max_level, saltpot = saltpots[u.uid], owner = {uid=users[u.owner].uid, avatar=users[u.owner].avatar,nickname=users[u.owner].nickname}})
        end
    end
    table.sort( temp, function(a, b)
        if a.max_level == b.max_level then
            return tonumber(a.zhanli) > tonumber(b.zhanli)
        end
        return a.max_level > b.max_level
    end)
    local ranks = table.slice(temp, 1, 100)
    return ranks
end

function CMD.getuserinfo(userid)
    local  d = {}
    d.uid = users[userid].uid
    d.avatar = users[userid].avatar
    d.nickname = users[userid].nickname
    d.serverid = users[userid].serverid
    d.max_level = users[userid].max_level
    d.zhanli = CMD.getuserzhanli(userid)
    d.online_status = users[userid].online_status
    d.last_logout_time = users[userid].last_logout_time
    return d
end

function CMD.getlineup(userid)
    local lineup = {}
    local myheros = heros[userid] or {}
    for _, myhero in ipairs(myheros) do
        local hero = clone(myhero)
        if hero.pos > 0 then
            hero._id = nil
            table.insert(lineup, hero)
        end
    end
    return lineup
end

function CMD.getuserowner(userid)
    local u = users[userid]
    return checkint(u.owner)
end


-- --获取推荐好友
-- function CMD.loadrecomfriends(uid, players)
--     local myserver = getServer(uid)

--     local function checkuser(userid)
--         if #players <= 0 then
--             return true
--         end
--         for _, uuid in ipairs(players) do
--             if uuid ~= userid then
--                 return true
--             end
--         end
--     end
--     local friends = {}

--     for userid, u in pairs(users) do
--         local server = getServer(userid)
--         if myserver == server and u.online_status == 1 and checkuser(userid) and uid ~= userid then
--             local user = CMD.getuserinfo(userid)
--             table.insert(friends, user)
--         end
--     end

--     if #friends <= 6 then
--         return friends
--     end

--     for i=1,7 do
--         friends = table.shuffle(friends)
--     end
--     local s = math.random(1, #friends - 6)
--     friends = table.slice(friends, s, 6)
--     return friends
-- end

--获取推荐好友
function CMD.loadrecomfriends(uid, players)
    local myserver = getServer(uid)

    local function checkuser(userid)
        if #players <= 0 then
            return true
        end
        for _, uuid in ipairs(players) do
            if uuid ~= userid then
                return true
            end
        end
    end
    local friends = {}

    local allplayers = allranks[myserver]

    for i, user in ipairs(allplayers) do
        local userid = user.uid
        local u = users[userid]
        if u.online_status == 1 and checkuser(userid) and uid ~= userid then
            table.insert(friends, user)
        end
    end

    if #friends <= 6 then
        return friends
    end

    for i=1,7 do
        friends = table.shuffle(friends)
    end
    local s = math.random(1, #friends - 6)
    friends = table.slice(friends, s, 6)
    return friends
end

function CMD.getuserinfolist(players)
    local result = {}
    for _, userid in ipairs(players) do
        result[userid] = CMD.getuserinfo(userid)
    end
    return result
end

--获取总战力
function CMD.getzhanlitotal(players)
    local zhanli = 0
    for _, userid in ipairs(players) do
        zhanli = zhanli + CMD.getuserzhanli(userid)
    end
    return zhanli
end

--获取总战力
function CMD.getalluserzhanli(players)
    local result = {}
    for _, userid in ipairs(players) do
        result[userid] = CMD.getuserzhanli(userid)
    end
    return result
end

function CMD.updateowner(ownerid, userid)
    local u = users[userid]
    u.owner = ownerid
    local ok = mqhelper.exec("upsert", userid, settings.user_mongodb_key.tname, settings.user_mongodb_key.cname, {["$set"]={owner=ownerid}}, {uid=userid})
    return "ok"
end

--获取用户抢占的盐罐
function CMD.getuserrobsaltpots(userid)
    local pots = {}
    for _,pot in pairs(saltpots) do
        if pot.rob_id == userid then
            table.insert(pots, pot)
        end
    end
    return pots
end

--获取用户家的盐罐
function CMD.getusersaltpot(userid)
    local mypot = saltpots[userid]
    return mypot
end


function CMD.getsaltpotlist(players)
    local result = {}
    for _, userid in ipairs(players) do
        result[userid].saltpot = saltpots[userid] or {}
        local owner = users[userid].owner or 0
        if owner > 0 then
            result[userid].owner = {uid=users[owner].uid,avatar=users[owner].avatar,nickname=users[owner].nickname}
        end
    end
    return result
end


--抢占盐罐
function CMD.robsaltpot(uid, userid, lineup, time)
    local pot = saltpots[userid]
    pot.rob_id = uid
    pot.rob_time = os.time()
    pot.rob_lineup = lineup
    pot.consume_time = time
    return "ok"
end

local function getrobpot(rob_id, level)
    for i,v in pairs(saltpots) do
        if v.rob_id == rob_id and v.level == level then
            return v.uid
        end
    end
end

--收集盐罐
function CMD.collectsaltpot(rob_id, level)
    local uid = getrobpot(rob_id, level)
    assert(uid~=nil, "收集盐罐失败")
    local pot = saltpots[uid]
    pot.rob_id = 0
    pot.rob_time = 0
    pot.level = 0
    pot.end_time = 0
    pot.rob_lineup = {}
    pot.consume_time = 0
    return "ok"
end

--制造盐罐奖池
local function makesaltpotpools()
    local pools = {}
    for k,v in pairs(yanguanconf) do
       for i=1, v.cost * 100 do
            table.insert(pools, checkint(k))
        end
    end

    for i=1,7 do
        pools = table.shuffle(pools)
    end
    return pools
end

--随机盐罐
local function randomsaltpot()
    local pools = makesaltpotpools()
    local r = math.random(1, 100)
    if not pools[r] then
        return nil
    end
    local level = pools[r]
    return level
end

--刷新盐罐
local function refreshsaltpot()
    for _, u in pairs(users) do
        if u.max_level >= 50 then --大于50关后刷新
            local level = randomsaltpot()
            if level then
                if not saltpots[u.uid] then --没有盐罐 则刷新盐罐
                    local pot = {
                        uid=u.uid,
                        serverid=u.serverid,
                        level=level,
                        rob_id=0,
                        rob_time=0,
                        rob_lineup={},
                        consume_time = 0, --占领收获的时间
                        end_time=os.time() + 3*3600,
                        refresh_time=os.time(),
                    }
                    saltpots[u.uid] = pot
                    db[settings.saltpot_mongodb_key.cname]:update({uid=u.uid}, pot, true)
                else
                    --有盐罐
                    local pot = saltpots[u.uid]
                    --未被占领
                    if pot.rob_id == 0 then
                        if os.time() > pot.end_time then
                            pot.rob_id = 0
                            pot.rob_time = 0
                            pot.level = 0
                            pot.end_time = 0
                            pot.rob_lineup = {}
                            db[settings.saltpot_mongodb_key.cname]:update({uid=u.uid}, pot, true)
                        end
                    else
                        --占领了
                        local t = checkint(pot.rob_time) + pot.consume_time --占领结束时间
                        if os.time() > t then
                            pot.rob_id = 0
                            pot.rob_time = 0
                            pot.level = 0
                            pot.end_time = 0
                            pot.rob_lineup = {}
                            pot.consume_time = 0
                            db[settings.saltpot_mongodb_key.cname]:update({uid=u.uid}, pot, true)
                        end
                    end
                end
            end
        end
    end
    skynet.sleep(60*100)
end

function CMD.send2all(mail)
    skynet.fork(function()
        for userid, user in pairs(users) do
           local id = skynet.call(".id_service", "lua", "genid", "mail")
            mail.id = id
            mail.receiver = userid
            local ok = mongohelper.insert(settings.mail_mongodb_key.tname, settings.mail_mongodb_key.cname, mail)
            skynet.send(".msgd", "lua", "sendmail", userid, mail)
        end
    end)
    return "ok"
end

skynet.start(function()
    skynet.dispatch("lua", function(session, source, cmd, ...)
        skynet.error("usercenterd dispatch", cmd)
        local f = assert(CMD[cmd])
        skynet.ret(skynet.pack(f(...)))
    end)

    --链接mongo
    local mongoconf     = settings.db_cnf[skynet_node_name].mongodb_cnf
    local client = mongo.client(mongoconf)

    if not client then
        error("usercenterd mongo 数据库连接失败")
    end

    local tname = settings.mongodb_tb.game
    db = client:getDB(tname)
    if not db then
        error("mongo 连接失败")
    end

    rediscli = redis.connect(settings.db_cnf.loginserver.redisdb_cnf)

    if not rediscli then
        error(" rediscli 连接失败")
    end

    skynet.fork(function()
        while true do
            db = client:getDB(tname)
            rediscli:ping()
            skynet.sleep(1000)
        end
    end)

    loadalluser()
    loadallhero()
    loadallartifact()
    loadallbag()
    loadsaltpot() --加载盐罐

    skynet.fork(function()
        while true do
            refreshsaltpot()
        end
    end)

    skynet.fork(function()
        while true do
            updaterank()
            skynet.sleep(6000)
        end
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
