local skynet = require "skynet"
local queue = require "skynet.queue"
local redishelper = require "redishelper"
local keysutils   = require "keysutils"
local dateutils   = require "dateutils"
local utils       = require "utils"
local redis       = require 'skynet.db.redis'
local mongo       = require 'skynet.db.mongo'
local settings    = require "settings"
local clublogic   = require "clublogic"

local skynet_node_name = ...
require "skynet.manager"
require "functions"

local CMD = {}

local db = {}

local clubmsgs = {}
local recruitmsgs ={}
local arenamsgs ={}
local baifumsgs ={}

local function getServer(serverid)
    return utils.getserver(serverid)
end

local function loadclubmsg()
    local page = 1
    while true do
        local s = (page - 1) * 100
        local ret = db[settings.club_mongodb_key.cname]:find():sort({ id = 1 }):skip(s):limit(100)
        if not ret:hasNext() then
            break
        end
        while ret:hasNext() do
            local club = ret:next()
            local ret1 = db[settings.clubmsg_mongodb_key.cname]:find({clubid = club.id}):sort({ id = -1 }):limit(50)
            local msgs = clubmsgs[club.id] or {}
            while ret1:hasNext() do
                local msg = ret1:next()
                msg._id = nil
                table.insert(msgs, msg)
            end
        end
        page = page + 1
    end
end

local function loadrecruitmsg()
    for serverid=1, 100 do
        local res = db[settings.recruitmsg_mongodb_key.cname]:find({serverid = serverid}):sort({ id = -1 }):limit(50)
        local msgs = recruitmsgs[serverid] or {}
        while res:hasNext() do
            local msg = res:next()
            msg._id = nil
            table.insert(msgs, msg)
        end
    end
end

local function loadarenamsg()
    local page = 1
    while true do
        local s = (page - 1) * 100
        local ret = db[settings.arenamsg_mongodb_key.cname]:find():sort({ id = 1 }):skip(s):limit(100)
        if not ret:hasNext() then
            break
        end
        while ret:hasNext() do
            local msg = ret:next()
            msg._id = nil
            local msgs = arenamsgs[msg.server] or {}
            if #msgs < 50 then
                table.insert(msgs, msg)
            end
        end
        page = page + 1
    end
end


local function loadbaifumsg()
    local page = 1
    while true do
        local s = (page - 1) * 100
        local ret = db[settings.baifumsg_mongodb_key.cname]:find():sort({ id = 1 }):skip(s):limit(100)
        if not ret:hasNext() then
            break
        end
        while ret:hasNext() do
            local msg = ret:next()
            msg._id = nil
            local msgs = baifumsgs[msg.server] or {}
            if #msgs < 50 then
                table.insert(msgs, msg)
            end
        end
        page = page + 1
    end
end

function CMD.sendclubmsg(clubid, msg)
    local temp = clubmsgs[clubid] or {}
    table.insert(temp, msg)
    local l=#temp
    if l>=50 then
        temp = table.slice(temp, 50, -1)
    end
    clubmsgs[clubid] = temp
    local ok = db[settings.clubmsg_mongodb_key.cname]:insert(msg)
    return "ok"
end

function CMD.loadclubmsg(clubid, msgid)
    local msgs = clubmsgs[clubid]
    local resp = {}
    for i,v in ipairs(msgs) do
        if v.id >= msgid then
            table.insert(resp, v)
        end
    end
    table.sort( resp, function(a, b) return a.id > b.id end)
    return resp
end



function CMD.sendrecruitmsg(serverid, msg)
    local temp = recruitmsgs[serverid] or {}
    table.insert(temp, msg)
    local l=#temp
    if l>=50 then
        temp = table.slice(temp, 50, -1)
    end
    recruitmsgs[serverid] = temp
    local ok = db[settings.recruitmsg_mongodb_key.cname]:insert(msg)
    return "ok"
end

function CMD.loadrecruitmsg(serverid, msgid)
    local msgs = recruitmsgs[serverid]
    local resp = {}
    for i,v in ipairs(msgs) do
        if v.id >= msgid then
            table.insert(resp, v)
        end
    end
    table.sort( resp, function(a, b) return a.id > b.id end)
    return resp
end



function CMD.sendarenamsg(server, msg)
    local temp = arenamsgs[server] or {}
    table.insert(temp, msg)
    local l=#temp
    if l>=50 then
        temp = table.slice(temp, 50, -1)
    end
    arenamsgs[server] = temp
    local ok = db[settings.arenamsg_mongodb_key.cname]:insert(msg)
    return "ok"
end

function CMD.loadarenamsg(server, msgid)
    local msgs = arenamsgs[server]
    local resp = {}
    for i,v in ipairs(msgs) do
        if v.id >= msgid then
            table.insert(resp, v)
        end
    end
    table.sort( resp, function(a, b) return a.id > b.id end)
    return resp
end


function CMD.sendbaifumsg(server, msg)
    local temp = baifumsgs[server] or {}
    table.insert(temp, msg)
    local l=#temp
    if l>=50 then
        temp = table.slice(temp, 50, -1)
    end
    baifumsgs[server] = temp
    local ok = db[settings.baifumsg_mongodb_key.cname]:insert(msg)
    return "ok"
end

function CMD.loadbaifumsg(server, msgid)
    local msgs = baifumsgs[server]
    local resp = {}
    for i,v in ipairs(msgs) do
        if v.id >= msgid then
            table.insert(resp, v)
        end
    end
    table.sort( resp, function(a, b) return a.id > b.id end)
    return resp
end

skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)

    --链接mongo
    local mongoconf     = settings.db_cnf[skynet_node_name].mongodb_cnf
    local client = mongo.client(mongoconf)

    if not client then
        error("usercenterd mongo 数据库连接失败")
    end

    local tname = settings.mongodb_tb.game
    db = client:getDB(tname)
    if not db then
        error("mongo 连接失败")
    end

    skynet.fork(function()
        while true do
            if true then
                db = client:getDB(tname)
                skynet.sleep(1000)
            end
        end
    end)

    loadclubmsg()
    loadrecruitmsg()
    loadarenamsg()
    loadbaifumsg()
    collectgarbage()
    skynet.register('.' .. SERVICE_NAME)
end)
