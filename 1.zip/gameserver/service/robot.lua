local skynet     = require "skynet"
local datacenter = require "skynet.datacenter"
local cjson      = require "cjson"
local websocket  = require "http.websocket"
local http       = require("http.httpc")

local openid = ...

local uid
local ws_id

local CMD = {}

local header = {
    ["content-type"] = "application/json"
}

local function create_client()
    ws_id = websocket.connect("ws://127.0.0.1:8889")
end


local function callback()
    skynet.fork(function()
        while true do
            local resp, close_reason = websocket.read(ws_id)
            WARN("reobt read resp : " .. (resp and resp or "[Close] " .. close_reason))
            local resp = cjson.decode(resp)
            local c = resp.c
            local m = resp.m
            local data = resp.data
            if c == "user" and m == "loaduser" then
                USER = data.data.user
                MAX_LEVEL = USER.max_level
            end
            if c == "user" and m == "loadallhero" then
                HEROS = data.data.heros
            end
            if c == "user" and m == "pass" then
                MAX_LEVEL = data.data.max_level
            end
        end
    end)
end


local function loaduser()
    local msg = cjson.encode({c="user", m="loaduser", data={}})
    websocket.write(ws_id, msg)
    skynet.sleep(100)
    local msg = cjson.encode({c="user", m="loadallhero", data={}})
    websocket.write(ws_id, msg)
    local msg = cjson.encode({c="user", m="loadbag", data={}})
    websocket.write(ws_id, msg)
    local msg = cjson.encode({c="user", m="loadachievement", data={}})
    websocket.write(ws_id, msg)
    skynet.sleep(100)
end

local function addbag()
    local msg = cjson.encode({c="user", m="addbag", data={name="box_lv1", num=1000}})
    websocket.write(ws_id, msg)
    local msg = cjson.encode({c="user", m="addbag", data={name="box_lv2", num=1000}})
    websocket.write(ws_id, msg)
    local msg = cjson.encode({c="user", m="addbag", data={name="box_lv3", num=1000}})
    websocket.write(ws_id, msg)
    local msg = cjson.encode({c="user", m="addbag", data={name="box_lv4", num=1000}})
    websocket.write(ws_id, msg)
    local msg = cjson.encode({c="user", m="addbag", data={name="coin", num=100000000000}})
    websocket.write(ws_id, msg)
    skynet.sleep(100)
end

local function openbox()
    local msg = cjson.encode({c="user", m="openbox", data={lv=1, num=10}})
    websocket.write(ws_id, msg)
    local msg = cjson.encode({c="user", m="openbox", data={lv=2, num=10}})
    websocket.write(ws_id, msg)
    local msg = cjson.encode({c="user", m="openbox", data={lv=3, num=10}})
    websocket.write(ws_id, msg)
    local msg = cjson.encode({c="user", m="openbox", data={lv=4, num=10}})
    websocket.write(ws_id, msg)
    skynet.sleep(100)
end

--上阵
local function confirmup()
    for i,v in ipairs(HEROS) do
        local msg = cjson.encode({c="user", m="confirmup", data={heroid=v.heroid}})
        websocket.write(ws_id, msg)
    end
end

--升级
local function lordlvup()
    local msg = cjson.encode({c="user", m="lvup", data={tp="lord", lv=10}})
    websocket.write(ws_id, msg)
end

local function herolvup()
    for i,v in ipairs(HEROS) do
        local msg = cjson.encode({c="user", m="lvup", data={tp="hero", heroid=v.heroid, lv=10}})
        websocket.write(ws_id, msg)
    end
end


local function lordstageup()
    local msg = cjson.encode({c="user", m="stageup", data={tp="lord"}})
    websocket.write(ws_id, msg)
end

local function herostageup()
    for i,v in ipairs(HEROS) do
        local msg = cjson.encode({c="user", m="stageup", data={tp="hero", heroid=v.heroid}})
        websocket.write(ws_id, msg)
    end
end


local function eqplvup()
    -- for i,v in ipairs(HEROS) do
    --     local msg = cjson.encode({c="user", m="lvup", data={heroid=v.heroid}})
    --     websocket.write(ws_id, msg)
    -- end
end

local function pass()
    local msg = cjson.encode({c="user", m="pass", data={level=MAX_LEVEL}})
    websocket.write(ws_id, msg)
end

function CMD.login()
    local data = {
        module="login",
        method="minilogin",
        server_ca="hDJ^54D@!&DH*Sdh18(Sahjig123",
        parms={
            openid=openid,
            iv=openid,
            encryptedData=openid,
            protocol="ws",
            serverid=1
        }
    }
    local statuscode, resp_str = http.request("POST", "http://127.0.0.1:8002", "/api", {}, header, cjson.encode(data))
    local ok, resp = pcall(cjson.decode, resp_str)

    if not ok then
        error("login failed")
    end
    DEBUG("resp = ", DUMP(resp))
    local uid = math.floor(resp.data.uid)
    create_client()
    -- while true do
    local msg = cjson.encode({c="user", m="login", data={subid=resp.data.subid, token="123", uid=uid}})
    websocket.write(ws_id, msg)
    local resp, close_reason = websocket.read(ws_id)
    DEBUG("reobt resp : " .. (resp and resp or "[Close] " .. close_reason))
    if not resp then
        error("echo server close.")
    end
    local ok, resp = pcall(cjson.decode, resp)

    if not ok then
        error("login failed")
    end

    callback()
    loaduser()
    addbag()
    skynet.fork(function()
        while true do
            openbox()
            skynet.sleep(100)
            confirmup()
            skynet.sleep(100)
            lordlvup()
            skynet.sleep(100)
            herolvup()
            skynet.sleep(100)
            lordstageup()
            skynet.sleep(100)
            herostageup()
            skynet.sleep(50)
            eqplvup()
            skynet.sleep(50)
            pass()
            skynet.sleep(100)
        end
    end)
    DEBUG("robot login success")
    return "ok"
end

function CMD.kick()
    DEBUG("kick openid = ", openid)
    skynet.exit()
end

skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        -- skynet.error("robot cmd = ", command)
        local f = assert(CMD[command])
        local ret = f(...)

        if ret then
            skynet.ret(skynet.pack(ret))
        end

    end)
    collectgarbage()
end)
