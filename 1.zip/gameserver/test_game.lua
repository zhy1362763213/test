local skynet = require "skynet"
local cjson  = require "cjson"

require "functions"
local s, e = ...
s = math.floor(tonumber(s))
e = math.floor(tonumber(e))
local CMD = {}
math.randomseed(tostring(os.time()):reverse():sub(1, 7))

local robots = {}

function CMD.kick()
    for _, robot in ipairs(robots) do
        pcall(skynet.call, robot, "lua", "kick")
    end
    return 'ok'
end

skynet.start(function()
    skynet.fork(function()
        for i = s, e do
            local robot = skynet.newservice("robot", i)
            table.insert(robots, robot)
            skynet.send(robot, "lua", "login")
        end
    end)
    skynet.dispatch("lua", function(_, _, command, ...)
        --skynet.trace()
        local f = CMD[command]

        local ret = f(...)

        if ret then
            skynet.ret(skynet.pack(ret))
        end
    end)
end)
