local skynet = require "skynet"
local mongohelper = require "mongohelper"
local keysutils   = require "keysutils"
local dateutils   = require "dateutils"
local utils       = require "utils"
local redis       = require 'skynet.db.redis'
local mongo       = require 'skynet.db.mongo'
local settings    = require "settings"
local maillogic   = require "maillogic"
local cjson       = require "cjson"
local redishelper = require "redishelper"
local skynet_node_name = ...
require "skynet.manager"
require "functions"

local CMD = {}

local buy_scripts = [[
    redis.call('zincrby', ARGV[1], ARGV[3], ARGV[2])
    redis.call('expire', ARGV[1], ARGV[4])
    return "ok"
]]

local receive_scripts = [[
    redis.call('zadd', ARGV[1], 1, ARGV[2])
    redis.call('expire', ARGV[1], ARGV[3])
    return "ok"
]]

local score_scripts = [[
    redis.call('incrby', ARGV[1], ARGV[2])
    redis.call('expire', ARGV[1], ARGV[3])
    return "ok"
]]

local pattern = "(%d+)-(%d+)-(%d+) (%d+):(%d+):(%d+)"

function CMD.loadallconfig(serverid)
    local server = mongohelper.findOne(settings.server_item_mongodb_key.tname, settings.server_item_mongodb_key.cname, {_id=serverid})
    local activity_id = server.activity_id or 0
    local config = mongohelper.find(settings.activity_config_mongodb_key.tname, settings.activity_config_mongodb_key.cname)
    for k,v in ipairs(config) do
        local s = dateutils.get_timestamp_by_datetime(v.start_time, pattern)
        local e = dateutils.get_timestamp_by_datetime(v.end_time, pattern)
        if os.time() >= s and os.time() < e then
            v.status = 1
        else
            v.status = 0
        end
        if activity_id == v._id then
        local timestamp = dateutils.get_timestamp_by_datetime(server.activity_end_time, pattern)
        if os.time() > timestamp then
            v.status = 1
        end
    end
    end
    return config
end

function CMD.loadconfig(id)
    local res = mongohelper.findOne(settings.activity_config_mongodb_key.tname, settings.activity_config_mongodb_key.cname, {_id=id})
    return res
end

function CMD.loadheishi(uid)
    local k = keysutils.user_week_buy_heishi_key(settings.appname, uid, dateutils.get_weekno())
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    return utils.redis_pack(res)
end


function CMD.loadbaoxiang(uid)
    local k = keysutils.user_week_buy_baoxiang_key(settings.appname, uid, dateutils.get_weekno())
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    local t1 = utils.redis_pack(res)

    local k = keysutils.user_week_receivebuy_baoxiang_key(settings.appname, uid, dateutils.get_weekno())
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    local t2 = utils.redis_pack(res)

    local k = keysutils.user_week_receive_baoxiang_key(settings.appname, uid, dateutils.get_weekno())
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    local t3 = utils.redis_pack(res)

    local k = keysutils.user_week_baoxiang_score_key(settings.appname, uid, dateutils.get_weekno())
    local t4 = redishelper.exec("get", uid, k) or 0

    return t1, t2, t3, t4
end


function CMD.loadzhaomu(uid)
    local k = keysutils.user_week_buy_zhaomu_key(settings.appname, uid, dateutils.get_weekno())
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    local t1 = utils.redis_pack(res)

    local k = keysutils.user_week_receivebuy_zhaomu_key(settings.appname, uid, dateutils.get_weekno())
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    local t2 = utils.redis_pack(res)

    local k = keysutils.user_week_receive_zhaomu_key(settings.appname, uid, dateutils.get_weekno())
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    local t3 = utils.redis_pack(res)

    local k = keysutils.user_week_zhaomu_score_key(settings.appname, uid, dateutils.get_weekno())
    local t4 = redishelper.exec("get", uid, k) or 0
    return t1, t2, t3, t4
end

function CMD.loadduanwu(uid)
    local k = keysutils.user_buy_duanwu_key(settings.appname, uid, dateutils.getyear())
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    local t1 = utils.redis_pack(res)

    local k = keysutils.user_receivebuy_duanwu_key(settings.appname, uid, dateutils.getyear())
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    local t2 = utils.redis_pack(res)

    local k = keysutils.user_receive_duanwu_key(settings.appname, uid, dateutils.getyear())
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    local t3 = utils.redis_pack(res)

    local k = keysutils.user_duanwu_score_key(settings.appname, uid, dateutils.getyear())
    local t4 = redishelper.exec("get", uid, k) or 0

    local k = keysutils.user_duihuan_duanwu_key(settings.appname, uid, dateutils.getyear())
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    local t5 = utils.redis_pack(res)
    return t1, t2, t3, t4, t5
end


function CMD.buyheishi(uid, id, num)
    local k = keysutils.user_week_buy_heishi_key(settings.appname, uid, dateutils.get_weekno())
    local overtime = dateutils.oneweekend(os.time() + 7*86400)
    local ex = overtime - os.time()
    return redishelper.exec("eval", uid, buy_scripts, 4, "k", "id", "num", "ex", k, id, num, ex)
end


function CMD.buybaoxiang(uid, id, num)
    local k = keysutils.user_week_buy_baoxiang_key(settings.appname, uid, dateutils.get_weekno())
    local overtime = dateutils.oneweekend(os.time() + 7*86400)
    local ex = overtime - os.time()
    return redishelper.exec("eval", uid, buy_scripts, 4, "k", "id", "num", "ex", k, id, num, ex)
end


function CMD.receivebuybaoxiang(uid, id, num)
    local k = keysutils.user_week_receivebuy_baoxiang_key(settings.appname, uid, dateutils.get_weekno())
    local overtime = dateutils.oneweekend(os.time() + 7*86400)
    local ex = overtime - os.time()
    return redishelper.exec("eval", uid, buy_scripts, 4, "k", "id", "num", "ex", k, id, num, ex)
end


function CMD.incrbaoxiangscore(uid, score)
    score = checkint(score)
    local k = keysutils.user_week_baoxiang_score_key(settings.appname, uid, dateutils.get_weekno())
    local overtime = dateutils.oneweekend(os.time() + 7*86400)
    local ex = overtime - os.time()
    return redishelper.exec("eval", uid, score_scripts, 3, "k", "score", "ex", k, score, ex)
end


function CMD.receivebaoxiang(uid, id)
    local k = keysutils.user_week_receive_baoxiang_key(settings.appname, uid, dateutils.get_weekno())
    local overtime = dateutils.oneweekend(os.time() + 7*86400)
    local ex = overtime - os.time()
    return redishelper.exec("eval", uid, receive_scripts, 3, "k", "id", "ex", k, id, ex)
end


function CMD.buyzhaomu(uid, id, num)
    local k = keysutils.user_week_buy_zhaomu_key(settings.appname, uid, dateutils.get_weekno())
    local overtime = dateutils.oneweekend(os.time() + 7*86400)
    local ex = overtime - os.time()
    return redishelper.exec("eval", uid, buy_scripts, 4, "k", "id", "num", "ex", k, id, num, ex)
end


function CMD.buyduanwu(uid, id, num)
    local k = keysutils.user_buy_duanwu_key(settings.appname, uid, dateutils.getyear())
    local overtime = dateutils.oneweekend(os.time() + 30*86400)
    local ex = overtime - os.time()
    return redishelper.exec("eval", uid, buy_scripts, 4, "k", "id", "num", "ex", k, id, num, ex)
end

function CMD.incrzhaomuscore(uid, score)
    score = checkint(score)
    local k = keysutils.user_week_zhaomu_score_key(settings.appname, uid, dateutils.get_weekno())
    local overtime = dateutils.oneweekend(os.time() + 7*86400)
    local ex = overtime - os.time()
    return redishelper.exec("eval", uid, score_scripts, 3, "k", "score", "ex", k, score, ex)
end

function CMD.incrduanwuscore(uid, score)
    score = checkint(score)
    local k = keysutils.user_duanwu_score_key(settings.appname, uid, dateutils.getyear())
    local overtime = dateutils.oneweekend(os.time() + 7*86400)
    local ex = overtime - os.time()
    return redishelper.exec("eval", uid, score_scripts, 3, "k", "score", "ex", k, score, ex)
end

function CMD.receivebuyzhaomu(uid, id, num)
    local k = keysutils.user_week_receivebuy_zhaomu_key(settings.appname, uid, dateutils.get_weekno())
    local overtime = dateutils.oneweekend(os.time() + 7*86400)
    local ex = overtime - os.time()
    return redishelper.exec("eval", uid, buy_scripts, 4, "k", "id", "num", "ex", k, id, num, ex)
end


function CMD.receivezhaomu(uid, id)
    local k = keysutils.user_week_receive_zhaomu_key(settings.appname, uid, dateutils.get_weekno())
    local overtime = dateutils.oneweekend(os.time() + 7*86400)
    local ex = overtime - os.time()
    return redishelper.exec("eval", uid, receive_scripts, 3, "k", "id", "ex", k, id, ex)
end


function CMD.receivebuyduanwu(uid, id, num)
    local k = keysutils.user_receivebuy_duanwu_key(settings.appname, uid, dateutils.getyear())
    local overtime = dateutils.oneweekend(os.time() + 30*86400)
    local ex = overtime - os.time()
    return redishelper.exec("eval", uid, buy_scripts, 4, "k", "id", "num", "ex", k, id, num, ex)
end


function CMD.receiveduanwu(uid, id)
    local k = keysutils.user_receive_duanwu_key(settings.appname, uid, dateutils.getyear())
    local overtime = dateutils.oneweekend(os.time() + 30*86400)
    local ex = overtime - os.time()
    return redishelper.exec("eval", uid, receive_scripts, 3, "k", "id", "ex", k, id, ex)
end

function CMD.duihuanduanwu(uid, id, num)
    local k = keysutils.user_duihuan_duanwu_key(settings.appname, uid, dateutils.getyear())
    local overtime = dateutils.oneweekend(os.time() + 30*86400)
    local ex = overtime - os.time()
    return redishelper.exec("eval", uid, buy_scripts, 4, "k", "id", "num", "ex", k, id, num, ex)
end

skynet.start(function()
    -- local c = CMD.loadallconfig()
    -- DEBUG("loadallconfig = ", DUMP(c))
    -- mongohelper.batch_insert(settings.activity_config_mongodb_key.tname, settings.activity_config_mongodb_key.cname, {{_id=1, name="江湖黑市", status=1}, {_id=2,  name="宝箱活动", status=1}, {_id=3, name="招募活动", status=1}})
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
