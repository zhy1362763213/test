local skynet    = require "skynet"
local cjson     = require "cjson"
local redis     = require 'skynet.db.redis'
local settings  = require "settings"
local mongo     = require 'skynet.db.mongo'
local bson      = require 'bson'
local mqhelper  = require "mqhelper"
local settings  = require "settings"

local skynet_node_name = ...

local mongodb
local db

local id_tb = {}

require "skynet.manager"


local CMD = {}

local function init()
    local ret = db:find()
    if not ret:hasNext() then
        return
    end
    while ret:hasNext() do
        local v = ret:next()
        id_tb[v.key] = v.uuid
    end
    return "ok"
end


function CMD.genid(key)
    id_tb[key] = id_tb[key] or 0
    id_tb[key] = id_tb[key] + 1
    db:update({key=key}, {["$set"]={key=key, uuid=id_tb[key]}}, true)
    local r = mongodb:runCommand("getLastError")
    assert(r.err == bson.null, r.err)
    assert(r.n > 0, "failed")
    return id_tb[key]
end


local inc = 0
local workerId = settings.nodes[skynet_node_name].server_no

function CMD.getuuid()
    inc = inc + 1
    local d = os.date("*t")
    local s = string.format("%04d%02d%02d%02d%02d%02d%03d%08d",d.year,d.month,d.day,d.hour,d.min,d.sec,workerId,inc)
    return "JSDD_"..s
end

skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        skynet.error("redis despatch command = ", command)
        local f = assert(CMD[command])
        skynet.ret(skynet.pack(f(...)))
    end)

    --链接mongo
    local mongoconf     = settings.db_cnf[skynet_node_name].mongodb_cnf
    local client = mongo.client(mongoconf)

    if not client then
        error("mongo 数据库连接失败")
    end

    local tname = settings.mongodb_tb.game
    mongodb = client:getDB(tname)
    if not mongodb then
        error("mongo 连接失败")
    end

    db = mongodb["gen_id"]
    skynet.fork(function()
        while true do
            mongodb = client:getDB(tname)
            skynet.sleep(1000)
        end
    end)

    init()

    skynet.register('.' .. SERVICE_NAME)
end)
