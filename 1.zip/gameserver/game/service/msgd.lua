local skynet     = require "skynet"
local cjson      = require "cjson"
local datacenter = require "skynet.datacenter"
local mongo      = require 'skynet.db.mongo'
local utils      = require "utils"
local dateutils  = require "dateutils"
local settings   = require 'settings'
math.randomseed(tostring(os.time()):reverse():sub(1, 7))

local skynet_node_name = ...
require "skynet.manager"

require "functions"

local db
local CMD            = {}
local response_queue = {}
local onlineusers = {}

local lasttime = nil

local mailbox = {} -- 邮件消息
local clubbox = {} -- 俱乐部消息
local recruitbox = {} -- 招募消息
local arenabox  = {} -- 竞技场消息
local baifubox  = {} -- 百服消息
local friendapplybox  = {} -- 好友申请消息
local friendagreebox  = {} -- 好友申请通过消息
local givecoinbox = {} -- 赠送金币消息
local friendbox  = {} -- 好友消息

--邮件消息
local function sendmail(uid)
    if mailbox[uid] and #mailbox[uid] > 0 then
        local msg = table.remove(mailbox[uid], 1)

        local v = response_queue[uid]
        if v then
            if msg.id > (v.msgindex.mailindex or 0) then
                local pkg = {}
                local box = {}
                local data = {}
                pkg.box = box

                box.c        = 'msg'
                box.m        = 'mailmsg'
                box.data     = data
                data.errcode = 0
                data.errmsg  = ""
                data.data    = { msg = msg }
                v.foo(true, pkg)
                return true
            end
        end
    end

    return false
end


local function sendclubmsg(uid)
    local v = response_queue[uid]
    if v then
        local clubid = v.clubid
        if clubid then
            clubid = checkint(clubid)
            local temp = clubbox[clubid] or {}
            for i, msg in ipairs(temp) do
                if msg.id>(v.msgindex.clubindex or 0) then

                    local pkg = {}
                    local box = {}
                    local data = {}
                    pkg.box = box

                    box.c        = 'msg'
                    box.m        = 'clubmsg'
                    box.data     = data
                    data.errcode = 0
                    data.errmsg  = ""
                    data.data    = { msg = msg }

                    v.foo(true, pkg)
                    return true
                end
            end
        end
    end
    return false
end

local function sendrecruitmsg(uid)
    local v = response_queue[uid]
    if v then
        local serverid = v.serverid
        if serverid then
            local temp = recruitbox[serverid] or {}

            for i,msg in ipairs(temp) do
                if msg.id>(v.msgindex.recruitindex or 0) then

                    local pkg = {}
                    local box = {}
                    local data = {}
                    pkg.box = box

                    box.c        = 'msg'
                    box.m        = 'recruitmsg'
                    box.data     = data
                    data.errcode = 0
                    data.errmsg  = ""
                    data.data    = { msg = msg }

                    v.foo(true, pkg)
                    return true
                end
            end
        end
    end
    return false
end


local function sendarenamsg(uid)
    local v = response_queue[uid]
    if v then
        local server = v.arenaserver
        if server then
            local temp = arenabox[server] or {}

            for i,msg in ipairs(temp) do
                if msg.id>(v.msgindex.arenaindex or 0) then

                    local pkg = {}
                    local box = {}
                    local data = {}
                    pkg.box = box

                    box.c        = 'msg'
                    box.m        = 'arenamsg'
                    box.data     = data
                    data.errcode = 0
                    data.errmsg  = ""
                    data.data    = { msg = msg }

                    v.foo(true, pkg)
                    return true
                end
            end
        end
    end
    return false
end


local function sendbaifumsg(uid)
    local v = response_queue[uid]
    if v then
        local server = v.baifuserver
        if server then
            local temp = baifubox[server] or {}

            for i,msg in ipairs(temp) do
                if msg.id>(v.msgindex.baifuindex or 0) then

                    local pkg = {}
                    local box = {}
                    local data = {}
                    pkg.box = box

                    box.c        = 'msg'
                    box.m        = 'baifumsg'
                    box.data     = data
                    data.errcode = 0
                    data.errmsg  = ""
                    data.data    = { msg = msg }

                    v.foo(true, pkg)
                    return true
                end
            end
        end
    end
    return false
end


local function friendapply(uid)
    if friendapplybox[uid] and #friendapplybox[uid] > 0 then
        local msg = table.remove(friendapplybox[uid], 1)

        local v = response_queue[uid]
        if v then
            local pkg = {}
            local box = {}
            local data = {}
            pkg.box = box

            box.c        = 'msg'
            box.m        = 'friendapply'
            box.data     = data
            data.errcode = 0
            data.errmsg  = ""
            data.data    = { user = msg }
            v.foo(true, pkg)
            return true
        end
    end

    return false
end


local function friendapplyagree(uid)
    if friendagreebox[uid] and #friendagreebox[uid] > 0 then
        local msg = table.remove(friendagreebox[uid], 1)

        local v = response_queue[uid]
        if v then
            local pkg = {}
            local box = {}
            local data = {}
            pkg.box = box

            box.c        = 'msg'
            box.m        = 'applyagree'
            box.data     = data
            data.errcode = 0
            data.errmsg  = ""
            data.data    = { user = msg }
            v.foo(true, pkg)
            return true
        end
    end

    return false
end

local function givecoin2user(uid)
    if givecoinbox[uid] and #givecoinbox[uid] > 0 then
        local msg = table.remove(givecoinbox[uid], 1)

        local v = response_queue[uid]
        if v then
            local pkg = {}
            local box = {}
            local data = {}
            pkg.box = box

            box.c        = 'msg'
            box.m        = 'givecoin'
            box.data     = data
            data.errcode = 0
            data.errmsg  = ""
            data.data    = { msg = msg }
            v.foo(true, pkg)
            return true
        end
    end

    return false
end

local function friendmsg(uid)
    if friendbox[uid] and #friendbox[uid] > 0 then
        local msg = table.remove(friendbox[uid], 1)

        local v = response_queue[uid]
        if v then
            if msg.id > (v.msgindex.friendindex or 0) then
                local pkg = {}
                local box = {}
                local data = {}
                pkg.box = box

                box.c        = 'msg'
                box.m        = 'mailmsg'
                box.data     = data
                data.errcode = 0
                data.errmsg  = ""
                data.data    = { msg = msg }
                v.foo(true, pkg)
                return true
            end
        end
    end

    return false
end

local function response()
    skynet.error('消息中心  response')
    while true do
        for k, v in pairs(response_queue) do
            if sendmail(k) then
                response_queue[k] = nil
            elseif sendclubmsg(k) then
                response_queue[k] = nil
            elseif sendrecruitmsg(k) then
                response_queue[k] = nil
            elseif sendarenamsg(k) then
                response_queue[k] = nil
            elseif sendbaifumsg(k) then
                response_queue[k] = nil
            elseif friendapply(k) then
                response_queue[k] = nil
            elseif friendapplyagree(k) then
                response_queue[k] = nil
            elseif givecoin2user(k) then
                response_queue[k] = nil
            elseif friendmsg(k) then
                response_queue[k] = nil
            end
        end
        skynet.sleep(10)
    end
end

function CMD.come(uid)
    skynet.error("welcom to msgd ", uid)
    onlineusers[uid] = true
    mailbox[uid] = {}
    friendapplybox[uid] = {}
    friendagreebox[uid] = {}
    friendbox[uid] = {}
    return "ok"
end

function CMD.bye(uid)
    onlineusers[uid] = nil
    mailbox[uid] = nil
    friendapplybox[uid] = nil
    friendbox[uid] = nil
    local v = response_queue[uid]
    if v then
        local pkg = {}
        v.foo(true, pkg)
        response_queue[uid] = nil
    end
    return "ok"
end

--发送邮件消息
function CMD.sendmail(receiver, mail)
    receiver = checkint(receiver)
    if not onlineusers[receiver] then
        return
    end
    local temp = mailbox[receiver] or {}
    table.insert(temp, mail)
    mailbox[receiver] = temp
end

function CMD.sendclubmsg(clubid, msg)
    DEBUG("sendclubmsg = ", clubid, " msg = ", DUMP(msg))
    clubid = checkint(clubid)
    local temp = clubbox[clubid] or {}
    table.insert(temp, msg)
    local l=#temp
    if l>=50 then
        temp = table.slice(temp, 50, -1)
    end
    DEBUG("sendclubmsg temp = ", DUMP(temp))
    clubbox[clubid] = temp
end

function CMD.sendrecruitmsg(serverid, msg)
    local temp = recruitbox[serverid] or {}
    table.insert(temp, msg)
    local l=#temp
    if l>=50 then
        temp = table.slice(temp, 50, -1)
    end
    recruitbox[serverid] = temp
end

function CMD.sendarenamsg(server, msg)
    local temp = arenabox[server] or {}
    table.insert(temp, msg)
    local l=#temp
    if l>=50 then
        temp = table.slice(temp, 50, -1)
    end
    arenabox[server] = temp
end



function CMD.sendbaifumsg(server, msg)
    local temp = baifubox[server] or {}
    table.insert(temp, msg)
    local l=#temp
    if l>=50 then
        temp = table.slice(temp, 50, -1)
    end
    baifubox[server] = temp
end


function CMD.applyfriend(receiver, msg)
    receiver = checkint(receiver)
    if not onlineusers[receiver] then
        return
    end
    local temp = friendapplybox[receiver] or {}
    table.insert(temp, msg)
    friendapplybox[receiver] = temp
    return "ok"
end

--申请好友同意
function CMD.applyagree(receiver, msg)
    receiver = checkint(receiver)
    if not onlineusers[receiver] then
        return
    end
    local temp = friendagreebox[receiver] or {}
    table.insert(temp, msg)
    friendagreebox[receiver] = temp
    return "ok"
end

function CMD.givecoin(receiver, msg)
    receiver = checkint(receiver)
    if not onlineusers[receiver] then
        return
    end
    local temp = givecoinbox[receiver] or {}
    table.insert(temp, msg)
    givecoinbox[receiver] = temp
    return "ok"
end

--私聊消息
function CMD.send2friend(receiver, msg)
    receiver = checkint(receiver)
    if not onlineusers[receiver] then
        return
    end
    local temp = friendbox[receiver] or {}
    table.insert(temp, msg)
    friendbox[receiver] = temp
    return "ok"
end

skynet.start(function()
    skynet.dispatch("lua", function(session, source, cmd, ...)
        skynet.error("msgd dispatch", cmd)

        if cmd == "get" then
            local uid, msgindex, clubid, serverid, arenaserver, baifuserver = ...
            skynet.error("uid=", uid, " 加入到消息中心 ", type(uid), cjson.encode(msgindex), clubid, serverid)

            msgindex.mailindex = checkint(msgindex.mailindex)
            msgindex.clubindex = checkint(msgindex.clubindex)
            msgindex.recruitindex = checkint(msgindex.recruitindex)
            msgindex.arenaindex = checkint(msgindex.arenaindex)
            msgindex.baifuindex = checkint(msgindex.baifuindex)
            msgindex.applyindex = checkint(msgindex.applyindex)
            msgindex.agreeindex = checkint(msgindex.agreeindex)
            msgindex.giveindex  = checkint(msgindex.giveindex)
            msgindex.friendindex = checkint(msgindex.friendindex)

            clubid = clubid or 0

            if uid then
                response_queue[uid] = {
                    foo = skynet.response(), msgindex = msgindex, clubid = clubid, arenaserver=arenaserver, serverid=serverid, baifuserver=baifuserver
                }
            end
        else
            local f = assert(CMD[cmd])
            skynet.ret(skynet.pack(f(...)))
        end
    end)
    skynet.fork(response)

    collectgarbage()
    skynet.register ".msgd"
    skynet.error("邮件服务动完成")
end)
