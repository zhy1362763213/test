local skynet = require "skynet"
local redishelper = require "redishelper"
local keysutils   = require "keysutils"
local dateutils   = require "dateutils"
local utils       = require "utils"
local appname     = require "settings".appname

local skynet_node_name = ...
require "skynet.manager"
local CMD = {}

local scritps = [[
    redis.call('zadd', ARGV[1], ARGV[3], ARGV[2])
    redis.call('expire', ARGV[1], ARGV[4])
    return "ok"
]]

--挑战成功
function CMD.success(uid, server, hm)
    local k = keysutils.boss_rank_key(appname, server, dateutils.getday())
    redishelper.exec("eval", uid, scritps, 4, "key", "member", "socre", "ex", k, uid, hm, 86400)
    return "ok"
end

--获取每日咸王我的伤害
function CMD.loadmyharm(uid, server)
    local k = keysutils.boss_rank_key(appname, server, dateutils.getday())
    return redishelper.exec("zscore", uid, k, uid)
end

function CMD.loadrank(uid, server)
    local k = keysutils.boss_rank_key(appname, server, dateutils.getday())
    local res = redishelper.exec("zrevrange", uid, k, 0, 99, "WITHSCORES")
    local list = utils.redis_pack(res)
    return list
end

function CMD.loadmyrank(uid, server)
    local k = keysutils.boss_rank_key(appname, server, dateutils.getday())
    return redishelper.exec("zrank", uid, k, uid) or 0
end



skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        DEBUG("bossd cmd = ", command)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
