local skynet = require "skynet"
local redishelper = require "redishelper"
local mongohelper = require "mongohelper"
local keysutils   = require "keysutils"
local settings    = require "settings"
local dateutils   = require "dateutils"
local utils       = require "utils"
local skynet_node_name = ...

local appname     = settings.appname
require "skynet.manager"
local CMD = {}


--获取七日签到
function CMD.getsignin7(uid)
    local k = keysutils.user_signin7_key(appname, uid)
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    return utils.redis_pack(res)
end


function CMD.signin7(uid, date)
    local k = keysutils.user_signin7_key(appname, uid)
    return redishelper.exec("zadd", uid, k, os.time(), date)
end

local login_scritps = [[
    local n = redis.call('hget', ARGV[1], KEYS[2]) or 0
    n = tonumber(n)
    if n < 30 then
        redis.call('hincrby', ARGV[1], KEYS[2], ARGV[2])
    end
    if n >= 30 then
        redis.call('hmset', ARGV[1], KEYS[2], ARGV[2], KEYS[3], ARGV[3])
    end
    return "ok"
]]

--每日登录成功
function CMD.login(uid)
    local k = keysutils.user_signin_key(appname, uid)
    return redishelper.exec("eval", uid, login_scritps, 3, "key", "login_count", "sign_count", k, 1, 0)
end

--获取签到信息
function CMD.getsignin(uid)
    local k = keysutils.user_signin_key(appname, uid)
    local res = redishelper.exec("hgetall", uid, k)
    return utils.redis_pack(res)
end

function CMD.sign(uid, count)
    local now = os.time()
    local k = keysutils.user_signin_key(appname, uid)
    return redishelper.exec("hincrby", uid, k, "sign_count", count)
end


skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
