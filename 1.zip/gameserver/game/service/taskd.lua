local skynet = require "skynet"
local redishelper = require "redishelper"
local mongohelper = require "mongohelper"
local keysutils   = require "keysutils"
local settings    = require "settings"
local dateutils   = require "dateutils"
local utils       = require "utils"
local skynet_node_name = ...

local appname     = settings.appname
require "skynet.manager"
local CMD = {}


function CMD.login(uid)
    DEBUG("task login =", uid)
    return CMD.addtasknum(uid, 1, 1)
end

local scritps = [[
    redis.call('zadd', ARGV[1], 1, ARGV[4])
    redis.call('expire', ARGV[1], ARGV[6])
    redis.call('incrby', ARGV[2], ARGV[5])
    redis.call('expire', ARGV[2], ARGV[6])
    redis.call('incrby', ARGV[3], ARGV[5])
    redis.call('expire', ARGV[3], ARGV[7])
]]

function CMD.receivetask(uid, id, score)
    local k1 = keysutils.user_task_list_key(appname, uid, dateutils.getday())
    local k2 = keysutils.user_day_taskscore_key(appname, uid, dateutils.getday())
    local k3 = keysutils.user_week_taskscore_key(appname, uid, dateutils.get_weekno())
    local overtime = dateutils.onedayover(os.time())
    local dayex = overtime - os.time()
    local overtime = dateutils.oneweekend(os.time())
    local weekex = overtime - os.time()
    return redishelper.exec("eval", uid, scritps, 7, "k1", "k2", "k3", "id", "score", "dayex", "weekex", k1, k2, k3, id, score, dayex, weekex)
end

local task_scritps = [[
    redis.call('zincrby', ARGV[1], ARGV[3], ARGV[2])
    redis.call('expire', ARGV[1], ARGV[4])
]]

function CMD.addtasknum(uid, id, num)
    local k = keysutils.user_task_num_key(appname, uid, dateutils.getday())
    local overtime = dateutils.onedayover(os.time())
    local dayex = overtime - os.time()
    return redishelper.exec("eval", uid, task_scritps, 4, "k", "id", "num", "ex", k, id, num, dayex)
end

function CMD.receivedaily(uid, id)
    local k = keysutils.user_daily_task_key(appname, uid, dateutils.getday())
    local overtime = dateutils.onedayover(os.time())
    local dayex = overtime - os.time()
    return redishelper.exec("set", uid, k, id, "ex", dayex)
end

function CMD.receiveweekly(uid, id)
    local k = keysutils.user_weekly_task_key(appname, uid, dateutils.get_weekno())
    local overtime = dateutils.oneweekend(os.time())
    local weekex = overtime - os.time()
    return redishelper.exec("set", uid, k, id, "ex", weekex)
end

local load_scritps = [[
    local tasks = redis.call('zrevrange', ARGV[1], 0, -1, "WITHSCORES") or {}
    local list = redis.call('zrevrange', ARGV[2], 0, -1, "WITHSCORES") or {}
    local day_score = redis.call('get', ARGV[3]) or 0
    local week_score = redis.call('get', ARGV[4]) or 0
    local dailyid = redis.call('get', ARGV[5]) or 0
    local weeklyid = redis.call('get', ARGV[6]) or 0
    return {tasks, list, day_score, week_score, dailyid, weeklyid}
]]

function CMD.loadtask(uid)
    local k1 = keysutils.user_task_num_key(appname, uid, dateutils.getday())
    local k2 = keysutils.user_task_list_key(appname, uid, dateutils.getday())
    local k3 = keysutils.user_day_taskscore_key(appname, uid, dateutils.getday())
    local k4 = keysutils.user_week_taskscore_key(appname, uid, dateutils.get_weekno())
    local k5 = keysutils.user_daily_task_key(appname, uid, dateutils.getday())
    local k6 = keysutils.user_weekly_task_key(appname, uid, dateutils.get_weekno())
    return redishelper.exec("eval", uid, load_scritps, 6, "k1", "k2", "k3", "k4", "k5", "k6", k1, k2, k3, k4, k5, k6)
end

skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        DEBUG("taskd cmd = ", command)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
