local skynet = require "skynet"
local mc           = require "skynet.multicast"
local table_insert = table.insert

local scene_id = ...
scene_id = math.floor(tonumber(scene_id))

local CMD = {}
local channel

function CMD.join_chat(agent)
    local ok = pcall(skynet.call, agent, "lua", "listen_chat", 'world_channels', skynet.self(), channel.channel)
    return "ok"
end

function CMD.sendmsg(cmd)
    channel:publish(cmd)
    return "ok"
end

local init = function()
    channel = mc.new()
    return "ok"
end

skynet.start(function()
    init()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
end)
