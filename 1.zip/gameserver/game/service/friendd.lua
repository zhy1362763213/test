local skynet = require "skynet"
local redishelper = require "redishelper"
local mongohelper = require "mongohelper"
local keysutils   = require "keysutils"
local settings     = require "settings"
local dateutils   = require "dateutils"
local utils       = require "utils"
local skynet_node_name = ...
require "skynet.manager"
local CMD = {}



--获取我的好友
function CMD.loadfriends(uid)
    local ret = mongohelper.find(settings.friend_mongodb_key.tname, settings.friend_mongodb_key.cname, {uid=uid})
    local friends = {}
    for i,v in ipairs(ret) do
        table.insert(friends, {friendid = v.friendid, status = v.status})
    end
    return friends
end


function CMD.loadfriendapply(uid)
    local ret = mongohelper.find(settings.friend_apply_mongodb_key.tname, settings.friend_apply_mongodb_key.cname, {friendid=uid, status=0})
    local temps = {}
    for i,v in ipairs(ret) do
        table.insert(temps, v.uid)
    end
    return temps
end


--申请添加好友
function CMD.apply(myid, friendid)
    return mongohelper.insert(settings.friend_apply_mongodb_key.tname, settings.friend_apply_mongodb_key.cname, {uid=myid, friendid=friendid, status=0, created_at=dateutils.get_datetime()})
end

function CMD.checkapply(myid, friendid)
    return mongohelper.findOne(settings.friend_apply_mongodb_key.tname, settings.friend_apply_mongodb_key.cname, {uid=myid, friendid=friendid, status=0})
end

--获取申请添加好友
function CMD.loadapply(myid)
    local ret = mongohelper.find(settings.friend_apply_mongodb_key.tname, settings.friend_apply_mongodb_key.cname, {uid=myid, status=0})
    local temps = {}
    for i,v in ipairs(ret) do
        table.insert(temps, v)
    end
    return temps
end

--同意填加好友
function CMD.agree(myid, friendid, status)
    mongohelper.upsert(settings.friend_apply_mongodb_key.tname, settings.friend_apply_mongodb_key.cname, {["$set"]={status=status, updated_at=dateutils.get_datetime()}}, {
        ['$or'] = {
            {uid=friendid, friendid=myid, status=0},
            {uid=myid, friendid=friendid, status=0}
        }
    })
    return "ok"
end


function CMD.opagree(myid, status)
    return mongohelper.upsert(settings.friend_apply_mongodb_key.tname, settings.friend_apply_mongodb_key.cname, {["$set"]={status=status, updated_at=dateutils.get_datetime()}}, {friendid=myid, status=0})
end

--添加好友
function CMD.addfriend(myid, friendid)
    return mongohelper.batch_insert(
            settings.friend_mongodb_key.tname,
            settings.friend_mongodb_key.cname,
            {
                {uid=myid, friendid=friendid, status=0, created_at=dateutils.get_datetime()},
                {uid=friendid, friendid=myid, status=0, created_at=dateutils.get_datetime()}
            }
        )
end

--拉黑好友
function CMD.black(myid, friendid)
    return mongohelper.upsert(settings.friend_mongodb_key.tname, settings.friend_mongodb_key.cname, {["$set"]={status=1, uid=myid, friendid=friendid, updated_at=dateutils.get_datetime()}}, {uid=myid, friendid=friendid, status=0})
end

--取消拉黑好友
function CMD.delblack(myid, friendid)
    return mongohelper.upsert(settings.friend_mongodb_key.tname, settings.friend_mongodb_key.cname, {["$set"]={status=0, uid=myid, friendid=friendid, updated_at=dateutils.get_datetime()}}, {uid=myid, friendid=friendid, status=1})
end

--删除好友
function CMD.delete(myid, friendid)
    return mongohelper.del(settings.friend_mongodb_key.tname, settings.friend_mongodb_key.cname, {uid=myid, friendid=friendid})
end


function CMD.getrefreshtime(uid)
    local k = keysutils.friend_refreshtime_key(settings.appname, uid)
    return redishelper.exec("get", uid, k)
end

function CMD.updaterefreshtime(uid)
    local k = keysutils.friend_refreshtime_key(settings.appname, uid)
    return redishelper.exec("set", uid, k, os.time())
end


function CMD.loadfriendcoin(uid)
    local k1 = keysutils.friend_give_coin(settings.appname, uid, dateutils.getday())
    local res1 = redishelper.exec("zrange", uid, k1, 0, -1 , "WITHSCORES")
    local k2 = keysutils.friend_receive_coin(settings.appname, uid, dateutils.getday())
    local res2 = redishelper.exec("zrange", uid, k2, 0, -1 , "WITHSCORES")
    return utils.redis_pack(res1), utils.redis_pack(res2)
end


local give_scripts = [[
    redis.call('zadd', ARGV[1], 1, ARGV[4])
    redis.call('expire', ARGV[1], tonumber(ARGV[6]))
    redis.call('zadd', ARGV[2], ARGV[5], ARGV[3])
    redis.call('expire', ARGV[2], tonumber(ARGV[6]))
    return "ok"
]]

function CMD.givecoin(giveid, receiveid, coin)
    local k1 = keysutils.friend_give_coin(settings.appname, giveid, dateutils.getday())
    local k2 = keysutils.friend_receive_coin(settings.appname, receiveid, dateutils.getday())
    local ex = dateutils.getdayex(os.time())
    return redishelper.exec("eval", giveid, give_scripts, 6, "k1", "k2","giveid", "receiveid", "coin", "ex", k1, k2, giveid, receiveid, coin, ex)
end

function CMD.receivecoin(receiveid, giveid)
    local k = keysutils.friend_receive_coin(settings.appname, receiveid, dateutils.getday())
    return redishelper.exec("zadd", receiveid, k, 0, giveid)
end


skynet.start(function()
    -- local ok = mongohelper.del(settings.friend_apply_mongodb_key.tname, settings.friend_apply_mongodb_key.cname, {uid=434026, friendid=831962})
    -- DEBUG(" agree del ok = ", ok)
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
