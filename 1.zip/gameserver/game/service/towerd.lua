local skynet = require "skynet"
local redishelper = require "redishelper"
local keysutils   = require "keysutils"
local dateutils   = require "dateutils"
local utils       = require "utils"
local settings     = require "settings"
local appname = settings.appname

local skynet_node_name = ...
require "skynet.manager"
local CMD = {}

--挑战成功
function CMD.success(uid, server)
    DEBUG("tower success = ", uid, " server = ", server)
    local k = keysutils.tower_rank_key(appname, server)
    return redishelper.exec("zincrby", uid, k, 1, uid)
end

function CMD.loadrank(uid, server)
    local k = keysutils.tower_rank_key(appname, server)
    local res = redishelper.exec("zrevrange", uid, k, 0, 99, "WITHSCORES")
    local list = utils.redis_pack(res)
    return list
end


function CMD.loadmyrank(uid, server)
    local k = keysutils.tower_rank_key(appname, server)
    return redishelper.exec("zrank", uid, k, uid) or 0
end

--获取咸将塔宝箱领取状态 1已领取 0未领取
function CMD.gettowerstatus(uid, stage)
    local k = keysutils.user_towerstatus_key(settings.appname, uid)
    return redishelper.exec("getbit", uid, k, stage)
end

function CMD.settowerstatus(uid, stage)
    local k = keysutils.user_towerstatus_key(settings.appname, uid)
    return redishelper.exec("setbit", uid, k, stage, 1)
end


skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
