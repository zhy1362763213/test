local skynet = require "skynet"
local mongohelper = require "mongohelper"
local keysutils   = require "keysutils"
local dateutils   = require "dateutils"
local utils       = require "utils"
local redis       = require 'skynet.db.redis'
local mongo       = require 'skynet.db.mongo'
local settings    = require "settings"
local maillogic   = require "maillogic"
local cjson       = require "cjson"
local redishelper = require "redishelper"
local skynet_node_name = ...
require "skynet.manager"
require "functions"

local CMD = {}

function CMD.checkreceive(uid, code)
    local k = keysutils.user_game_code_key(settings.appname, uid)
    return redishelper.exec("zscore", uid, k, code)
end

function CMD.loadbycode(code)
    local res = mongohelper.findOne(settings.game_code_mongodb_key.tname, settings.game_code_mongodb_key.cname, {code=code})
    return res
end

function CMD.receive(uid, code)
    local k = keysutils.user_game_code_key(settings.appname, uid)
    redishelper.exec("zadd", uid, k, os.time(), code)
    mongohelper.upsert(settings.game_code_mongodb_key.tname, settings.game_code_mongodb_key.cname, {["$inc"]={num=1}}, {code=code})
    return "ok"
end

skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
