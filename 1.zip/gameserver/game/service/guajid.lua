local skynet = require "skynet"
local redishelper = require "redishelper"
local keysutils   = require "keysutils"
local settings    = require "settings"
local dateutils   = require "dateutils"
local utils       = require "utils"
local skynet_node_name = ...
require "skynet.manager"
local CMD = {}


function CMD.getinfo(uid)
    local k = keysutils.user_guaji_info_key(settings.appname, uid)
    local res = redishelper.exec("hgetall", uid, k)
    return utils.redis_pack(res)
end

function CMD.getreceiveinfo(uid)
    local k = keysutils.user_guaji_reward_key(settings.appname, uid)
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    return utils.redis_pack(res)
end

function CMD.save(uid, data)
    local k = keysutils.user_guaji_info_key(settings.appname, uid)
    return redishelper.exec("hmset", uid, k, data)
end

function CMD.receive(uid, id)
    local k = keysutils.user_guaji_reward_key(settings.appname, uid)
    return redishelper.exec("zadd", uid, k, os.time(), id)
end

skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
