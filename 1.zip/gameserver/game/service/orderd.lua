local skynet     = require "skynet"
local cjson      = require "cjson"
local dateutils  = require "dateutils"
local redis      = require "skynet.db.redis"
local settings   = require "settings"
local keysutils  = require "keysutils"
local mongohelper  = require "mongohelper"
local skynet_node_name = ...

--[[
    关于充值的服务都调用这个服务
]]

require "functions"

require "skynet.manager"

local CMD = {}

function CMD.get(order_no)
    return mongohelper.findOne(settings.recharge_mongodb_key.tname, settings.recharge_mongodb_key.cname, {order_no=order_no, complete=0})
end

function CMD.complete(order_no)
    return mongohelper.upsert(settings.recharge_mongodb_key.tname, settings.recharge_mongodb_key.cname, {["$set"]={complete=1, completed_at=dateutils.get_datetime()}}, {order_no=order_no, complete=0})
end

skynet.start(function()
    skynet.dispatch("lua", function(session, source, cmd, ...)
        local f = assert(CMD[cmd])
        skynet.ret(skynet.pack(f(...)))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
