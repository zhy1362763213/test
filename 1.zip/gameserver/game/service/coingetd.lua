local skynet = require "skynet"
local redishelper = require "redishelper"
local keysutils   = require "keysutils"
local dateutils   = require "dateutils"
local utils       = require "utils"
local appname     = require "settings".appname

local skynet_node_name = ...
require "skynet.manager"
local CMD = {}

local scritps = [[
    redis.call('incrby', ARGV[1], ARGV[2])
    redis.call('expire', ARGV[1], ARGV[3])
    return "ok"
]]


function CMD.get(uid)
    local k = keysutils.user_coinget_key(appname, uid, dateutils.getday())
    local c = redishelper.exec("get", uid, k) or 0
    return c
end


function CMD.incrby(uid, num)
    local k = keysutils.user_coinget_key(appname, uid, dateutils.getday())
    return redishelper.exec("eval", uid, scritps, 3, "k", "n", "ex", k, num, 86400)
end


skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
