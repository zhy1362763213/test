local skynet = require "skynet"
local redishelper = require "redishelper"
local keysutils   = require "keysutils"
local settings    = require "settings"
local dateutils   = require "dateutils"
local utils       = require "utils"
local mongohelper = require "mongohelper"
local skynet_node_name = ...
require "skynet.manager"
local CMD = {}
--1008: 你成功击败了%s，抢走了%s的咸臣%s现在%s已经成为了你的咸臣，每次%s领取挂机奖励时会向你上缴%s的挂机金币收益。

--1009: 你尝试征服%s，但是挑战%s的咸主%s失败了，战力的提升有助于增加胜算哦～

--10010: 你成功击败了%s，现在%s已经成为了你的咸臣，每次%s领取挂机奖励时会向你上缴%s%的挂机金币收益。

--10011: 你尝试征服%s，但是失败了，战力的提升有助于增加胜算哦～

--发送战报给我自己
function CMD.sendcombatreport2myself(tp, my, user, owner)
    local content
    local params = {}
    if tp == "success" then
        if owner~=nil then
            content = 1008
            table.insert(params, owner.nickname)
            table.insert(params, owner.nickname)
            table.insert(params, user.nickname)
            table.insert(params, user.nickname)
            table.insert(params, user.nickname)
        else
            content = 10010
            table.insert(params, user.nickname)
            table.insert(params, user.nickname)
            table.insert(params, user.nickname)
        end
    else
        if owner~=nil then
            content = 1009
            table.insert(params, user.nickname)
            table.insert(params, user.nickname)
            table.insert(params, owner.nickname)
        else
            content = 10011
            table.insert(params, user.nickname)
        end
    end
    assert(content ~= nil)
    local mail = {}
    local id = skynet.call(".id_service", "lua", "genid", "combatreport")
    mail.id=id
    mail.temp="Y"
    mail.receiver=my.uid
    mail.params=params
    mail.status=0 --未读
    mail.title=1007
    mail.content=content
    mail.report = owner or user
    mail.created_at=dateutils.get_datetime()
    local ok = mongohelper.insert(settings.roommail_mongodb_key.tname, settings.roommail_mongodb_key.cname, mail)
    skynet.send(".msgd", "lua", "sendcombatreport", my.uid, mail)
    return "ok"
end


--10012: %s成功击败了你的咸主%s，从%s手中抢走了你

--10013: %s尝试从你的咸主%s手中抢走你，但是由于战力悬殊失败了

--10014: %s成功击败了你，%s成为了你的咸主

--10015: %s尝试把你抓为咸臣，但是由于战力悬殊失败了



--发送战报给我对方
function CMD.sendcombatreport2user(tp, my, user, owner)
    local content
    local params = {}
    if tp == "success" then
        if owner~=nil then
            content = 10012
            table.insert(params, my.nickname)
            table.insert(params, owner.nickname)
            table.insert(params, owner.nickname)
        else
            content = 10014
            table.insert(params, my.nickname)
            table.insert(params, my.nickname)
        end
    else
        if owner~=nil then
            content = 10013
            table.insert(params, my.nickname)
            table.insert(params, owner.nickname)
        else
            content = 10015
            table.insert(params, my.nickname)
        end
    end
    assert(content ~= nil)
    local mail = {}
    local id = skynet.call(".id_service", "lua", "genid", "combatreport")
    mail.id=id
    mail.temp="Y"
    mail.receiver=user.uid
    mail.params=params
    mail.status=0 --未读
    mail.title=1007
    mail.content=content
    mail.report = my
    mail.created_at=dateutils.get_datetime()
    local ok = mongohelper.insert(settings.roommail_mongodb_key.tname, settings.roommail_mongodb_key.cname, mail)
    skynet.send(".msgd", "lua", "sendcombatreport", user.uid, mail)
    return "ok"
end

--10016: %s成功击败了你，%s抢走了你的咸臣%s
--10017: %s尝试抢走你的咸臣%s，但是由于战力悬殊失败了
--发送战报给我咸主
function CMD.sendcombatreport2owner(tp, my, user, owner)
    local content
    local params = {}
    if tp == "success" then
        if owner~=nil then
            content = 10016
            table.insert(params, my.nickname)
            table.insert(params, my.nickname)
            table.insert(params, user.nickname)
        end
    else
        if owner~=nil then
            content = 10017
            table.insert(params, my.nickname)
            table.insert(params, user.nickname)
        end
    end
    assert(content ~= nil)
    local mail = {}
    local id = skynet.call(".id_service", "lua", "genid", "combatreport")
    mail.id=id
    mail.temp="Y"
    mail.receiver=owner.uid
    mail.params=params
    mail.status=0 --未读
    mail.title=1007
    mail.content=content
    mail.report = my
    mail.created_at=dateutils.get_datetime()
    local ok = mongohelper.insert(settings.roommail_mongodb_key.tname, settings.roommail_mongodb_key.cname, mail)
    skynet.send(".msgd", "lua", "sendcombatreport", owner.uid, mail)
    return "ok"
end

local scritps = [[
    local n = redis.call('incr', ARGV[1])
    redis.call('expire', ARGV[1], ARGV[2])
    return n
]]

function CMD.incrrobnum(uid)
    local k = keysutils.user_robsaltpot_num_key(settings.appname, uid, dateutils.getday())
    return redishelper.exec("eval", uid, scritps, 2, "k", "ex", k, dateutils.getdayex())
end

function CMD.robsaltpot(uid, member, score)
    local k = keysutils.user_robsaltpot_list_key(settings.appname, uid)
    return redishelper.exec("zadd", uid, k, score, member)
end

function CMD.getsaltpotnum(uid)
    local k = keysutils.user_robsaltpot_lis_key(settings.appname, uid)
    return redishelper.exec("zcard", uid, k)
end

function CMD.getsaltpotlist(uid)
    local k = keysutils.user_robsaltpot_lis_key(settings.appname, uid)
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    return utils.redis_pack(res)
end

function CMD.removesaltpot(uid, member)
    local k = keysutils.user_robsaltpot_lis_key(settings.appname, uid)
    return redishelper.exec("zrem", uid, k, member)
end

skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
