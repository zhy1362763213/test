local skynet = require "skynet"
local redishelper = require "redishelper"
local keysutils   = require "keysutils"
local settings     = require "settings"
local dateutils   = require "dateutils"
local utils       = require "utils"
local skynet_node_name = ...
require "skynet.manager"
local CMD = {}

local scritps = [[
    local model = redis.call('hgetall', ARGV[1])
    local share_num = redis.call('get', ARGV[2])
    local adv_num = redis.call('get', ARGV[3])
    return {model, share_num, adv_num}
]]

function CMD.loadhuoba(uid)
    local k1 = keysutils.user_huoba_model_key(settings.appname, uid)
    local k2 = keysutils.user_huoba_share_key(settings.appname, uid, dateutils.getday())
    local k3 = keysutils.user_huoba_adv_key(settings.appname, uid, dateutils.getday())
    return redishelper.exec("eval", uid, scritps, 3, "k1","k2","k3", k1, k2, k3)
end

function CMD.save(uid, data)
    local k = keysutils.user_huoba_model_key(settings.appname, uid)
    return redishelper.exec("hmset", uid, k, data)
end

function CMD.share(uid, num)
    local k = keysutils.user_huoba_share_key(settings.appname, uid, dateutils.getday())
    return redishelper.exec("set", uid, k, num, "ex", dateutils.getdayex())
end

function CMD.lookadv(uid, num)
    local k = keysutils.user_huoba_adv_key(settings.appname, uid, dateutils.getday())
    return redishelper.exec("set", uid, k, num, "ex", dateutils.getdayex())
end

skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
