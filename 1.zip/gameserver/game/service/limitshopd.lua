local skynet = require "skynet"
local redishelper = require "redishelper"
local keysutils   = require "keysutils"
local settings     = require "settings"
local dateutils   = require "dateutils"
local utils       = require "utils"
local skynet_node_name = ...
require "skynet.manager"
local CMD = {}


--购买限购
function CMD.buy(uid, id)
    local k = keysutils.user_limitshop_key(settings.appname, uid)
    return redishelper.exec("zincrby", uid, k, 1, id)
end


function CMD.loadbuyinfo(uid)
    local k = keysutils.user_limitshop_key(settings.appname, uid)
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    return utils.redis_pack(res)
end

skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
