local skynet = require "skynet"
local redishelper = require "redishelper"
local keysutils   = require "keysutils"
local settings     = require "settings"
local dateutils   = require "dateutils"
local utils       = require "utils"
local skynet_node_name = ...
require "skynet.manager"
local CMD = {}

--竞技场每日奖励邮件
function CMD.sendarenarewardmail()
end


skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
