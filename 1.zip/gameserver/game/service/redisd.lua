local skynet = require "skynet"
local redishelper = require "redishelper"
local keysutils   = require "keysutils"
local settings    = require "settings"
local dateutils   = require "dateutils"
local utils       = require "utils"
local skynet_node_name = ...
require "skynet.manager"
local CMD = {}

function CMD.chooseserver(openid, serverid)
    local k = keysutils.user_choose_server_key(settings.appname, openid)
    return redishelper.exec("set", nil, k, serverid)
end


function CMD.getserver(openid)
    local k = keysutils.user_choose_server_key(settings.appname, openid)
    return redishelper.exec("get", nil, k)
end


function CMD.getupdatenicknamenum(uid)
    local k = keysutils.user_update_nickname_num_key(settings.appname, uid)
    return redishelper.exec("get", uid, k) or 0
end


function CMD.incrupdatenicknamenum(uid)
    local k = keysutils.user_update_nickname_num_key(settings.appname, uid)
    return redishelper.exec("incr", uid, k)
end

skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
