local skynet = require "skynet"
local redishelper = require "redishelper"
local keysutils   = require "keysutils"
local settings     = require "settings"
local dateutils   = require "dateutils"
local utils       = require "utils"
local skynet_node_name = ...
require "skynet.manager"
local CMD = {}


--购买特惠礼包
function CMD.buydailydeal(uid, id, daylimit)
    local k = keysutils.user_buydailydeal_key(settings.appname, uid)
    return redishelper.exec("zadd", uid, k, daylimit, id)
end

--领取每日特惠礼包
function CMD.receive(uid, id)
    local k = keysutils.user_receivedailydeal_key(settings.appname, uid)
    return redishelper.exec("zadd", uid, k, os.time(), id..":"..dateutils.getday())
end

function CMD.getinfo(uid)
    local k = keysutils.user_buydailydeal_key(settings.appname, uid)
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    local buyinfo = utils.redis_pack(res)
    local k = keysutils.user_receivedailydeal_key(settings.appname, uid)
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    local receiveinfo =  utils.redis_pack(res)
    return buyinfo, receiveinfo
end


skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
