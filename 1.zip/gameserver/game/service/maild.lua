local skynet = require "skynet"
local mongohelper = require "mongohelper"
local keysutils   = require "keysutils"
local dateutils   = require "dateutils"
local utils       = require "utils"
local redis       = require 'skynet.db.redis'
local mongo       = require 'skynet.db.mongo'
local settings    = require "settings"
local maillogic   = require "maillogic"
local cjson       = require "cjson"
local redishelper = require "redishelper"
local skynet_node_name = ...
require "skynet.manager"
require "functions"
local rediscli
local lasttime

local CMD = {}

--发送邮件
function CMD.sendmail(uid, mail)
    local ok = mongohelper.insert(settings.mail_mongodb_key.tname, settings.mail_mongodb_key.cname, mail)
    local ok = skynet.send(".msgd", "lua", "sendmail", uid, mail)
    return "ok"
end

function CMD.loadmail(uid)
    local mails = mongohelper.find(settings.mail_mongodb_key.tname, settings.mail_mongodb_key.cname, {receiver=uid}, nil, {status=1, id=-1})
    return mails
end


function CMD.readmail(id, data)
    return mongohelper.upsert(settings.mail_mongodb_key.tname, settings.mail_mongodb_key.cname, {["$set"]=data}, {id=id})
end

function CMD.readallmail(uid, tp, data)
    return mongohelper.updateMany(settings.mail_mongodb_key.tname, settings.mail_mongodb_key.cname, {["$set"]=data}, {receiver=uid, tp=tp})
end

function CMD.delone(id)
    return mongohelper.del(settings.mail_mongodb_key.tname, settings.mail_mongodb_key.cname, {id=id})
end

function CMD.delreadall(uid, tp)
    return mongohelper.del(settings.mail_mongodb_key.tname, settings.mail_mongodb_key.cname, {receiver=uid, tp=tp, status=1})
end


function CMD.loadroommail(uid)
    local mails = {}
    mails.mails1 = mongohelper.find(settings.roommail_mongodb_key.tname, settings.roommail_mongodb_key.cname, {receiver=uid, tp=1}, nil, {id=-1})
    mails.mails2 = mongohelper.find(settings.roommail_mongodb_key.tname, settings.roommail_mongodb_key.cname, {receiver=uid, tp=2}, nil, {id=-1})
    return mails
end

function CMD.readroommailbyid(uid, id)
    return mongohelper.upsert(settings.roommail_mongodb_key.tname, settings.roommail_mongodb_key.cname, {["$set"]={status=1}}, {receiver=uid, id=id})
end

function CMD.readroommailall(uid)
    return mongohelper.updateMany(settings.roommail_mongodb_key.tname, settings.roommail_mongodb_key.cname, {["$set"]={status=1}}, {receiver=uid})
end

function CMD.delroommailbyid(uid, id)
    return mongohelper.del(settings.roommail_mongodb_key.tname, settings.roommail_mongodb_key.cname, {receiver=uid, id=id})
end

function CMD.delroommail(uid)
    return mongohelper.del(settings.roommail_mongodb_key.tname, settings.roommail_mongodb_key.cname, {receiver=uid})
end

function CMD.checksend(uid)
    local k = keysutils.user_mail_daywelfare_key(settings.appname, uid, dateutils.getday())
    return redishelper.exec("get", uid, k)
end

function CMD.baoxiangactivity(uid, rewards)
    local mail = {}
    local id = skynet.call(".id_service", "lua", "genid", "mail")
    mail.id=id
    mail.tp="system"
    mail.sender=10101
    mail.temp="Y"
    mail.receiver=uid
    mail.params={}
    mail.status=0 --未读
    mail.title=10036
    mail.content=10037
    mail.rewards = table.array(rewards)
    mail.created_at=dateutils.get_datetime()
    local ok = mongohelper.insert(settings.mail_mongodb_key.tname, settings.mail_mongodb_key.cname, mail)
    skynet.send(".msgd", "lua", "sendmail", uid, mail)
    return "ok"
end

function CMD.zhaomuactivity(uid, rewards)
    local mail = {}
    local id = skynet.call(".id_service", "lua", "genid", "mail")
    mail.id=id
    mail.tp="system"
    mail.sender=10101
    mail.temp="Y"
    mail.receiver=uid
    mail.params={}
    mail.status=0 --未读
    mail.title=10034
    mail.content=10035
    mail.rewards = table.array(rewards)
    mail.created_at=dateutils.get_datetime()
    local ok = mongohelper.insert(settings.mail_mongodb_key.tname, settings.mail_mongodb_key.cname, mail)
    skynet.send(".msgd", "lua", "sendmail", uid, mail)
    return "ok"
end

function CMD.newusermail(uid)
    local k = keysutils.user_newuser_mail_key(settings.appname, uid, "1")
    local result = redishelper.exec("get", uid, k)
    if not result then
        local mail = {}
        local id = skynet.call(".id_service", "lua", "genid", "mail")
        mail.id=id
        mail.tp="game"
        mail.sender=10101
        mail.temp="Y"
        mail.receiver=uid
        mail.params={}
        mail.status=0 --未读
        mail.title=10050
        mail.content=10051
        mail.rewards = table.array({})
        mail.created_at=dateutils.get_datetime()
        local ok = mongohelper.insert(settings.mail_mongodb_key.tname, settings.mail_mongodb_key.cname, mail)
        skynet.send(".msgd", "lua", "sendmail", uid, mail)
    end
    redishelper.exec("set", uid, k, 1)
    return "ok"
end

--每日福利
function CMD.senddaywelfaremail(uid)
    local k = keysutils.user_mail_daywelfare_key(settings.appname, uid, dateutils.getday())
    local result = redishelper.exec("get", uid, k)
    if not result then
        local mail = {}
        local id = skynet.call(".id_service", "lua", "genid", "mail")
        mail.id=id
        mail.tp="system"
        mail.sender=10101
        mail.temp="Y"
        mail.receiver=uid
        mail.params={}
        mail.status=0 --未读
        mail.title=10026
        mail.content=10026
        mail.rewards = {
            {key="box_lv1", value=10},
            {key="box_lv2", value=2},
            {key="gold", value=288}
        }
        mail.created_at=dateutils.get_datetime()
        local ok = mongohelper.insert(settings.mail_mongodb_key.tname, settings.mail_mongodb_key.cname, mail)
        skynet.send(".msgd", "lua", "sendmail", uid, mail)
    end
    redishelper.exec("set", uid, k, 1, "ex", dateutils.getdayex())
    return "ok"
end

local function do_func(data)
    local mail = {}
    if data.data.type == "arena_day" then
        local id = skynet.call(".id_service", "lua", "genid", "mail")
        mail.id=id
        mail.tp="system"
        mail.sender=10101
        mail.temp="Y"
        mail.receiver=data.data.receiver.uid
        mail.params={data.data.receiver.rank}
        mail.status=0 --未读
        mail.title=10026
        mail.content=10027
        mail.rewards = table.array({})
        mail.created_at=dateutils.get_datetime()
    elseif data.data.type == "arena_week" then
        local id = skynet.call(".id_service", "lua", "genid", "mail")
        mail.id=id
        mail.tp="system"
        mail.sender=10101
        mail.temp="Y"
        mail.receiver=data.data.receiver.uid
        mail.params={data.data.receiver.rank}
        mail.status=0 --未读
        mail.title=10028
        mail.content=10029
        mail.rewards = table.array({})
        mail.created_at=dateutils.get_datetime()
    elseif data.data.type == "admin" then
        if data.data.data.receiver ~= 0 then
            local id = skynet.call(".id_service", "lua", "genid", "mail")
            mail.id=id
            mail.tp="system"
            mail.sender=data.data.data.sender
            mail.temp="N"
            mail.receiver=data.data.data.receiver
            mail.params={}
            mail.status=0 --未读
            mail.title=data.data.data.title
            mail.content=data.data.data.content
            mail.rewards = table.array(data.data.data.rewards)
            mail.created_at=dateutils.get_datetime()
        else
            mail.tp="system"
            mail.sender=data.data.data.sender
            mail.temp="N"
            mail.receiver=0
            mail.params={}
            mail.status=0 --未读
            mail.title=data.data.data.title
            mail.content=data.data.data.content
            mail.rewards = table.array(data.data.data.rewards)
            mail.created_at=dateutils.get_datetime()
            local ok = pcall(skynet.call, ".usercenterd", "lua", "send2all", mail)
            return "ok"
        end
    end
    local ok = mongohelper.insert(settings.mail_mongodb_key.tname, settings.mail_mongodb_key.cname, mail)
    skynet.send(".msgd", "lua", "sendmail", data.data.data.receiver, mail)
    return "ok"
end

local function lpoprpush(queue, queuebakup)
    local script = [[
        local v = redis.call('lpop', ARGV[1])
        if not v then
            return nil
        end
        redis.call('rpush', ARGV[2], v)
        return v
    ]]
    local t = rediscli:eval(script, 2, "k2", "k1", queuebakup, queue)
    return t
end

local function copyback(queue, queuebakup)
    local t = lpoprpush(queue, queuebakup)
    while t do
        t = lpoprpush(queue, queuebakup)
    end
end

skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)

    rediscli = redis.connect(settings.db_cnf[skynet_node_name].redismq_cnf)
    local k1 = settings.mail_queue_key
    local k2 = settings.mail_queue_key_backup
    copyback(k1, k2)
    skynet.fork(function()
        while true do
            if rediscli then
                local res = rediscli:brpoplpush(k1, k2, 10)
                if res then
                    DEBUG(" mail info = ", res)
                    local ok, ret = pcall(cjson.decode, res)
                    if ok then
                        local r = do_func(ret)
                        if r then
                            rediscli:lrem(k2, -1, res)
                        else

                        end
                    end
                end
                if not lasttime or lasttime < os.time() - 10 then
                    lasttime = os.time()
                    rediscli:ping()
                end
            else
                skynet.sleep(1000)
            end
        end
    end)
    collectgarbage()
    skynet.register('.' .. SERVICE_NAME)
end)
