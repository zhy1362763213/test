local skynet = require "skynet"
local redishelper = require "redishelper"
local keysutils   = require "keysutils"
local dateutils   = require "dateutils"
local utils       = require "utils"
local blackmarketlogic = require "blackmarketlogic"
local settings    = require "settings"
local cjson       = require "cjson"

local appname = settings.appname
local skynet_node_name = ...
require "skynet.manager"
local CMD = {}


local function getdayex()
    local overtime = dateutils.onedayover(os.time())
    return overtime - os.time()
end

local function save(uid, t)
    local data = {}
    for k, v in pairs(t) do
        table.insert(data, v)
        table.insert(data, k)
    end
    local k = keysutils.user_blackmarket_discount_key(appname, uid, dateutils.getday())
    redishelper.exec("zadd", uid, k, table.unpack(data))
    redishelper.exec("expire", uid, k, getdayex())
    return "ok"
end

function CMD.save(uid, num, t)
    local k = keysutils.user_blackmarket_refresh_num_key(appname, uid, dateutils.getday())
    redishelper.exec("set", uid, k, num, "ex", getdayex())
    save(uid, t)
    return "ok"
end

function CMD.savediscount(uid, t)
    save(uid, t)
    return "ok"
end


function CMD.loaddiscount(uid)
    local k1 = keysutils.user_blackmarket_refresh_num_key(appname, uid, dateutils.getday())
    local num = redishelper.exec("get", uid, k1)
    num = checkint(num)
    -- if num <= 0 then
    --     local rews = blackmarketlogic.randomdiscount()
    --     CMD.savediscount(uid, rews)
    -- end
    local k2 = keysutils.user_blackmarket_discount_key(appname, uid, dateutils.getday())
    local res = redishelper.exec("zrange", uid, k2, 0, -1, "WITHSCORES")
    local discount = utils.redis_pack(res)
    local k3 = keysutils.user_blackmarket_buy_key(appname, uid, dateutils.getday(), num)
    local res = redishelper.exec("zrange", uid, k3, 0, -1, "WITHSCORES")
    local buy = utils.redis_pack(res)
    return num, discount, buy
end

function CMD.buy(uid, num, id)
    local k = keysutils.user_blackmarket_buy_key(appname, uid, dateutils.getday(), num)
    redishelper.exec("zadd", uid, k, 1, id)
    redishelper.exec("expire", uid, k, getdayex())
    return "ok"
end

skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
