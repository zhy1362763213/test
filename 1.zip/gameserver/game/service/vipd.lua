local skynet = require "skynet"
local redishelper = require "redishelper"
local keysutils   = require "keysutils"
local settings    = require "settings"
local dateutils   = require "dateutils"
local utils       = require "utils"
local skynet_node_name = ...
require "skynet.manager"
local CMD = {}

function CMD.receive(uid, id)
    local k = keysutils.user_vip_benefit_key(settings.appname, uid)
    return redishelper.exec("zadd", uid, k, os.time(), id)
end

function CMD.get(uid)
    local k = keysutils.user_vip_benefit_key(settings.appname, uid)
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    return utils.redis_pack(res)
end

skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
