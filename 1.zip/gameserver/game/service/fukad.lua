local skynet = require "skynet"
local redishelper = require "redishelper"
local keysutils   = require "keysutils"
local settings     = require "settings"
local dateutils   = require "dateutils"
local utils       = require "utils"
local skynet_node_name = ...
require "skynet.manager"
local CMD = {}


--购买福卡
function CMD.buy(uid, fukaid, t)
    local k = keysutils.user_buyfuka_key(settings.appname, uid)
    return redishelper.exec("zadd", uid, k, t, fukaid)
end

--每日领取
function CMD.receive(uid, fukaid, t)
    local k = keysutils.user_receivefuka_key(settings.appname, uid, dateutils.getday())
    return redishelper.exec("zadd", uid, k, t, fukaid)
end

function CMD.getinfo(uid, fukaid, t)
    local k = keysutils.user_buyfuka_key(settings.appname, uid)
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    local buyinfo = utils.redis_pack(res)
    local k = keysutils.user_receivefuka_key(settings.appname, uid, dateutils.getday())
    local res = redishelper.exec("zrange", uid, k, 0, -1, "WITHSCORES")
    local receiveinfo = utils.redis_pack(res)
    return buyinfo, receiveinfo
end

skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
