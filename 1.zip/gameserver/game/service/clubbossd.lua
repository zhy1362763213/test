local skynet = require "skynet"
local redishelper = require "redishelper"
local keysutils   = require "keysutils"
local dateutils   = require "dateutils"
local utils       = require "utils"
local redis       = require 'skynet.db.redis'
local settings     = require "settings"

local skynet_node_name = ...
require "skynet.manager"
require "functions"

local CMD = {}
local rediscli = {}
-- --科技升级
-- function CMD.researchlvup(uid, id, lv)
--     local k = keysutils.club_research_key(appname, uid)
--     return redishelper.exec("zincrby", uid, k, lv, id)
-- end

-- --科技重置
-- function CMD.reset(uid, params)
--     local data = {}
--     for k, v in pairs(params) do
--         table.insert(data, v)
--         table.insert(data, k)
--     end
--     local k = keysutils.club_research_key(settings.appname, uid)
--     return redishelper.exec("zadd", uid, k, table.unpack(data))
-- end


-- local function sendmail(clubid, bossid)
--     skynet.fork(function()
--         local k1 = keysutils.club_bossharmrank_key(settings.appname, clubid, bossid)
--         local res = rediscli:zrange(k1, 0, -1, "WITHSCORES")
--         local ret = utils.redis_pack(res)
--         for k,v in pairs(ret) do
--             local id = skynet.call(".id_service", "lua", "genid", "mail")
--             local mail = {
--                 id=id,
--                 sender="俱乐部",
--                 receiver=uid,
--             }
--             skynet.call(".maild", "lua", "sendmail", {})
--         end
--     end)
-- end

--攻打boss
function CMD.attackboss(uid, clubid, bossid, harm)
    local k = keysutils.club_bossharm_key(settings.appname, clubid, bossid)
    local hm = rediscli:get(k)
    if tonumber(hm) >= 10000 then
        return  1, "俱乐部boss已经被击败" --重复击败
    end
    local k1 = keysutils.club_bossharmrank_key(settings.appname, clubid, bossid)
    rediscli:zincrby(k1, harm, uid)
    local hm = rediscli:incr(k, harm)
    if tonumber(hm) >= 10000 then
        -- sendmail(clubid, bossid)
        return  2, "俱乐部boss已经被击败"
    end
    return 0
end


skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    rediscli = redis.connect(settings.db_cnf[skynet_node_name].redisdb_cnf)

    if not rediscli then
        error(" rediscli 连接失败")
    end

    skynet.fork(function()
        while true do
            if true then
                rediscli:ping()
                skynet.sleep(1000)
            end
        end
    end)
    collectgarbage()
    skynet.register('.' .. SERVICE_NAME)
end)
