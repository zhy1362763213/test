--成就系统
local skynet = require "skynet"
local redishelper = require "redishelper"
local keysutils   = require "keysutils"
local dateutils   = require "dateutils"
local utils       = require "utils"
local settings    = require "settings"

local skynet_node_name = ...
require "skynet.manager"
local CMD = {}

function CMD.incrcomplete(uid, kid, val)
    local k = keysutils.user_achievement_complete_key(settings.appname, uid)
    return redishelper.exec("zincrby", uid, k, val, kid)
end

function CMD.setcomplete(uid, kid, val)
    local k = keysutils.user_achievement_complete_key(settings.appname, uid)
    return redishelper.exec("zadd", uid, k, val, kid)
end

function CMD.get(uid)
    local k = keysutils.user_achievement_complete_key(settings.appname, uid)
    local res = redishelper.exec("zrevrange",  uid, k, 0, -1, "WITHSCORES")
    local d1 = utils.redis_pack(res)

    local k = keysutils.user_achievement_key(settings.appname, uid)
    local res = redishelper.exec("zrevrange", uid, k, 0, -1, "WITHSCORES")
    local d2 = utils.redis_pack(res)
    return d1, d2
end


function CMD.receive(uid, id)
    local k = keysutils.user_achievement_key(settings.appname, uid)
    return redishelper.exec("zadd", uid, k, os.time(), id)
end

skynet.start(function()

    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)
