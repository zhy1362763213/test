return {["101"] ={["name"] ="司马懿",["type"] =2,["haspower"] =1,["nickname"] ="simayi",["normal"] =1010,["skill"] =1011,["passives"] ={
1012,1013,1014}
,["club"] =1,["atk"] =182,["def"] =135,["hp"] =1421,["spd"] =12,["color"] =3,["cardnumber"] =8,["skillawake"] =1015,["passivesawake"] ={
1016,1017,1018}
,["skins"] ={
101,10101,10102}
,["work"] =4,["awakeactivecondition"] =22,["awake"] =21,["sex"] =1},["102"] ={["name"] ="郭嘉",["type"] =2,["haspower"] =1,["nickname"] ="guojia",["normal"] =1020,["skill"] =1021,["passives"] ={
1022,1023,1024}
,["club"] =1,["atk"] =180,["def"] =134,["hp"] =1406,["spd"] =12,["color"] =3,["cardnumber"] =8,["skillawake"] =1025,["passivesawake"] ={
1026,1027,1028}
,["skins"] ={
102,10201,10202}
,["work"] =4,["awakeactivecondition"] =22,["awake"] =21,["sex"] =1},["103"] ={["name"] ="关羽",["type"] =2,["haspower"] =1,["nickname"] ="guanyu",["normal"] =1030,["skill"] =1031,["passives"] ={
1032,1033,1034}
,["club"] =2,["atk"] =161,["def"] =160,["hp"] =1994,["spd"] =12,["color"] =3,["cardnumber"] =8,["skillawake"] =1035,["passivesawake"] ={
1036,1037,1038}
,["skins"] ={
103,10301,10302,1003}
,["work"] =1,["awakeactivecondition"] =22,["awake"] =21,["sex"] =1},["104"] ={["name"] ="诸葛亮",["type"] =2,["haspower"] =1,["nickname"] ="zhugeliang",["normal"] =1040,["skill"] =1041,["passives"] ={
1042,1043,1044}
,["club"] =2,["atk"] =181,["def"] =135,["hp"] =1412,["spd"] =12,["color"] =3,["cardnumber"] =8,["skillawake"] =1045,["passivesawake"] ={
1046,1047,1048}
,["skins"] ={
104,10401,10402,10403}
,["work"] =4,["awakeactivecondition"] =22,["awake"] =21,["sex"] =1},["105"] ={["name"] ="周瑜",["type"] =2,["haspower"] =1,["nickname"] ="zhouyu",["normal"] =1050,["skill"] =1051,["passives"] ={
1052,1053,1054}
,["club"] =3,["atk"] =180,["def"] =134,["hp"] =1403,["spd"] =12,["color"] =3,["cardnumber"] =8,["skillawake"] =1055,["passivesawake"] ={
1056,1057,1058}
,["skins"] ={
105,10501,10502}
,["work"] =4,["awakeactivecondition"] =22,["awake"] =21,["sex"] =1},["106"] ={["name"] ="太史慈",["type"] =2,["haspower"] =1,["nickname"] ="taishici",["normal"] =1060,["skill"] =1061,["passives"] ={
1062,1063,1064}
,["club"] =3,["atk"] =177,["def"] =133,["hp"] =1383,["spd"] =12,["color"] =3,["cardnumber"] =8,["skillawake"] =1065,["passivesawake"] ={
1066,1067,1068}
,["skins"] ={
106,10601,10602,1002}
,["work"] =6,["awakeactivecondition"] =22,["awake"] =21,["sex"] =1},["107"] ={["name"] ="吕布",["type"] =2,["haspower"] =1,["nickname"] ="lvbu",["normal"] =1070,["skill"] =1071,["passives"] ={
1072,1073,1074}
,["club"] =4,["atk"] =162,["def"] =156,["hp"] =2007,["spd"] =12,["color"] =3,["cardnumber"] =8,["skillawake"] =1075,["passivesawake"] ={
1076,1077,1078}
,["skins"] ={
107,10701,10702,10703}
,["work"] =1,["awakeactivecondition"] =22,["awake"] =21,["sex"] =1},["108"] ={["name"] ="华佗",["type"] =2,["haspower"] =1,["nickname"] ="huatuo",["normal"] =1080,["skill"] =1081,["passives"] ={
1082,1083,1084}
,["club"] =4,["atk"] =136,["def"] =141,["hp"] =1504,["spd"] =10,["color"] =3,["cardnumber"] =8,["skillawake"] =1085,["passivesawake"] ={
1086,1087,1088}
,["skins"] ={
108,10801,10802}
,["work"] =3,["awakeactivecondition"] =22,["awake"] =21,["sex"] =1},["109"] ={["name"] ="甄姬",["type"] =2,["haspower"] =1,["nickname"] ="zhenji",["normal"] =1090,["skill"] =1091,["passives"] ={
1092,1093,1094}
,["club"] =1,["atk"] =139,["def"] =143,["hp"] =1509,["spd"] =12,["color"] =3,["cardnumber"] =8,["skillawake"] =1095,["passivesawake"] ={
1096,1097,1098}
,["skins"] ={
109,10901,10902}
,["work"] =3,["awakeactivecondition"] =22,["awake"] =21,["sex"] =2},["110"] ={["name"] ="黄月英",["type"] =2,["haspower"] =1,["nickname"] ="huangyueying",["normal"] =1100,["skill"] =1101,["passives"] ={
1102,1103,1104}
,["club"] =2,["atk"] =150,["def"] =170,["hp"] =2110,["spd"] =10,["color"] =3,["cardnumber"] =8,["skillawake"] =1105,["passivesawake"] ={
1106,1107,1108}
,["skins"] ={
110,11001,11002}
,["work"] =6,["awakeactivecondition"] =22,["awake"] =21,["sex"] =2},["111"] ={["name"] ="孙策",["type"] =2,["haspower"] =1,["nickname"] ="sunce",["normal"] =1110,["skill"] =1111,["passives"] ={
1112,1113,1114}
,["club"] =3,["atk"] =155,["def"] =171,["hp"] =2111,["spd"] =10,["color"] =3,["cardnumber"] =8,["skillawake"] =1115,["passivesawake"] ={
1116,1117,1118}
,["skins"] ={
111,11101,11102,11103}
,["work"] =2,["awakeactivecondition"] =22,["awake"] =21,["sex"] =1},["112"] ={["name"] ="贾诩",["type"] =2,["haspower"] =1,["nickname"] ="jiaxu",["normal"] =1120,["skill"] =1121,["passives"] ={
1122,1123,1124}
,["club"] =4,["atk"] =179,["def"] =132,["hp"] =1399,["spd"] =13,["color"] =3,["cardnumber"] =8,["skillawake"] =1125,["passivesawake"] ={
1126,1127,1128}
,["skins"] ={
112,11201,11202,11203}
,["work"] =5,["awakeactivecondition"] =22,["awake"] =21,["sex"] =1},["113"] ={["name"] ="曹仁",["type"] =2,["haspower"] =1,["nickname"] ="caoren",["normal"] =1130,["skill"] =1131,["passives"] ={
1132,1133,1134}
,["club"] =1,["atk"] =163,["def"] =177,["hp"] =2022,["spd"] =10,["color"] =3,["cardnumber"] =8,["skillawake"] =1135,["passivesawake"] ={
1136,1137,1138}
,["skins"] ={
113,11301,11302}
,["work"] =2,["awakeactivecondition"] =22,["awake"] =21,["sex"] =1},["114"] ={["name"] ="姜维",["type"] =2,["haspower"] =1,["nickname"] ="jiangwei",["normal"] =1140,["skill"] =1141,["passives"] ={
1142,1143,1144}
,["club"] =2,["atk"] =178,["def"] =129,["hp"] =1441,["spd"] =12,["color"] =3,["cardnumber"] =8,["skillawake"] =1145,["passivesawake"] ={
1146,1147,1148}
,["skins"] ={
114,11401,11402,1001}
,["work"] =5,["awakeactivecondition"] =22,["awake"] =21,["sex"] =1},["115"] ={["name"] ="孙坚",["type"] =2,["haspower"] =1,["nickname"] ="sunjian",["normal"] =1150,["skill"] =1151,["passives"] ={
1152,1153,1154}
,["club"] =3,["atk"] =160,["def"] =162,["hp"] =1895,["spd"] =10,["color"] =3,["cardnumber"] =8,["skillawake"] =1155,["passivesawake"] ={
1156,1157,1158}
,["skins"] ={
115,11501,11502}
,["work"] =2,["awakeactivecondition"] =22,["awake"] =21,["sex"] =1},["116"] ={["name"] ="公孙瓒",["type"] =2,["haspower"] =1,["nickname"] ="gongsunzan",["normal"] =1160,["skill"] =1161,["passives"] ={
1162,1163,1164}
,["club"] =4,["atk"] =166,["def"] =140,["hp"] =1516,["spd"] =13,["color"] =3,["cardnumber"] =8,["skillawake"] =1165,["passivesawake"] ={
1166,1167,1168}
,["skins"] ={
116,11601,11602}
,["work"] =6,["awakeactivecondition"] =22,["awake"] =21,["sex"] =1},["202"] ={["name"] ="荀彧",["type"] =2,["haspower"] =1,["nickname"] ="xunyu",["normal"] =2020,["skill"] =2021,["passives"] ={
2022,2023,2024}
,["club"] =1,["atk"] =152,["def"] =165,["hp"] =2389,["spd"] =11,["color"] =2,["cardnumber"] =4,["skins"] ={
202}
,["work"] =3,["awakeactivecondition"] =0,["awake"] =0,["sex"] =1},["203"] ={["name"] ="典韦",["type"] =2,["haspower"] =1,["nickname"] ="dianwei",["normal"] =2030,["skill"] =2031,["passives"] ={
2032,2033,2034}
,["club"] =1,["atk"] =132,["def"] =154,["hp"] =2075,["spd"] =10,["color"] =2,["cardnumber"] =4,["skins"] ={
203}
,["work"] =2,["awakeactivecondition"] =0,["awake"] =0,["sex"] =1},["207"] ={["name"] ="鲁肃",["type"] =2,["haspower"] =1,["nickname"] ="lusu",["normal"] =2070,["skill"] =2071,["passives"] ={
2072,2073,2074}
,["club"] =3,["atk"] =162,["def"] =127,["hp"] =1265,["spd"] =11,["color"] =2,["cardnumber"] =4,["skins"] ={
207}
,["work"] =3,["awakeactivecondition"] =0,["awake"] =0,["sex"] =1},["208"] ={["name"] ="陆逊",["type"] =2,["haspower"] =1,["nickname"] ="luxun",["normal"] =2080,["skill"] =2081,["passives"] ={
2082,2083,2084}
,["club"] =3,["atk"] =167,["def"] =127,["hp"] =1433,["spd"] =12,["color"] =2,["cardnumber"] =4,["skins"] ={
208}
,["work"] =5,["awakeactivecondition"] =0,["awake"] =0,["sex"] =1},["209"] ={["name"] ="甘宁",["type"] =2,["haspower"] =1,["nickname"] ="ganning",["normal"] =2090,["skill"] =2091,["passives"] ={
2092,2093,2094}
,["club"] =3,["atk"] =136,["def"] =156,["hp"] =2143,["spd"] =10,["color"] =2,["cardnumber"] =4,["skins"] ={
209}
,["work"] =6,["awakeactivecondition"] =0,["awake"] =0,["sex"] =1},["210"] ={["name"] ="貂蝉",["type"] =2,["haspower"] =1,["nickname"] ="diaochan",["normal"] =2100,["skill"] =2101,["passives"] ={
2102,2103,2104}
,["club"] =4,["atk"] =153,["def"] =150,["hp"] =1699,["spd"] =11,["color"] =2,["cardnumber"] =4,["skins"] ={
210}
,["work"] =5,["awakeactivecondition"] =0,["awake"] =0,["sex"] =2},["211"] ={["name"] ="董卓",["type"] =2,["haspower"] =1,["nickname"] ="dongzhuo",["normal"] =2110,["skill"] =2111,["passives"] ={
2112,2113,2114}
,["club"] =4,["atk"] =128,["def"] =152,["hp"] =2021,["spd"] =10,["color"] =2,["cardnumber"] =4,["skins"] ={
211}
,["work"] =2,["awakeactivecondition"] =0,["awake"] =0,["sex"] =1},["212"] ={["name"] ="张角",["type"] =2,["haspower"] =1,["nickname"] ="zhangjiao",["normal"] =2120,["skill"] =2121,["passives"] ={
2122,2122,2124}
,["club"] =4,["atk"] =162,["def"] =127,["hp"] =1260,["spd"] =11,["color"] =2,["cardnumber"] =4,["skins"] ={
212}
,["work"] =4,["awakeactivecondition"] =0,["awake"] =0,["sex"] =1},["215"] ={["name"] ="许褚",["type"] =2,["haspower"] =1,["nickname"] ="xuchu",["normal"] =2150,["skill"] =2151,["passives"] ={
2152,2153,2154}
,["club"] =1,["atk"] =140,["def"] =145,["hp"] =2134,["spd"] =10,["color"] =1,["cardnumber"] =1,["skins"] ={
215}
,["work"] =1,["awakeactivecondition"] =0,["awake"] =0,["sex"] =1},["220"] ={["name"] ="马岱",["type"] =2,["haspower"] =1,["nickname"] ="madai",["normal"] =2200,["skill"] =2201,["passives"] ={
2202,2203,2204}
,["club"] =2,["atk"] =138,["def"] =142,["hp"] =1528,["spd"] =10,["color"] =2,["cardnumber"] =4,["skins"] ={
220}
,["work"] =3,["awakeactivecondition"] =0,["awake"] =0,["sex"] =1},["223"] ={["name"] ="蔡文姬",["type"] =2,["haspower"] =1,["nickname"] ="caiwenji",["normal"] =2230,["skill"] =2231,["passives"] ={
2232,2233,2234}
,["club"] =1,["atk"] =117,["def"] =131,["hp"] =1291,["spd"] =8,["color"] =2,["cardnumber"] =4,["skins"] ={
223}
,["work"] =4,["awakeactivecondition"] =0,["awake"] =0,["sex"] =2},["227"] ={["name"] ="颜良",["type"] =2,["haspower"] =1,["nickname"] ="yanliang",["normal"] =2270,["skill"] =2271,["passives"] ={
2272,2273}
,["club"] =4,["atk"] =135,["def"] =123,["hp"] =1134,["spd"] =10,["color"] =1,["cardnumber"] =1,["skins"] ={
227}
,["work"] =1,["awakeactivecondition"] =0,["awake"] =0,["sex"] =1},["228"] ={["name"] ="文丑",["type"] =2,["haspower"] =1,["nickname"] ="wenchou",["normal"] =2280,["skill"] =2281,["passives"] ={
2282,2283}
,["club"] =4,["atk"] =128,["def"] =152,["hp"] =2018,["spd"] =10,["color"] =1,["cardnumber"] =1,["skins"] ={
228}
,["work"] =2,["awakeactivecondition"] =0,["awake"] =0,["sex"] =1},["301"] ={["name"] ="周泰",["type"] =2,["haspower"] =1,["nickname"] ="zhoutai",["normal"] =3010,["skill"] =3011,["passives"] ={
3012,3013}
,["club"] =3,["atk"] =160,["def"] =127,["hp"] =1250,["spd"] =11,["color"] =1,["cardnumber"] =1,["skins"] ={
301}
,["work"] =1,["awakeactivecondition"] =0,["awake"] =0,["sex"] =1},["302"] ={["name"] ="许攸",["type"] =2,["haspower"] =1,["nickname"] ="xuyou",["normal"] =3020,["skill"] =3021,["passives"] ={
3022,3023}
,["club"] =1,["atk"] =132,["def"] =139,["hp"] =1457,["spd"] =9,["color"] =1,["cardnumber"] =1,["skins"] ={
302}
,["work"] =3,["awakeactivecondition"] =0,["awake"] =0,["sex"] =1},["303"] ={["name"] ="于禁",["type"] =2,["haspower"] =1,["nickname"] ="yujin",["normal"] =3030,["skill"] =3031,["passives"] ={
3032,3033}
,["club"] =1,["atk"] =132,["def"] =116,["hp"] =1031,["spd"] =9,["color"] =1,["cardnumber"] =1,["skins"] ={
303}
,["work"] =2,["awakeactivecondition"] =0,["awake"] =0,["sex"] =1},["304"] ={["name"] ="张星彩",["type"] =2,["haspower"] =1,["nickname"] ="zhangxingcai",["normal"] =3040,["skill"] =3041,["passives"] ={
3042,3043,3044}
,["club"] =2,["atk"] =128,["def"] =152,["hp"] =2018,["spd"] =10,["color"] =1,["cardnumber"] =1,["skins"] ={
304}
,["work"] =2,["awakeactivecondition"] =0,["awake"] =0,["sex"] =2},["305"] ={["name"] ="关银屏",["type"] =2,["haspower"] =1,["nickname"] ="guanyinping",["normal"] =3050,["skill"] =3051,["passives"] ={
3052,3053}
,["club"] =2,["atk"] =140,["def"] =145,["hp"] =2134,["spd"] =10,["color"] =1,["cardnumber"] =1,["skins"] ={
305}
,["work"] =1,["awakeactivecondition"] =0,["awake"] =0,["sex"] =2},["306"] ={["name"] ="关平",["type"] =2,["haspower"] =1,["nickname"] ="guanping",["normal"] =3060,["skill"] =3061,["passives"] ={
3062}
,["club"] =2,["atk"] =102,["def"] =127,["hp"] =1260,["spd"] =7,["color"] =1,["cardnumber"] =1,["skins"] ={
306}
,["work"] =5,["awakeactivecondition"] =0,["awake"] =0,["sex"] =1},["307"] ={["name"] ="程普",["type"] =2,["haspower"] =1,["nickname"] ="chengpu",["normal"] =3070,["skill"] =3071,["passives"] ={
3072,3073}
,["club"] =3,["atk"] =110,["def"] =142,["hp"] =1735,["spd"] =8,["color"] =1,["cardnumber"] =1,["skins"] ={
307}
,["work"] =2,["awakeactivecondition"] =0,["awake"] =0,["sex"] =1},["308"] ={["name"] ="张昭",["type"] =2,["haspower"] =1,["nickname"] ="zhangzhao",["normal"] =3080,["skill"] =3081,["passives"] ={
3082,3083}
,["club"] =3,["atk"] =121,["def"] =136,["hp"] =1500,["spd"] =9,["color"] =1,["cardnumber"] =1,["skins"] ={
308}
,["work"] =3,["awakeactivecondition"] =0,["awake"] =0,["sex"] =1},["312"] ={["name"] ="邢道荣",["type"] =2,["haspower"] =1,["nickname"] ="xingdaorong",["normal"] =3120,["skill"] =3121,["passives"] ={
3122,3123,3124}
,["club"] =4,["atk"] =165,["def"] =128,["hp"] =1284,["spd"] =11,["color"] =1,["cardnumber"] =1,["skins"] ={
312}
,["work"] =2,["awakeactivecondition"] =0,["awake"] =0,["sex"] =1},["313"] ={["name"] ="祝融夫人",["type"] =2,["haspower"] =1,["nickname"] ="zhurongfuren",["normal"] =3130,["skill"] =3131,["passives"] ={
3132,3133,3134}
,["club"] =2,["atk"] =117,["def"] =131,["hp"] =1291,["spd"] =8,["color"] =2,["cardnumber"] =4,["skins"] ={
313}
,["work"] =4,["awakeactivecondition"] =0,["awake"] =0,["sex"] =2},["314"] ={["name"] ="孟获",["type"] =2,["haspower"] =1,["nickname"] ="menghuo",["normal"] =3140,["skill"] =3141,["passives"] ={
3143,3143,3144}
,["club"] =2,["atk"] =156,["def"] =125,["hp"] =1218,["spd"] =11,["color"] =2,["cardnumber"] =4,["skins"] ={
314}
,["work"] =1,["awakeactivecondition"] =0,["awake"] =0,["sex"] =1},["1000"] ={["name"] ="怪1",["type"] =3,["haspower"] =0,["nickname"] ="taishici",["normal"] =9999,["passives"] ={
}
,["skins"] ={
}
}}
