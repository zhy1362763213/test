local zhongshenka = {
    payment = 128,
    recharge_total = 128,
    gold = 1280,
    time = 2,
    coin = 0.1,
    timelong=-1,
    everyday = {
        coin=100,
        jinjieshi=200
    }
}


local yueka = {
    payment = 30,
    recharge_total = 30,
    gold = 300,
    time = 2,
    timelong=30,
    everyday = {
        coin=100,
        jinjieshi=100,
        huoba_lv3=1
    }
}

local zhouka = {
    payment = 8,
    recharge_total = 8,
    gold = 80,
    coin = 0.1,
    timelong=7,
    everyday = {
        coin=100,
    }
}


local fulika = {
    payment = 0,
    recharge_total = 0,
    timelong=-1,
    everyday = {
        coin=10,
    }
}

return config