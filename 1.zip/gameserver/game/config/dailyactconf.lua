return {
    ["1"] = {
      ["id"] = 1,
      ["limit"] = 20,
      ["rewards"] = {
        ["value"] = 100,
        ["type"] = "jingtie"
      }
    },
    ["2"] = {
      ["id"] = 2,
      ["limit"] = 40,
      ["rewards"] = {
        ["value"] = 5,
        ["type"] = "huoba_lv1"
      }
    },
    ["3"] = {
      ["id"] = 3,
      ["limit"] = 60,
      ["rewards"] = {
        ["value"] = 1,
        ["type"] = "box_lv2"
      }
    },
    ["4"] = {
      ["id"] = 4,
      ["limit"] = 80,
      ["rewards"] = {
        ["value"] = 5,
        ["type"] = "xianshenmenpiao"
      }
    },
    ["5"] = {
      ["id"] = 5,
      ["limit"] = 100,
      ["rewards"] = {
        ["value"] = 1,
        ["type"] = "zhaomuling"
      }
    }

 }