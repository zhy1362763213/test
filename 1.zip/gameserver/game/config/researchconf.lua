return {
    ["603"] = {
      ["researchtype"] = 0,
      ["work"] = 2,
      ["researchmaxlevel"] = 40,
      ["researchorder"] = 3,
      ["id"] = 603,
      ["researchname"] = "researchconf_researchname_603"
    },
    ["407"] = {
      ["researchtype"] = 0,
      ["work"] = 5,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 7,
      ["id"] = 407,
      ["researchname"] = "researchconf_researchname_407"
    },
    ["302"] = {
      ["researchtype"] = 0,
      ["work"] = 6,
      ["researchmaxlevel"] = 50,
      ["researchorder"] = 2,
      ["id"] = 302,
      ["researchname"] = "researchconf_researchname_302"
    },
    ["106"] = {
      ["researchtype"] = 0,
      ["work"] = 1,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 6,
      ["id"] = 106,
      ["researchname"] = "researchconf_researchname_106"
    },
    ["113"] = {
      ["researchtype"] = 1,
      ["work"] = 1,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 113,
      ["researchname"] = "researchconf_researchname_113"
    },
    ["414"] = {
      ["researchtype"] = 1,
      ["work"] = 5,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 414,
      ["researchname"] = "researchconf_researchname_414"
    },
    ["610"] = {
      ["researchtype"] = 1,
      ["work"] = 2,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 610,
      ["researchname"] = "researchconf_researchname_610"
    },
    ["604"] = {
      ["researchtype"] = 0,
      ["work"] = 2,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 4,
      ["id"] = 604,
      ["researchname"] = "researchconf_researchname_604"
    },
    ["408"] = {
      ["researchtype"] = 0,
      ["work"] = 5,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 8,
      ["id"] = 408,
      ["researchname"] = "researchconf_researchname_408"
    },
    ["303"] = {
      ["researchtype"] = 0,
      ["work"] = 6,
      ["researchmaxlevel"] = 40,
      ["researchorder"] = 3,
      ["id"] = 303,
      ["researchname"] = "researchconf_researchname_303"
    },
    ["107"] = {
      ["researchtype"] = 0,
      ["work"] = 1,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 7,
      ["id"] = 107,
      ["researchname"] = "researchconf_researchname_107"
    },
    ["114"] = {
      ["researchtype"] = 1,
      ["work"] = 1,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 114,
      ["researchname"] = "researchconf_researchname_114"
    },
    ["310"] = {
      ["researchtype"] = 1,
      ["work"] = 6,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 310,
      ["researchname"] = "researchconf_researchname_310"
    },
    ["611"] = {
      ["researchtype"] = 1,
      ["work"] = 2,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 611,
      ["researchname"] = "researchconf_researchname_611"
    },
    ["605"] = {
      ["researchtype"] = 0,
      ["work"] = 2,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 5,
      ["id"] = 605,
      ["researchname"] = "researchconf_researchname_605"
    },
    ["409"] = {
      ["researchtype"] = 1,
      ["work"] = 5,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 409,
      ["researchname"] = "researchconf_researchname_409"
    },
    ["304"] = {
      ["researchtype"] = 0,
      ["work"] = 6,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 4,
      ["id"] = 304,
      ["researchname"] = "researchconf_researchname_304"
    },
    ["108"] = {
      ["researchtype"] = 0,
      ["work"] = 1,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 8,
      ["id"] = 108,
      ["researchname"] = "researchconf_researchname_108"
    },
    ["311"] = {
      ["researchtype"] = 1,
      ["work"] = 6,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 311,
      ["researchname"] = "researchconf_researchname_311"
    },
    ["612"] = {
      ["researchtype"] = 1,
      ["work"] = 2,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 612,
      ["researchname"] = "researchconf_researchname_612"
    },
    ["606"] = {
      ["researchtype"] = 0,
      ["work"] = 2,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 6,
      ["id"] = 606,
      ["researchname"] = "researchconf_researchname_606"
    },
    ["501"] = {
      ["researchtype"] = 0,
      ["work"] = 3,
      ["researchmaxlevel"] = 60,
      ["researchorder"] = 1,
      ["id"] = 501,
      ["researchname"] = "researchconf_researchname_501"
    },
    ["305"] = {
      ["researchtype"] = 0,
      ["work"] = 6,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 5,
      ["id"] = 305,
      ["researchname"] = "researchconf_researchname_305"
    },
    ["109"] = {
      ["researchtype"] = 1,
      ["work"] = 1,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 109,
      ["researchname"] = "researchconf_researchname_109"
    },
    ["312"] = {
      ["researchtype"] = 1,
      ["work"] = 6,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 312,
      ["researchname"] = "researchconf_researchname_312"
    },
    ["613"] = {
      ["researchtype"] = 1,
      ["work"] = 2,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 613,
      ["researchname"] = "researchconf_researchname_613"
    },
    ["607"] = {
      ["researchtype"] = 0,
      ["work"] = 2,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 7,
      ["id"] = 607,
      ["researchname"] = "researchconf_researchname_607"
    },
    ["502"] = {
      ["researchtype"] = 0,
      ["work"] = 3,
      ["researchmaxlevel"] = 50,
      ["researchorder"] = 2,
      ["id"] = 502,
      ["researchname"] = "researchconf_researchname_502"
    },
    ["306"] = {
      ["researchtype"] = 0,
      ["work"] = 6,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 6,
      ["id"] = 306,
      ["researchname"] = "researchconf_researchname_306"
    },
    ["201"] = {
      ["researchtype"] = 0,
      ["work"] = 4,
      ["researchmaxlevel"] = 60,
      ["researchorder"] = 1,
      ["id"] = 201,
      ["researchname"] = "researchconf_researchname_201"
    },
    ["313"] = {
      ["researchtype"] = 1,
      ["work"] = 6,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 313,
      ["researchname"] = "researchconf_researchname_313"
    },
    ["614"] = {
      ["researchtype"] = 1,
      ["work"] = 2,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 614,
      ["researchname"] = "researchconf_researchname_614"
    },
    ["608"] = {
      ["researchtype"] = 0,
      ["work"] = 2,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 8,
      ["id"] = 608,
      ["researchname"] = "researchconf_researchname_608"
    },
    ["503"] = {
      ["researchtype"] = 0,
      ["work"] = 3,
      ["researchmaxlevel"] = 40,
      ["researchorder"] = 3,
      ["id"] = 503,
      ["researchname"] = "researchconf_researchname_503"
    },
    ["307"] = {
      ["researchtype"] = 0,
      ["work"] = 6,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 7,
      ["id"] = 307,
      ["researchname"] = "researchconf_researchname_307"
    },
    ["202"] = {
      ["researchtype"] = 0,
      ["work"] = 4,
      ["researchmaxlevel"] = 50,
      ["researchorder"] = 2,
      ["id"] = 202,
      ["researchname"] = "researchconf_researchname_202"
    },
    ["314"] = {
      ["researchtype"] = 1,
      ["work"] = 6,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 314,
      ["researchname"] = "researchconf_researchname_314"
    },
    ["510"] = {
      ["researchtype"] = 1,
      ["work"] = 3,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 510,
      ["researchname"] = "researchconf_researchname_510"
    },
    ["609"] = {
      ["researchtype"] = 1,
      ["work"] = 2,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 609,
      ["researchname"] = "researchconf_researchname_609"
    },
    ["504"] = {
      ["researchtype"] = 0,
      ["work"] = 3,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 4,
      ["id"] = 504,
      ["researchname"] = "researchconf_researchname_504"
    },
    ["308"] = {
      ["researchtype"] = 0,
      ["work"] = 6,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 8,
      ["id"] = 308,
      ["researchname"] = "researchconf_researchname_308"
    },
    ["203"] = {
      ["researchtype"] = 0,
      ["work"] = 4,
      ["researchmaxlevel"] = 40,
      ["researchorder"] = 3,
      ["id"] = 203,
      ["researchname"] = "researchconf_researchname_203"
    },
    ["210"] = {
      ["researchtype"] = 1,
      ["work"] = 4,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 210,
      ["researchname"] = "researchconf_researchname_210"
    },
    ["511"] = {
      ["researchtype"] = 1,
      ["work"] = 3,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 511,
      ["researchname"] = "researchconf_researchname_511"
    },
    ["505"] = {
      ["researchtype"] = 0,
      ["work"] = 3,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 5,
      ["id"] = 505,
      ["researchname"] = "researchconf_researchname_505"
    },
    ["309"] = {
      ["researchtype"] = 1,
      ["work"] = 6,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 309,
      ["researchname"] = "researchconf_researchname_309"
    },
    ["204"] = {
      ["researchtype"] = 0,
      ["work"] = 4,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 4,
      ["id"] = 204,
      ["researchname"] = "researchconf_researchname_204"
    },
    ["211"] = {
      ["researchtype"] = 1,
      ["work"] = 4,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 211,
      ["researchname"] = "researchconf_researchname_211"
    },
    ["512"] = {
      ["researchtype"] = 1,
      ["work"] = 3,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 512,
      ["researchname"] = "researchconf_researchname_512"
    },
    ["506"] = {
      ["researchtype"] = 0,
      ["work"] = 3,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 6,
      ["id"] = 506,
      ["researchname"] = "researchconf_researchname_506"
    },
    ["401"] = {
      ["researchtype"] = 0,
      ["work"] = 5,
      ["researchmaxlevel"] = 60,
      ["researchorder"] = 1,
      ["id"] = 401,
      ["researchname"] = "researchconf_researchname_401"
    },
    ["205"] = {
      ["researchtype"] = 0,
      ["work"] = 4,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 5,
      ["id"] = 205,
      ["researchname"] = "researchconf_researchname_205"
    },
    ["212"] = {
      ["researchtype"] = 1,
      ["work"] = 4,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 212,
      ["researchname"] = "researchconf_researchname_212"
    },
    ["513"] = {
      ["researchtype"] = 1,
      ["work"] = 3,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 513,
      ["researchname"] = "researchconf_researchname_513"
    },
    ["507"] = {
      ["researchtype"] = 0,
      ["work"] = 3,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 7,
      ["id"] = 507,
      ["researchname"] = "researchconf_researchname_507"
    },
    ["402"] = {
      ["researchtype"] = 0,
      ["work"] = 5,
      ["researchmaxlevel"] = 50,
      ["researchorder"] = 2,
      ["id"] = 402,
      ["researchname"] = "researchconf_researchname_402"
    },
    ["206"] = {
      ["researchtype"] = 0,
      ["work"] = 4,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 6,
      ["id"] = 206,
      ["researchname"] = "researchconf_researchname_206"
    },
    ["101"] = {
      ["researchtype"] = 0,
      ["work"] = 1,
      ["researchmaxlevel"] = 60,
      ["researchorder"] = 1,
      ["id"] = 101,
      ["researchname"] = "researchconf_researchname_101"
    },
    ["213"] = {
      ["researchtype"] = 1,
      ["work"] = 4,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 213,
      ["researchname"] = "researchconf_researchname_213"
    },
    ["514"] = {
      ["researchtype"] = 1,
      ["work"] = 3,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 514,
      ["researchname"] = "researchconf_researchname_514"
    },
    ["508"] = {
      ["researchtype"] = 0,
      ["work"] = 3,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 8,
      ["id"] = 508,
      ["researchname"] = "researchconf_researchname_508"
    },
    ["403"] = {
      ["researchtype"] = 0,
      ["work"] = 5,
      ["researchmaxlevel"] = 40,
      ["researchorder"] = 3,
      ["id"] = 403,
      ["researchname"] = "researchconf_researchname_403"
    },
    ["207"] = {
      ["researchtype"] = 0,
      ["work"] = 4,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 7,
      ["id"] = 207,
      ["researchname"] = "researchconf_researchname_207"
    },
    ["102"] = {
      ["researchtype"] = 0,
      ["work"] = 1,
      ["researchmaxlevel"] = 50,
      ["researchorder"] = 2,
      ["id"] = 102,
      ["researchname"] = "researchconf_researchname_102"
    },
    ["214"] = {
      ["researchtype"] = 1,
      ["work"] = 4,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 214,
      ["researchname"] = "researchconf_researchname_214"
    },
    ["410"] = {
      ["researchtype"] = 1,
      ["work"] = 5,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 410,
      ["researchname"] = "researchconf_researchname_410"
    },
    ["509"] = {
      ["researchtype"] = 1,
      ["work"] = 3,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 509,
      ["researchname"] = "researchconf_researchname_509"
    },
    ["404"] = {
      ["researchtype"] = 0,
      ["work"] = 5,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 4,
      ["id"] = 404,
      ["researchname"] = "researchconf_researchname_404"
    },
    ["208"] = {
      ["researchtype"] = 0,
      ["work"] = 4,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 8,
      ["id"] = 208,
      ["researchname"] = "researchconf_researchname_208"
    },
    ["103"] = {
      ["researchtype"] = 0,
      ["work"] = 1,
      ["researchmaxlevel"] = 40,
      ["researchorder"] = 3,
      ["id"] = 103,
      ["researchname"] = "researchconf_researchname_103"
    },
    ["110"] = {
      ["researchtype"] = 1,
      ["work"] = 1,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 110,
      ["researchname"] = "researchconf_researchname_110"
    },
    ["411"] = {
      ["researchtype"] = 1,
      ["work"] = 5,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 411,
      ["researchname"] = "researchconf_researchname_411"
    },
    ["601"] = {
      ["researchtype"] = 0,
      ["work"] = 2,
      ["researchmaxlevel"] = 60,
      ["researchorder"] = 1,
      ["id"] = 601,
      ["researchname"] = "researchconf_researchname_601"
    },
    ["405"] = {
      ["researchtype"] = 0,
      ["work"] = 5,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 5,
      ["id"] = 405,
      ["researchname"] = "researchconf_researchname_405"
    },
    ["209"] = {
      ["researchtype"] = 1,
      ["work"] = 4,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 209,
      ["researchname"] = "researchconf_researchname_209"
    },
    ["104"] = {
      ["researchtype"] = 0,
      ["work"] = 1,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 4,
      ["id"] = 104,
      ["researchname"] = "researchconf_researchname_104"
    },
    ["111"] = {
      ["researchtype"] = 1,
      ["work"] = 1,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 111,
      ["researchname"] = "researchconf_researchname_111"
    },
    ["412"] = {
      ["researchtype"] = 1,
      ["work"] = 5,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 412,
      ["researchname"] = "researchconf_researchname_412"
    },
    ["602"] = {
      ["researchtype"] = 0,
      ["work"] = 2,
      ["researchmaxlevel"] = 50,
      ["researchorder"] = 2,
      ["id"] = 602,
      ["researchname"] = "researchconf_researchname_602"
    },
    ["406"] = {
      ["researchtype"] = 0,
      ["work"] = 5,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 6,
      ["id"] = 406,
      ["researchname"] = "researchconf_researchname_406"
    },
    ["301"] = {
      ["researchtype"] = 0,
      ["work"] = 6,
      ["researchmaxlevel"] = 60,
      ["researchorder"] = 1,
      ["id"] = 301,
      ["researchname"] = "researchconf_researchname_301"
    },
    ["105"] = {
      ["researchtype"] = 0,
      ["work"] = 1,
      ["researchmaxlevel"] = 20,
      ["researchorder"] = 5,
      ["id"] = 105,
      ["researchname"] = "researchconf_researchname_105"
    },
    ["112"] = {
      ["researchtype"] = 1,
      ["work"] = 1,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 112,
      ["researchname"] = "researchconf_researchname_112"
    },
    ["413"] = {
      ["researchtype"] = 1,
      ["work"] = 5,
      ["researchmaxlevel"] = 30,
      ["researchorder"] = 0,
      ["id"] = 413,
      ["researchname"] = "researchconf_researchname_413"
    }

 }