local config = {
    [1]={daynum=1, tp="jinjieshi", num=888},
    [2]={daynum=2, tp="jingtie", num=888},
    [3]={daynum=3, tp="gold", num=888},
    [4]={daynum=4, tp="jingtie", num=888},
    [5]={daynum=5, tp="jinjieshi", num=888},
    [6]={daynum=6, tp="gold", num=888},
    [7]={daynum=7, tp="jingtie", num=888},
    [8]={daynum=8, tp="jinjieshi", num=888},
    [9]={daynum=9, tp="gold", num=888},
    [10]={daynum=10, tp="jingtie", num=888},
    [11]={daynum=11, tp="jinjieshi", num=888},
    [12]={daynum=12, tp="gold", num=888},
    [13]={daynum=13, tp="jingtie", num=888},
    [14]={daynum=14, tp="gold", num=888},
    [15]={daynum=15, tp="zhenzhu", num=5},
}

return config