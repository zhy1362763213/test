--[[
    itemid 配置表
]]
return  {
    ["0"] = {
        {
            type=1,
            name="coin"
        },
        {
            type=2,
            name="gold"
        }
    },
    ["1010"] = {
        {
            type=3,
            name="huoba_lv3"
        }
    },
    ["1006"] = {
        {
            type=3,
            name="jingtie"
        }
    },
    ["2002"] = {
        {
            type=3,
            name="box_lv2"
        }
    },
    ["1003"] = {
        {
            type=3,
            name="jinjieshi"
        },
    },
    ["3201"] = {
        {
            type=3,
            name="libao_wujiang_hong2"
        }
    },
    ["1013"] = {
        {
            type=3,
            name="zhenzhu"
        }
    },
    ["3001"] = {
        {
            type=3,
            name="libao_coin"
        }
    },
    ["3007"] = {
        {
            type=3,
            name="libao_wujiang_hong1"
        }
    },
    ["3002"] = {
        {
            type=3,
            name="libao_gold"
        }
    },
    ["1011"] = {
        {
            type=3,
            name="yugan_lv1"
        }
    },
    ["1009"] = {
        {
            type=3,
            name="huoba_lv1"
        }
    },
    ["1001"] = {
        {
            type=3,
            name="zhaomuling"
        }
    },
    ["1014"] = {
        {
            type=3,
            name="军团币"
        }
    },
}