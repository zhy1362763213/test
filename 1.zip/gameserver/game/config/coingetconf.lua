return {
    ["11"] = {
      ["id"] = 11,
      ["diamondspend"] = 30,
      ["viplv"] = 1
    },
    ["55"] = {
      ["id"] = 55,
      ["diamondspend"] = 30,
      ["viplv"] = 11
    },
    ["12"] = {
      ["id"] = 12,
      ["diamondspend"] = 30,
      ["viplv"] = 1
    },
    ["56"] = {
      ["id"] = 56,
      ["diamondspend"] = 30,
      ["viplv"] = 12
    },
    ["13"] = {
      ["id"] = 13,
      ["diamondspend"] = 30,
      ["viplv"] = 1
    },
    ["57"] = {
      ["id"] = 57,
      ["diamondspend"] = 30,
      ["viplv"] = 12
    },
    ["80"] = {
      ["id"] = 80,
      ["diamondspend"] = 30,
      ["viplv"] = 16
    },
    ["14"] = {
      ["id"] = 14,
      ["diamondspend"] = 30,
      ["viplv"] = 2
    },
    ["58"] = {
      ["id"] = 58,
      ["diamondspend"] = 30,
      ["viplv"] = 12
    },
    ["81"] = {
      ["id"] = 81,
      ["diamondspend"] = 30,
      ["viplv"] = 17
    },
    ["15"] = {
      ["id"] = 15,
      ["diamondspend"] = 30,
      ["viplv"] = 2
    },
    ["59"] = {
      ["id"] = 59,
      ["diamondspend"] = 30,
      ["viplv"] = 12
    },
    ["82"] = {
      ["id"] = 82,
      ["diamondspend"] = 30,
      ["viplv"] = 17
    },
    ["16"] = {
      ["id"] = 16,
      ["diamondspend"] = 30,
      ["viplv"] = 2
    },
    ["83"] = {
      ["id"] = 83,
      ["diamondspend"] = 30,
      ["viplv"] = 17
    },
    ["17"] = {
      ["id"] = 17,
      ["diamondspend"] = 30,
      ["viplv"] = 3
    },
    ["40"] = {
      ["id"] = 40,
      ["diamondspend"] = 30,
      ["viplv"] = 8
    },
    ["84"] = {
      ["id"] = 84,
      ["diamondspend"] = 30,
      ["viplv"] = 17
    },
    ["18"] = {
      ["id"] = 18,
      ["diamondspend"] = 30,
      ["viplv"] = 3
    },
    ["41"] = {
      ["id"] = 41,
      ["diamondspend"] = 30,
      ["viplv"] = 9
    },
    ["85"] = {
      ["id"] = 85,
      ["diamondspend"] = 30,
      ["viplv"] = 17
    },
    ["19"] = {
      ["id"] = 19,
      ["diamondspend"] = 30,
      ["viplv"] = 3
    },
    ["42"] = {
      ["id"] = 42,
      ["diamondspend"] = 30,
      ["viplv"] = 9
    },
    ["86"] = {
      ["id"] = 86,
      ["diamondspend"] = 30,
      ["viplv"] = 18
    },
    ["43"] = {
      ["id"] = 43,
      ["diamondspend"] = 30,
      ["viplv"] = 9
    },
    ["87"] = {
      ["id"] = 87,
      ["diamondspend"] = 30,
      ["viplv"] = 18
    },
    ["44"] = {
      ["id"] = 44,
      ["diamondspend"] = 30,
      ["viplv"] = 9
    },
    ["88"] = {
      ["id"] = 88,
      ["diamondspend"] = 30,
      ["viplv"] = 18
    },
    ["45"] = {
      ["id"] = 45,
      ["diamondspend"] = 30,
      ["viplv"] = 9
    },
    ["89"] = {
      ["id"] = 89,
      ["diamondspend"] = 30,
      ["viplv"] = 18
    },
    ["46"] = {
      ["id"] = 46,
      ["diamondspend"] = 30,
      ["viplv"] = 10
    },
    ["47"] = {
      ["id"] = 47,
      ["diamondspend"] = 30,
      ["viplv"] = 10
    },
    ["70"] = {
      ["id"] = 70,
      ["diamondspend"] = 30,
      ["viplv"] = 14
    },
    ["48"] = {
      ["id"] = 48,
      ["diamondspend"] = 30,
      ["viplv"] = 10
    },
    ["71"] = {
      ["id"] = 71,
      ["diamondspend"] = 30,
      ["viplv"] = 15
    },
    ["49"] = {
      ["id"] = 49,
      ["diamondspend"] = 30,
      ["viplv"] = 10
    },
    ["72"] = {
      ["id"] = 72,
      ["diamondspend"] = 30,
      ["viplv"] = 15
    },
    ["73"] = {
      ["id"] = 73,
      ["diamondspend"] = 30,
      ["viplv"] = 15
    },
    ["30"] = {
      ["id"] = 30,
      ["diamondspend"] = 30,
      ["viplv"] = 6
    },
    ["74"] = {
      ["id"] = 74,
      ["diamondspend"] = 30,
      ["viplv"] = 15
    },
    ["31"] = {
      ["id"] = 31,
      ["diamondspend"] = 30,
      ["viplv"] = 7
    },
    ["75"] = {
      ["id"] = 75,
      ["diamondspend"] = 30,
      ["viplv"] = 15
    },
    ["32"] = {
      ["id"] = 32,
      ["diamondspend"] = 30,
      ["viplv"] = 7
    },
    ["76"] = {
      ["id"] = 76,
      ["diamondspend"] = 30,
      ["viplv"] = 16
    },
    ["33"] = {
      ["id"] = 33,
      ["diamondspend"] = 30,
      ["viplv"] = 7
    },
    ["77"] = {
      ["id"] = 77,
      ["diamondspend"] = 30,
      ["viplv"] = 16
    },
    ["34"] = {
      ["id"] = 34,
      ["diamondspend"] = 30,
      ["viplv"] = 7
    },
    ["78"] = {
      ["id"] = 78,
      ["diamondspend"] = 30,
      ["viplv"] = 16
    },
    ["35"] = {
      ["id"] = 35,
      ["diamondspend"] = 30,
      ["viplv"] = 7
    },
    ["79"] = {
      ["id"] = 79,
      ["diamondspend"] = 30,
      ["viplv"] = 16
    },
    ["36"] = {
      ["id"] = 36,
      ["diamondspend"] = 30,
      ["viplv"] = 8
    },
    ["37"] = {
      ["id"] = 37,
      ["diamondspend"] = 30,
      ["viplv"] = 8
    },
    ["60"] = {
      ["id"] = 60,
      ["diamondspend"] = 30,
      ["viplv"] = 12
    },
    ["38"] = {
      ["id"] = 38,
      ["diamondspend"] = 30,
      ["viplv"] = 8
    },
    ["61"] = {
      ["id"] = 61,
      ["diamondspend"] = 30,
      ["viplv"] = 13
    },
    ["39"] = {
      ["id"] = 39,
      ["diamondspend"] = 30,
      ["viplv"] = 8
    },
    ["62"] = {
      ["id"] = 62,
      ["diamondspend"] = 30,
      ["viplv"] = 13
    },
    ["63"] = {
      ["id"] = 63,
      ["diamondspend"] = 30,
      ["viplv"] = 13
    },
    ["20"] = {
      ["id"] = 20,
      ["diamondspend"] = 30,
      ["viplv"] = 4
    },
    ["64"] = {
      ["id"] = 64,
      ["diamondspend"] = 30,
      ["viplv"] = 13
    },
    ["21"] = {
      ["id"] = 21,
      ["diamondspend"] = 30,
      ["viplv"] = 4
    },
    ["65"] = {
      ["id"] = 65,
      ["diamondspend"] = 30,
      ["viplv"] = 13
    },
    ["22"] = {
      ["id"] = 22,
      ["diamondspend"] = 30,
      ["viplv"] = 4
    },
    ["66"] = {
      ["id"] = 66,
      ["diamondspend"] = 30,
      ["viplv"] = 14
    },
    ["23"] = {
      ["id"] = 23,
      ["diamondspend"] = 30,
      ["viplv"] = 5
    },
    ["67"] = {
      ["id"] = 67,
      ["diamondspend"] = 30,
      ["viplv"] = 14
    },
    ["1"] = {
      ["id"] = 1,
      ["diamondspend"] = 0,
      ["viplv"] = 0
    },
    ["24"] = {
      ["id"] = 24,
      ["diamondspend"] = 30,
      ["viplv"] = 5
    },
    ["90"] = {
      ["id"] = 90,
      ["diamondspend"] = 30,
      ["viplv"] = 18
    },
    ["2"] = {
      ["id"] = 2,
      ["diamondspend"] = 0,
      ["viplv"] = 0
    },
    ["68"] = {
      ["id"] = 68,
      ["diamondspend"] = 30,
      ["viplv"] = 14
    },
    ["3"] = {
      ["id"] = 3,
      ["diamondspend"] = 0,
      ["viplv"] = 0
    },
    ["25"] = {
      ["id"] = 25,
      ["diamondspend"] = 30,
      ["viplv"] = 5
    },
    ["4"] = {
      ["id"] = 4,
      ["diamondspend"] = 30,
      ["viplv"] = 0
    },
    ["69"] = {
      ["id"] = 69,
      ["diamondspend"] = 30,
      ["viplv"] = 14
    },
    ["26"] = {
      ["id"] = 26,
      ["diamondspend"] = 30,
      ["viplv"] = 6
    },
    ["5"] = {
      ["id"] = 5,
      ["diamondspend"] = 30,
      ["viplv"] = 0
    },
    ["6"] = {
      ["id"] = 6,
      ["diamondspend"] = 30,
      ["viplv"] = 0
    },
    ["27"] = {
      ["id"] = 27,
      ["diamondspend"] = 30,
      ["viplv"] = 6
    },
    ["50"] = {
      ["id"] = 50,
      ["diamondspend"] = 30,
      ["viplv"] = 10
    },
    ["7"] = {
      ["id"] = 7,
      ["diamondspend"] = 30,
      ["viplv"] = 0
    },
    ["8"] = {
      ["id"] = 8,
      ["diamondspend"] = 30,
      ["viplv"] = 0
    },
    ["28"] = {
      ["id"] = 28,
      ["diamondspend"] = 30,
      ["viplv"] = 6
    },
    ["51"] = {
      ["id"] = 51,
      ["diamondspend"] = 30,
      ["viplv"] = 11
    },
    ["9"] = {
      ["id"] = 9,
      ["diamondspend"] = 30,
      ["viplv"] = 0
    },
    ["29"] = {
      ["id"] = 29,
      ["diamondspend"] = 30,
      ["viplv"] = 6
    },
    ["52"] = {
      ["id"] = 52,
      ["diamondspend"] = 30,
      ["viplv"] = 11
    },
    ["53"] = {
      ["id"] = 53,
      ["diamondspend"] = 30,
      ["viplv"] = 11
    },
    ["10"] = {
      ["id"] = 10,
      ["diamondspend"] = 30,
      ["viplv"] = 0
    },
    ["54"] = {
      ["id"] = 54,
      ["diamondspend"] = 30,
      ["viplv"] = 11
    }
  
 }