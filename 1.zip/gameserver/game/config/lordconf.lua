return {
    ["clk"] = 7,
    ["atk"] = 9,
    ["hp"] = 45,
    ["def"] = 10,
}