return {["0"] ={["def_ratio"] =0,["lord_lv"] =100,["hp_ratio"] =0,["atk_ratio"] =0,["order_spend"] =20,["conditions"] ={
}
},["1"] ={["def_ratio"] =0.1,["lord_lv"] =200,["hp_ratio"] =0.1,["atk_ratio"] =0.1,["order_spend"] =100,["conditions"] ={
}
},["2"] ={["def_ratio"] =0.2,["lord_lv"] =300,["hp_ratio"] =0.2,["atk_ratio"] =0.2,["order_spend"] =200,["conditions"] ={
}
},["3"] ={["def_ratio"] =0.3,["lord_lv"] =500,["hp_ratio"] =0.3,["atk_ratio"] =0.3,["order_spend"] =400,["conditions"] ={
}
},["4"] ={["def_ratio"] =0.4,["lord_lv"] =700,["hp_ratio"] =0.4,["atk_ratio"] =0.4,["order_spend"] =800,["conditions"] ={
}
},["5"] ={["def_ratio"] =0.5,["lord_lv"] =900,["hp_ratio"] =0.5,["atk_ratio"] =0.5,["order_spend"] =1500,["conditions"] ={
}
},["6"] ={["def_ratio"] =0.6,["lord_lv"] =1100,["hp_ratio"] =0.6,["atk_ratio"] =0.6,["order_spend"] =2500,["conditions"] ={
}
},["7"] ={["def_ratio"] =0.7,["lord_lv"] =1300,["hp_ratio"] =0.7,["atk_ratio"] =0.7,["order_spend"] =4000,["conditions"] ={
}
},["8"] ={["def_ratio"] =0.8,["lord_lv"] =1500,["hp_ratio"] =0.8,["atk_ratio"] =0.8,["order_spend"] =8000,["conditions"] ={
}
},["9"] ={["def_ratio"] =0.9,["lord_lv"] =1800,["hp_ratio"] =0.9,["atk_ratio"] =0.9,["order_spend"] =12000,["conditions"] ={
}
},["10"] ={["def_ratio"] =1,["lord_lv"] =2100,["hp_ratio"] =1,["atk_ratio"] =1,["order_spend"] =18000,["conditions"] ={
}
},["11"] ={["def_ratio"] =1.1,["lord_lv"] =2400,["hp_ratio"] =1.1,["atk_ratio"] =1.1,["order_spend"] =24000,["conditions"] ={
}
},["12"] ={["def_ratio"] =1.2,["lord_lv"] =2800,["hp_ratio"] =1.2,["atk_ratio"] =1.2,["order_spend"] =30000,["conditions"] ={
}
},["13"] ={["def_ratio"] =1.3,["lord_lv"] =3200,["hp_ratio"] =1.3,["atk_ratio"] =1.3,["order_spend"] =40000,["conditions"] ={
}
},["14"] ={["def_ratio"] =1.4,["lord_lv"] =3600,["hp_ratio"] =1.4,["atk_ratio"] =1.4,["order_spend"] =50000,["conditions"] ={
}
},["15"] ={["def_ratio"] =1.5,["lord_lv"] =4000,["hp_ratio"] =1.5,["atk_ratio"] =1.5,["order_spend"] =100000,["conditions"] ={
}
},["16"] ={["def_ratio"] =1.6,["lord_lv"] =4500,["hp_ratio"] =1.6,["atk_ratio"] =1.6,["order_spend"] =150000,["conditions"] ={
{["type"] =10,["value"] =2}}
},["17"] ={["def_ratio"] =1.7,["lord_lv"] =5000,["hp_ratio"] =1.7,["atk_ratio"] =1.7,["order_spend"] =200000,["conditions"] ={
{["type"] =10,["value"] =3}}
},["18"] ={["def_ratio"] =1.8,["lord_lv"] =5500,["hp_ratio"] =1.8,["atk_ratio"] =1.8,["order_spend"] =250000,["conditions"] ={
{["type"] =10,["value"] =4}}
},["19"] ={["def_ratio"] =1.9,["lord_lv"] =6000,["hp_ratio"] =1.9,["atk_ratio"] =1.9,["order_spend"] =-1,["conditions"] ={
}
}}
