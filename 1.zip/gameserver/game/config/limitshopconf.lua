local config = {
    ["10001"]={id="10001", title="宝箱限购",   recharge_total=30,  payment=30, limit=1, reward= {gold=300, box_lv1=20, box_lv2=10}},
    ["10002"]={id="10002", title="超值白玉箱", recharge_total=128,  payment=128, limit=1, reward= {gold=1280, baiyu=10000, caiyu=5}},
    ["10003"]={id="10003", title="玩具转换箱", recharge_total=198,  payment=198, limit=1, reward= {gold=1980, wanjuzhuanhuanshi=1}},
    ["10004"]={id="10004", title="豪华彩玉箱", recharge_total=648,  payment=648, limit=648, reward= {gold=6480, caiyu=99}},
    ["10005"]={id="10005", title="超值宝箱",   recharge_total=328,  payment=328, limit=5, reward= {box_lv1=50, box_lv2=20, box_lv3=10, box_lv4=10}},
    ["10006"]={id="10006", title="豪华进阶石", recharge_total=648,  payment=648, limit=5, reward= {gold=6480, zhaomuling=50, jinjieshi=10000}},
    ["10007"]={id="10007", title="古老梦魇箱", recharge_total=648,  payment=648, limit=5, reward= {gold=6480, jingshi=5000, jinjieshi=10000}},
    ["10008"]={id="10008", title="尊贵渔具箱", recharge_total=648,  payment=648, limit=5, reward= {gold=6480, yugan_lv1=100, yugan_lv2=50}},
}

return config