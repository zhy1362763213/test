return {
    ["1"] = {
        ["start"] = 0,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 300
            }
        },
        ["end"] = 35,
        ["stage"] = 1
    },
    ["2"] = {
        ["start"] = 35,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 400
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 500
            }
        },
        ["end"] = 70,
        ["stage"] = 2
    },
    ["3"] = {
        ["start"] = 70,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 500
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 20
            }
        },
        ["end"] = 105,
        ["stage"] = 3
    },
    ["4"] = {
        ["start"] = 105,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 600
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 1000
            }
        },
        ["end"] = 140,
        ["stage"] = 4
    },
    ["5"] = {
        ["start"] = 140,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 700
            },
            {
                ["key"] = "libao_wujiang_hong1",
                ["value"] = 10
            }
        },
        ["end"] = 175,
        ["stage"] = 5
    },
    ["6"] = {
        ["start"] = 175,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 800
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 2000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 30
            }
        },
        ["end"] = 210,
        ["stage"] = 6
    },
    ["7"] = {
        ["start"] = 210,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 900
            }
        },
        ["end"] = 245,
        ["stage"] = 7
    },
    ["8"] = {
        ["start"] = 245,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 1000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 3000
            }
        },
        ["end"] = 280,
        ["stage"] = 8
    },
    ["9"] = {
        ["start"] = 280,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 1200
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 40
            }
        },
        ["end"] = 315,
        ["stage"] = 9
    },
    ["10"] = {
        ["start"] = 315,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 1400
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 5000
            },
            {
                ["key"] = "libao_wujiang_hong1",
                ["value"] = 20
            }
        },
        ["end"] = 350,
        ["stage"] = 10
    },
    ["11"] = {
        ["start"] = 350,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 1600
            }
        },
        ["end"] = 385,
        ["stage"] = 11
    },
    ["12"] = {
        ["start"] = 385,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 1800
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 7500
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 50
            }
        },
        ["end"] = 420,
        ["stage"] = 12
    },
    ["13"] = {
        ["start"] = 420,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 2000
            }
        },
        ["end"] = 455,
        ["stage"] = 13
    },
    ["14"] = {
        ["start"] = 455,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 2200
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 10000
            }
        },
        ["end"] = 490,
        ["stage"] = 14
    },
    ["15"] = {
        ["start"] = 490,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 2400
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 60
            },
            {
                ["key"] = "libao_wujiang_hong1",
                ["value"] = 40
            }
        },
        ["end"] = 525,
        ["stage"] = 15
    },
    ["16"] = {
        ["start"] = 525,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 2600
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 12500
            }
        },
        ["end"] = 560,
        ["stage"] = 16
    },
    ["17"] = {
        ["start"] = 560,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 2800
            }
        },
        ["end"] = 595,
        ["stage"] = 17
    },
    ["18"] = {
        ["start"] = 595,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 3000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 15000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 80
            }
        },
        ["end"] = 630,
        ["stage"] = 18
    },
    ["19"] = {
        ["start"] = 630,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 3200
            }
        },
        ["end"] = 665,
        ["stage"] = 19
    },
    ["20"] = {
        ["start"] = 665,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 3400
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 17500
            },
            {
                ["key"] = "libao_wujiang_hong1",
                ["value"] = 60
            }
        },
        ["end"] = 700,
        ["stage"] = 20
    },
    ["21"] = {
        ["start"] = 700,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 3600
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 100
            }
        },
        ["end"] = 735,
        ["stage"] = 21
    },
    ["22"] = {
        ["start"] = 735,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 3800
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 20000
            }
        },
        ["end"] = 770,
        ["stage"] = 22
    },
    ["23"] = {
        ["start"] = 770,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 4000
            }
        },
        ["end"] = 805,
        ["stage"] = 23
    },
    ["24"] = {
        ["start"] = 805,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 4200
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 22500
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 120
            }
        },
        ["end"] = 840,
        ["stage"] = 24
    },
    ["25"] = {
        ["start"] = 840,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 4400
            },
            {
                ["key"] = "libao_wujiang_hong1",
                ["value"] = 80
            }
        },
        ["end"] = 875,
        ["stage"] = 25
    },
    ["26"] = {
        ["start"] = 875,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 4600
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 25000
            }
        },
        ["end"] = 910,
        ["stage"] = 26
    },
    ["27"] = {
        ["start"] = 910,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 4800
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 140
            }
        },
        ["end"] = 945,
        ["stage"] = 27
    },
    ["28"] = {
        ["start"] = 945,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 5000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 27500
            }
        },
        ["end"] = 980,
        ["stage"] = 28
    },
    ["29"] = {
        ["start"] = 980,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 5200
            }
        },
        ["end"] = 1015,
        ["stage"] = 29
    },
    ["30"] = {
        ["start"] = 1015,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 5400
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 30000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 160
            },
            {
                ["key"] = "libao_wujiang_hong1",
                ["value"] = 100
            }
        },
        ["end"] = 1050,
        ["stage"] = 30
    },
    ["31"] = {
        ["start"] = 1050,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 5600
            }
        },
        ["end"] = 1085,
        ["stage"] = 31
    },
    ["32"] = {
        ["start"] = 1085,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 5800
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 35000
            }
        },
        ["end"] = 1120,
        ["stage"] = 32
    },
    ["33"] = {
        ["start"] = 1120,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 6000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 180
            }
        },
        ["end"] = 1155,
        ["stage"] = 33
    },
    ["34"] = {
        ["start"] = 1155,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 6200
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 40000
            }
        },
        ["end"] = 1190,
        ["stage"] = 34
    },
    ["35"] = {
        ["start"] = 1190,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 6400
            },
            {
                ["key"] = "libao_wujiang_hong1",
                ["value"] = 120
            }
        },
        ["end"] = 1225,
        ["stage"] = 35
    },
    ["36"] = {
        ["start"] = 1225,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 6600
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 45000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 200
            }
        },
        ["end"] = 1260,
        ["stage"] = 36
    },
    ["37"] = {
        ["start"] = 1260,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 6800
            }
        },
        ["end"] = 1295,
        ["stage"] = 37
    },
    ["38"] = {
        ["start"] = 1295,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 7000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 50000
            }
        },
        ["end"] = 1330,
        ["stage"] = 38
    },
    ["39"] = {
        ["start"] = 1330,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 7200
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 220
            }
        },
        ["end"] = 1365,
        ["stage"] = 39
    },
    ["40"] = {
        ["start"] = 1365,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 7400
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 55000
            },
            {
                ["key"] = "libao_wujiang_hong1",
                ["value"] = 140
            }
        },
        ["end"] = 1400,
        ["stage"] = 40
    },
    ["41"] = {
        ["start"] = 1400,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 7600
            }
        },
        ["end"] = 1435,
        ["stage"] = 41
    },
    ["42"] = {
        ["start"] = 1435,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 7800
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 60000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 240
            }
        },
        ["end"] = 1470,
        ["stage"] = 42
    },
    ["43"] = {
        ["start"] = 1470,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 8000
            }
        },
        ["end"] = 1505,
        ["stage"] = 43
    },
    ["44"] = {
        ["start"] = 1505,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 8200
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 65000
            }
        },
        ["end"] = 1540,
        ["stage"] = 44
    },
    ["45"] = {
        ["start"] = 1540,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 8400
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 260
            },
            {
                ["key"] = "libao_wujiang_hong1",
                ["value"] = 160
            }
        },
        ["end"] = 1575,
        ["stage"] = 45
    },
    ["46"] = {
        ["start"] = 1575,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 8600
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 70000
            }
        },
        ["end"] = 1610,
        ["stage"] = 46
    },
    ["47"] = {
        ["start"] = 1610,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 8800
            }
        },
        ["end"] = 1645,
        ["stage"] = 47
    },
    ["48"] = {
        ["start"] = 1645,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 9000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 75000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 280
            }
        },
        ["end"] = 1680,
        ["stage"] = 48
    },
    ["49"] = {
        ["start"] = 1680,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 9200
            }
        },
        ["end"] = 1715,
        ["stage"] = 49
    },
    ["50"] = {
        ["start"] = 1715,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 9400
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 80000
            },
            {
                ["key"] = "libao_wujiang_hong1",
                ["value"] = 180
            }
        },
        ["end"] = 1750,
        ["stage"] = 50
    },
    ["51"] = {
        ["start"] = 1750,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 9600
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 300
            }
        },
        ["end"] = 1785,
        ["stage"] = 51
    },
    ["52"] = {
        ["start"] = 1785,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 9800
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 85000
            }
        },
        ["end"] = 1820,
        ["stage"] = 52
    },
    ["53"] = {
        ["start"] = 1820,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            }
        },
        ["end"] = 1855,
        ["stage"] = 53
    },
    ["54"] = {
        ["start"] = 1855,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 90000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 320
            }
        },
        ["end"] = 1890,
        ["stage"] = 54
    },
    ["55"] = {
        ["start"] = 1890,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "libao_wujiang_hong1",
                ["value"] = 200
            }
        },
        ["end"] = 1925,
        ["stage"] = 55
    },
    ["56"] = {
        ["start"] = 1925,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 95000
            }
        },
        ["end"] = 1960,
        ["stage"] = 56
    },
    ["57"] = {
        ["start"] = 1960,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 340
            }
        },
        ["end"] = 1995,
        ["stage"] = 57
    },
    ["58"] = {
        ["start"] = 1995,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 100000
            }
        },
        ["end"] = 2030,
        ["stage"] = 58
    },
    ["59"] = {
        ["start"] = 2030,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            }
        },
        ["end"] = 2065,
        ["stage"] = 59
    },
    ["60"] = {
        ["start"] = 2065,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 100000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 360
            },
            {
                ["key"] = "libao_wujiang_hong1",
                ["value"] = 220
            }
        },
        ["end"] = 2100,
        ["stage"] = 60
    },
    ["61"] = {
        ["start"] = 2100,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            }
        },
        ["end"] = 2135,
        ["stage"] = 61
    },
    ["62"] = {
        ["start"] = 2135,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 100000
            }
        },
        ["end"] = 2170,
        ["stage"] = 62
    },
    ["63"] = {
        ["start"] = 2170,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 380
            }
        },
        ["end"] = 2205,
        ["stage"] = 63
    },
    ["64"] = {
        ["start"] = 2205,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 100000
            }
        },
        ["end"] = 2240,
        ["stage"] = 64
    },
    ["65"] = {
        ["start"] = 2240,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "libao_wujiang_hong1",
                ["value"] = 240
            }
        },
        ["end"] = 2275,
        ["stage"] = 65
    },
    ["66"] = {
        ["start"] = 2275,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 100000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 400
            }
        },
        ["end"] = 2310,
        ["stage"] = 66
    },
    ["67"] = {
        ["start"] = 2310,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            }
        },
        ["end"] = 2345,
        ["stage"] = 67
    },
    ["68"] = {
        ["start"] = 2345,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 100000
            }
        },
        ["end"] = 2380,
        ["stage"] = 68
    },
    ["69"] = {
        ["start"] = 2380,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 400
            }
        },
        ["end"] = 2415,
        ["stage"] = 69
    },
    ["70"] = {
        ["start"] = 2415,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 100000
            },
            {
                ["key"] = "libao_wujiang_hong1",
                ["value"] = 260
            }
        },
        ["end"] = 2450,
        ["stage"] = 70
    },
    ["71"] = {
        ["start"] = 2450,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            }
        },
        ["end"] = 2485,
        ["stage"] = 71
    },
    ["72"] = {
        ["start"] = 2485,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 100000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 400
            }
        },
        ["end"] = 2520,
        ["stage"] = 72
    },
    ["73"] = {
        ["start"] = 2520,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            }
        },
        ["end"] = 2555,
        ["stage"] = 73
    },
    ["74"] = {
        ["start"] = 2555,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 100000
            }
        },
        ["end"] = 2590,
        ["stage"] = 74
    },
    ["75"] = {
        ["start"] = 2590,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 400
            },
            {
                ["key"] = "libao_wujiang_hong1",
                ["value"] = 270
            }
        },
        ["end"] = 2625,
        ["stage"] = 75
    },
    ["76"] = {
        ["start"] = 2625,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 100000
            }
        },
        ["end"] = 2660,
        ["stage"] = 76
    },
    ["77"] = {
        ["start"] = 2660,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            }
        },
        ["end"] = 2695,
        ["stage"] = 77
    },
    ["78"] = {
        ["start"] = 2695,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 100000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 400
            }
        },
        ["end"] = 2730,
        ["stage"] = 78
    },
    ["79"] = {
        ["start"] = 2730,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            }
        },
        ["end"] = 2765,
        ["stage"] = 79
    },
    ["80"] = {
        ["start"] = 2765,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 100000
            },
            {
                ["key"] = "libao_wujiang_hong1",
                ["value"] = 300
            }
        },
        ["end"] = 2800,
        ["stage"] = 80
    },
    ["81"] = {
        ["start"] = 2800,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 400
            }
        },
        ["end"] = 2835,
        ["stage"] = 81
    },
    ["82"] = {
        ["start"] = 2835,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 100000
            }
        },
        ["end"] = 2870,
        ["stage"] = 82
    },
    ["83"] = {
        ["start"] = 2870,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            }
        },
        ["end"] = 2905,
        ["stage"] = 83
    },
    ["84"] = {
        ["start"] = 2905,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 100000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 400
            }
        },
        ["end"] = 2940,
        ["stage"] = 84
    },
    ["85"] = {
        ["start"] = 2940,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "libao_wujiang_hong1",
                ["value"] = 320
            }
        },
        ["end"] = 2975,
        ["stage"] = 85
    },
    ["86"] = {
        ["start"] = 2975,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 100000
            }
        },
        ["end"] = 3010,
        ["stage"] = 86
    },
    ["87"] = {
        ["start"] = 3010,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 400
            }
        },
        ["end"] = 3045,
        ["stage"] = 87
    },
    ["88"] = {
        ["start"] = 3045,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 100000
            }
        },
        ["end"] = 3080,
        ["stage"] = 88
    },
    ["89"] = {
        ["start"] = 3080,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            }
        },
        ["end"] = 3115,
        ["stage"] = 89
    },
    ["90"] = {
        ["start"] = 3115,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 100000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 400
            },
            {
                ["key"] = "libao_wujiang_hong1",
                ["value"] = 340
            }
        },
        ["end"] = 3150,
        ["stage"] = 90
    },
    ["91"] = {
        ["start"] = 3150,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            }
        },
        ["end"] = 3185,
        ["stage"] = 91
    },
    ["92"] = {
        ["start"] = 3185,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "jinjieshi",
                ["value"] = 100000
            }
        },
        ["end"] = 3220,
        ["stage"] = 92
    },
    ["93"] = {
        ["start"] = 3220,
        ["reward_items"] = {
            {
                ["key"] = "gold",
                ["value"] = 10000
            },
            {
                ["key"] = "zhaomuling",
                ["value"] = 400
            }
        },
        ["end"] = 3255,
        ["stage"] = 93
    }
}
