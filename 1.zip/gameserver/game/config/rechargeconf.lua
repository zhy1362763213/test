local rechargeconf={}

local config={
    ["1001"]={payment=6,gold=60,song_gold=10},
    ["1002"]={payment=30,gold=300,song_gold=40},
    ["1003"]={payment=68,gold=680,song_gold=140},
    ["1004"]={payment=128,gold=1280,song_gold=380},
    ["1005"]={payment=328,gold=3280,song_gold=1340},
    ["1006"]={payment=648,gold=6480,song_gold=3600},

}

function rechargeconf.getconf(id)
    return config[tostring(id)]
end

return rechargeconf