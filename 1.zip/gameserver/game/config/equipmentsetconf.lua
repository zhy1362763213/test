return {
    ["7"] = {
      ["setnum"] = 2,
      ["id"] = 7,
      ["setattrs"] = {
        {
          ["type"] = "xue",
          ["value"] = 0.15
        }
      },
      ["color"] = 4
    },
    ["3"] = {
      ["setnum"] = 2,
      ["id"] = 3,
      ["setattrs"] = {
        {
          ["type"] = "xue",
          ["value"] = 0.05
        }
      },
      ["color"] = 2
    },
    ["8"] = {
      ["setnum"] = 4,
      ["id"] = 8,
      ["setattrs"] = {
        {
          ["type"] = "xue",
          ["value"] = 0.15
        },
        {
          ["type"] = "xue",
          ["value"] = 0.25
        }
      },
      ["color"] = 4
    },
    ["4"] = {
      ["setnum"] = 4,
      ["id"] = 4,
      ["setattrs"] = {
        {
          ["type"] = "xue",
          ["value"] = 0.05
        },
        {
          ["type"] = "xue",
          ["value"] = 0.15
        }
      },
      ["color"] = 2
    },
    ["9"] = {
      ["setnum"] = 2,
      ["id"] = 9,
      ["setattrs"] = {
        {
          ["type"] = "xue",
          ["value"] = 0.2
        }
      },
      ["color"] = 5
    },
    ["5"] = {
      ["setnum"] = 2,
      ["id"] = 5,
      ["setattrs"] = {
        {
          ["type"] = "xue",
          ["value"] = 0.1
        }
      },
      ["color"] = 3
    },
    ["1"] = {
      ["setnum"] = 2,
      ["id"] = 1,
      ["setattrs"] = {

      },
      ["color"] = 1
    },
    ["6"] = {
      ["setnum"] = 4,
      ["id"] = 6,
      ["setattrs"] = {
        {
          ["type"] = "xue",
          ["value"] = 0.1
        },
        {
          ["type"] = "xue",
          ["value"] = 0.2
        }
      },
      ["color"] = 3
    },
    ["2"] = {
      ["setnum"] = 4,
      ["id"] = 2,
      ["setattrs"] = {

      },
      ["color"] = 1
    },
    ["10"] = {
      ["setnum"] = 4,
      ["id"] = 10,
      ["setattrs"] = {
        {
          ["type"] = "xue",
          ["value"] = 0.2
        },
        {
          ["type"] = "xue",
          ["value"] = 0.3
        }
      },
      ["color"] = 5
    }

 }