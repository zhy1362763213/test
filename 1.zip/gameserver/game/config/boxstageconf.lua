return {
    ["1"] = {
      ["id"] = 1,
      ["value"] = "box_lv2",
      ["limit"] = 10
    },
    ["2"] = {
      ["id"] = 2,
      ["value"] = "box_lv2",
      ["limit"] = 20
    },
    ["3"] = {
      ["id"] = 3,
      ["value"] = "box_lv3",
      ["limit"] = 30
    },
    ["4"] = {
      ["id"] = 4,
      ["value"] = "box_lv4",
      ["limit"] = 40
    },
    ["5"] = {
      ["id"] = 5,
      ["value"] = "box_lv4",
      ["limit"] = 80
    },
    ["6"] = {
      ["id"] = 6,
      ["value"] = "box_lv4",
      ["limit"] = 100
    },
    ["7"] = {
      ["id"] = 7,
      ["value"] = "box_lv3",
      ["limit"] = 70
    },
    ["8"] = {
      ["id"] = 8,
      ["value"] = "box_lv4",
      ["limit"] = 50
    },
    ["9"] = {
      ["id"] = 9,
      ["value"] = "box_lv5",
      ["limit"] = 100
    },
 }