--[[
    积天好礼
]]
return {
    ["10"] = {
      ["completevalue"] = 10,
      ["id"] = 10,
      ["activityid"] = 10,
      ["params"] = {
        {
          ["itemid"] = 1003,
          ["value"] = 588,
          ["weight"] = 1,
          ["type"] = 3
        }
      }
    },
    ["2"] = {
      ["completevalue"] = 2,
      ["id"] = 2,
      ["activityid"] = 10,
      ["params"] = {
        {
          ["itemid"] = 1006,
          ["value"] = 488,
          ["weight"] = 1,
          ["type"] = 3
        }
      }
    },
    ["15"] = {
      ["completevalue"] = 15,
      ["id"] = 15,
      ["activityid"] = 10,
      ["params"] = {
        {
          ["itemid"] = 1013,
          ["value"] = 5,
          ["weight"] = 1,
          ["type"] = 3
        }
      }
    },
    ["3"] = {
      ["completevalue"] = 3,
      ["id"] = 3,
      ["activityid"] = 10,
      ["params"] = {
        {
          ["itemid"] = 0,
          ["value"] = 288,
          ["weight"] = 1,
          ["type"] = 2
        }
      }
    },
    ["11"] = {
      ["completevalue"] = 11,
      ["id"] = 11,
      ["activityid"] = 10,
      ["params"] = {
        {
          ["itemid"] = 1006,
          ["value"] = 788,
          ["weight"] = 1,
          ["type"] = 3
        }
      }
    },
    ["4"] = {
      ["completevalue"] = 4,
      ["id"] = 4,
      ["activityid"] = 10,
      ["params"] = {
        {
          ["itemid"] = 1003,
          ["value"] = 388,
          ["weight"] = 1,
          ["type"] = 3
        }
      }
    },
    ["5"] = {
      ["completevalue"] = 5,
      ["id"] = 5,
      ["activityid"] = 10,
      ["params"] = {
        {
          ["itemid"] = 1006,
          ["value"] = 588,
          ["weight"] = 1,
          ["type"] = 3
        }
      }
    },
    ["12"] = {
      ["completevalue"] = 12,
      ["id"] = 12,
      ["activityid"] = 10,
      ["params"] = {
        {
          ["itemid"] = 0,
          ["value"] = 488,
          ["weight"] = 1,
          ["type"] = 2
        }
      }
    },
    ["6"] = {
      ["completevalue"] = 6,
      ["id"] = 6,
      ["activityid"] = 10,
      ["params"] = {
        {
          ["itemid"] = 0,
          ["value"] = 288,
          ["weight"] = 1,
          ["type"] = 2
        }
      }
    },
    ["13"] = {
      ["completevalue"] = 13,
      ["id"] = 13,
      ["activityid"] = 10,
      ["params"] = {
        {
          ["itemid"] = 1003,
          ["value"] = 688,
          ["weight"] = 1,
          ["type"] = 3
        }
      }
    },
    ["7"] = {
      ["completevalue"] = 7,
      ["id"] = 7,
      ["activityid"] = 10,
      ["params"] = {
        {
          ["itemid"] = 1003,
          ["value"] = 488,
          ["weight"] = 1,
          ["type"] = 3
        }
      }
    },
    ["8"] = {
      ["completevalue"] = 8,
      ["id"] = 8,
      ["activityid"] = 10,
      ["params"] = {
        {
          ["itemid"] = 1006,
          ["value"] = 688,
          ["weight"] = 1,
          ["type"] = 3
        }
      }
    },
    ["14"] = {
      ["completevalue"] = 14,
      ["id"] = 14,
      ["activityid"] = 10,
      ["params"] = {
        {
          ["itemid"] = 1006,
          ["value"] = 888,
          ["weight"] = 1,
          ["type"] = 3
        }
      }
    },
    ["1"] = {
      ["completevalue"] = 1,
      ["id"] = 1,
      ["activityid"] = 10,
      ["params"] = {
        {
          ["itemid"] = 1003,
          ["value"] = 288,
          ["weight"] = 1,
          ["type"] = 3
        }
      }
    },
    ["9"] = {
      ["completevalue"] = 9,
      ["id"] = 9,
      ["activityid"] = 10,
      ["params"] = {
        {
          ["itemid"] = 0,
          ["value"] = 488,
          ["weight"] = 1,
          ["type"] = 2
        }
      }
    }

 }