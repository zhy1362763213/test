return {
    ["1"] = {
      ["id"] = 1,
      ["cardrewarddaily"] = {
        {
          ["itemid"] = 0,
          ["value"] = 10,
          ["weight"] = 1,
          ["type"] = 2
        }
      },
      ["activityid"] = 11,
      ["cardbenefit"] = {

      },
      ["rank"] = 4,
      ["tips"] = "cardconf_tips_1",
      ["cardspend"] = 0,
      ["cardreward"] = {

      },
      ["cardday"] = -1,
      ["carddescription"] = "",
      ["name"] = "cardconf_name_1"
    },
    ["4003"] = {
      ["id"] = 4003,
      ["cardrewarddaily"] = {
        {
          ["itemid"] = 0,
          ["value"] = 100,
          ["weight"] = 1,
          ["type"] = 2
        },
        {
          ["itemid"] = 1003,
          ["value"] = 200,
          ["weight"] = 1,
          ["type"] = 3
        }
      },
      ["activityid"] = 11,
      ["cardbenefit"] = {
        {
          ["benefit"] = 4,
          ["type"] = 11,
          ["value"] = 7200
        },
        {
          ["benefit"] = 4,
          ["type"] = 4,
          ["value"] = 0.10000000000000001
        }
      },
      ["rank"] = 1,
      ["tips"] = "cardconf_tips_4",
      ["cardspend"] = 12800,
      ["cardreward"] = {
        {
          ["itemid"] = 0,
          ["value"] = 1280,
          ["weight"] = 1,
          ["type"] = 2
        }
      },
      ["cardday"] = -1,
      ["carddescription"] = "cardconf_carddescription_3",
      ["name"] = "cardconf_name_4"
    },
    ["4001"] = {
      ["id"] = 4001,
      ["cardrewarddaily"] = {
        {
          ["itemid"] = 0,
          ["value"] = 100,
          ["weight"] = 1,
          ["type"] = 2
        }
      },
      ["activityid"] = 11,
      ["cardbenefit"] = {
        {
          ["benefit"] = 2,
          ["type"] = 4,
          ["value"] = 0.10000000000000001
        }
      },
      ["rank"] = 3,
      ["tips"] = "cardconf_tips_2",
      ["cardspend"] = 800,
      ["cardreward"] = {
        {
          ["itemid"] = 0,
          ["value"] = 100,
          ["weight"] = 1,
          ["type"] = 2
        }
      },
      ["cardday"] = 7,
      ["carddescription"] = "cardconf_carddescription_1",
      ["name"] = "cardconf_name_2"
    },
    ["4002"] = {
      ["id"] = 4002,
      ["cardrewarddaily"] = {
        {
          ["itemid"] = 0,
          ["value"] = 100,
          ["weight"] = 1,
          ["type"] = 2
        },
        {
          ["itemid"] = 1003,
          ["value"] = 100,
          ["weight"] = 1,
          ["type"] = 3
        },
        {
          ["itemid"] = 1010,
          ["value"] = 1,
          ["weight"] = 1,
          ["type"] = 3
        }
      },
      ["activityid"] = 11,
      ["cardbenefit"] = {
        {
          ["benefit"] = 3,
          ["type"] = 11,
          ["value"] = 7200
        }
      },
      ["rank"] = 2,
      ["tips"] = "cardconf_tips_3",
      ["cardspend"] = 3000,
      ["cardreward"] = {
        {
          ["itemid"] = 0,
          ["value"] = 300,
          ["weight"] = 1,
          ["type"] = 2
        }
      },
      ["cardday"] = 30,
      ["carddescription"] = "cardconf_carddescription_2",
      ["name"] = "cardconf_name_3"
    }

 }