return {["1"] ={["time"] =2,["price"] =1},["2"] ={["time"] =2,["price"] =6},["3"] ={["time"] =2,["price"] =12},["4"] ={["time"] =2,["price"] =18}}
 