local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
local daybuylogic  = require "daybuylogic"
require "functions"

--积天好礼模型

local daybuymodel = {}

function daybuymodel:init(days, receives)
    self.days = {}
    if days then
        for k,v in pairs(days) do
            self.days[checkint(k)] = checkint(v)  --self.days[日期]=累计总数
        end
    end
    self.receives = {}
    if receives then
        for k,v in pairs(receives) do
            self.receives[checkint(k)] = checkint(v) --self.days[天数]= 状态 1已领取
        end
    end
end

--积天好礼累计充值天数
function daybuymodel:getpaydaynum(payment)
    local n = 0
    for k, v in pairs(self.days) do
        if v >= 6 then
            n = n + 1
        end
    end
    return n
end

--积天好礼每日累计充值金额
function daybuymodel:add(payment)
    local date = dateutils.getday()
    local total = self.days[date] or 0
    total = total + payment
    self.days[date] = total
    skynet.call(".daybuyd", "lua", "add", UID, date, payment)
end

--是否可以领取
function daybuymodel:checkcanreceive(id)
    if self.receives[id] then
        return false
    end
    return true
end

--领取
function daybuymodel:receive(id)
    id = checkint(id)
    self.receives[id] = 1
    local ok = skynet.call(".daybuyd", "lua", "receive", UID, id)
end


function daybuymodel:serialize()
    local d = 0
    for k,v in pairs(self.days) do
        if tonumber(v) >= 6 then
            d = d + 1
        end
    end
    local temp = {}
    if d > 0 then
        for i=1, d do
            local t = {}
            t.id = i
            if self.receives[i] then
                t.status = 1
            else
                t.status = 0
            end
            table.insert(temp, t)
        end
    end
    return table.array(temp)
end

return daybuymodel
