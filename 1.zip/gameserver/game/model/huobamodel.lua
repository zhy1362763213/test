local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils    = require "dateutils"
local utils        = require "utils"
require "functions"

local pattern = "(%d+)-(%d+)-(%d+) (%d+):(%d+):(%d+)"
local huobamodel = {}

function huobamodel:init(usermodel, data)
    data = data or {}
    local m = data[1]
    local m = utils.redis_pack(m)
    self.usermodel          = usermodel
    self.huoba_lv           = checkint(m.huoba_lv)
    self.huoba_start_time   = checkint(m.huoba_start_time)
    self.huoba_timelong     = checkint(m.huoba_timelong)
    self.lv1_share_num      = checkint(data[2])
    self.lv1_adv_num        = checkint(data[3])
end


function huobamodel:userhuoba(lv)
    local t = lv * 10 * 60
    if not self.huoba_lv or self.huoba_lv ~= lv or self:calhuobatimelong() <= 0 then
        self.huoba_lv = lv
        self.huoba_start_time = os.time()
        self.huoba_timelong = t
    else
        self.huoba_timelong = self.huoba_timelong + t
    end
end

--计算火把攻击时长
function huobamodel:calhuobatimelong()
    local logintime = dateutils.get_timestamp_by_datetime(self.usermodel.last_login_time, pattern)
    if self.huoba_start_time > logintime then
        local t = math.max(0, os.time() - self.huoba_start_time)
        self.huoba_timelong = math.max(self.huoba_timelong - t, 0)
    else
        if self.usermodel.last_logout_time and self.usermodel.last_logout_time ~= "" then
            local logouttime = dateutils.get_timestamp_by_datetime(self.usermodel.last_logout_time, pattern)
            -- local t = logintime - logouttime
            local t = math.max(0, os.time() - logintime)
            self.huoba_timelong = math.max(self.huoba_timelong - t, 0)
            -- self.huoba_start_time = logintime
        end
    end
    return self.huoba_timelong
end

function huobamodel:share()
    assert(self.lv1_share_num < 1, "今日已分享")
    self.lv1_share_num = self.lv1_share_num + 1
    local ok = skynet.call(".huobad", "lua", "share", UID, self.lv1_share_num)
end

--看广告
function huobamodel:lookadv()
    assert(self.lv1_adv_num < 10, "看广告数量已达上限")
    self.lv1_adv_num = self.lv1_adv_num + 1
    local ok = skynet.call(".huobad", "lua", "lookadv", UID, self.lv1_adv_num)
end

function huobamodel:serialize()
    local info     = {}
    info.huoba_lv           = self.huoba_lv
    info.huoba_timelong     = self:calhuobatimelong()
    info.lv1_share_num      = 1 - self.lv1_share_num
    info.lv1_adv_num        = 10 - self.lv1_adv_num
    return info
end

function huobamodel:save()
    local info     = {}
    info.huoba_lv           = self.huoba_lv
    info.huoba_start_time   = self.huoba_start_time
    info.huoba_timelong     = self:calhuobatimelong()
    local ok = skynet.call(".huobad", "lua", "save", UID, info)
end

return huobamodel
