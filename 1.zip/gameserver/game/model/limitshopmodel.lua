local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
local shoplimitlogic  = require "shoplimitlogic"
require "functions"

--限购商城模型

local limitshop = {}

local cfg = shoplimitlogic.getconf()

function limitshop:init(shop)
    self.shop   = {}
    for k,v in pairs(cfg) do
        self.shop[k] = checkint(shop[k])
    end
end

function limitshop:buy(id)
    self.shop[id] = self.shop[id] + 1
    local ok = skynet.call(".limitshopd", "lua", "buy", UID, id)
end

function limitshop:checkbuy(id)
    id = tostring(id)
    local c = cfg[id]
    if c.limit <= self.shop[id] then
        return false
    end
    return true
end

function limitshop:serialize()
    local temp = {}
    for k,v in pairs(self.shop) do
        table.insert(temp, {id=k, num=v})
    end
    return temp
end


return limitshop
