local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils = require "dateutils"
local bagmodel  = require "bagmodel"
require "functions"

--好友模型

local friendmodel = {}

--好友列表
function friendmodel:init(friends, gives, receives)
    self.friends = {}
    for i,v in ipairs(friends) do
        table.insert(self.friends, v)
    end
    self.gives = {}
    for k,v in pairs(gives) do
        self.gives[checkint(k)] = tonumber(v)
    end
    self.receives = {}
    for k,v in pairs(receives) do
        self.receives[checkint(k)] = tonumber(v)
    end
end


function friendmodel:isfriend(friendid)
    for i,v in ipairs(self.friends) do
        if v.uid == friendid then
            return true
        end
    end
    return false
end

function friendmodel:addfriend(friend)
    table.insert(self.friends, friend)
    local ok = skynet.call(".friendd", "lua", "addfriend", UID, friend.uid)
end


function friendmodel:inneraddfriend(friend)
    table.insert(self.friends, friend)
end


--拉黑
function friendmodel:isblack(friendid)
    for i,v in ipairs(self.friends) do
        if v.uid == friendid then
            return v.status or 0
        end
    end
    return -1
end

--拉黑
function friendmodel:black(friendid)
    for i,v in ipairs(self.friends) do
        if v.uid == friendid then
            v.status = 1
        end
    end
    skynet.call(".friendd", "lua", "black", UID, friendid)
end

--删除拉黑
function friendmodel:delblack(friendid)
    for i,v in ipairs(self.friends) do
        if v.uid == friendid then
            v.status = 0
        end
    end
    skynet.call(".friendd", "lua", "delblack", UID, friendid)
end

function friendmodel:delete(friendid)
    for i,v in ipairs(self.friends) do
        if v.uid == friendid then
            table.remove(self.friends, i)
        end
    end
    skynet.call(".friendd", "lua", "delete", UID, friendid)
    skynet.call(".friendd", "lua", "delete", friendid, UID)
end


function friendmodel:checkgive(fid)
    fid = checkint(fid)
    local coin = self.gives[fid]
    return coin
end

function friendmodel:givecoin(fid, coin)
    fid = checkint(fid)
    self.gives[fid] = 1
    local ok = skynet.call(".friendd", "lua", "givecoin", UID, fid, coin)
end


function friendmodel:checkreceive(fid)
    fid = checkint(fid)
    local coin = self.receives[fid] or 0
    return coin ~= 0
end

function friendmodel:innergivecoin(fid, coin)
    fid = checkint(fid)
    self.receives[fid] = tonumber(coin)
end

function friendmodel:receivecoin(fid)
    fid = checkint(fid)
    local coin = self.receives[fid] or 0
    assert(coin ~= 0)
    self.receives[fid] = 0
    local ok = skynet.call(".friendd", "lua", "receivecoin", UID, fid)
    return coin
end

function friendmodel:checkgiveandreceive()
    local gives, receives = self:giveandreceive()
    return #gives > 0 or #receives > 0
end


function friendmodel:giveandreceive()
    local gives = {}
    local receives = {}
    for _,v in ipairs(self.friends) do
        local uid = checkint(v.uid)
        if not self.gives[uid] then
            table.insert(gives,uid)
        end
        if self.receives[uid] == 0 then
            table.insert(receives, uid)
        end
    end
    return gives, receives
end

function friendmodel:serialize()

    for _,v in ipairs(self.friends) do
        local uid = checkint(v.uid)
        v.is_give = self.gives[uid] or 0
        v.receive_coin = self.receives[uid] or 0
    end

    table.sort( self.friends, function(a, b)
        if a.max_level == b.max_level then
            return tonumber(a.zhanli) > tonumber(b.zhanli)
        end
        return a.max_level > b.max_level
    end)
    return table.array(self.friends)
end


return friendmodel
