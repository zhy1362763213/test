local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
require "functions"

--vip专属折扣

local vipmodel = {}

function vipmodel:init(receives)
    self.receives = {}
    for k, v in pairs(receives) do
        self.receives[checkint(k)] = 1
    end
end

function vipmodel:checkreceive(id)
    id = checkint(id)
    return self.receives[id]
end

function vipmodel:receive(id)
    id = checkint(id)
    self.receives[id] = 1
    local ok = skynet.call(".vipd", "lua", "receive", UID, id)
end


function vipmodel:serialize()
    local resp = {}
    for k,v in pairs(self.receives) do
        table.insert(resp, {id=k})
    end
    return table.array(resp)
end

return vipmodel
