local skynet = require "skynet"
local cjson  = require "cjson"
local inviteconf   = require "inviteconf"
local dateutils  = require "dateutils"
require "functions"

--邀请好友模型

local invitemodel = {}

function invitemodel:init(invite_num, receives)
    data           = data or {}
    self.receives = {}
    self.invite_num = checkint(invite_num)
    for k,v in pairs(inviteconf) do
        if receives[k] then
            self.receives[k] = 1
        else
            self.receives[k] = 0
        end
    end
end


function invitemodel:checkreceive(id)
    local cfg = inviteconf[tostring(id)]
    DEBUG("cfg = ", DUMP(cfg))
    if self.invite_num >= cfg.invite_num and self.receives[id] == 0 then
        return true
    end
    return false
end


--签到
function invitemodel:receive(id)
    self.receives[checkint(id)] = true
    local ok = skynet.call(".invited", "lua", "receive", UID, id)
end


function invitemodel:serialize()
    local info = {}
    info.invite_num = self.invite_num
    local list = {}
    for k,v in pairs(self.receives) do
        table.insert(list, {id=k, status=v})
    end
    info.list = table.array(list)
    return info
end

return invitemodel
