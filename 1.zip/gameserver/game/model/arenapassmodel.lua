local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
require "functions"

--通行证模型

local arenapassmodel = {}

function arenapassmodel:init(data, level)
    data        = data or {}
    self.score  = checkint(data.score)
    self.stage1 = checkint(data.stage1)
    self.stage2 = checkint(data.stage2)
    self.level  = checkint(level)
end



return arenapassmodel
