local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
require "functions"

--7日登陆签到模型

local signin7model = {}

function signin7model:init(data)
    data        = data or {}
    self.signin7info = {}
    for k,v in pairs(data) do
        self.signin7info[checkint(k)] = true
    end
end


function signin7model:checksignin()
    local today = dateutils.getday()
    return self.signin7info[checkint(today)]
end


--签到
function signin7model:signin()
    local today = dateutils.getday()
    self.signin7info[checkint(today)] = true
    local ok = skynet.call(".signind", "lua", "signin7", UID, today)
end

function signin7model:getsignday()
    local n = 0
    for k,v in pairs(self.signin7info) do
        n = n + 1
    end
    return n
end

function signin7model:serialize()
    local info = {}
    for k,v in pairs(self.signin7info) do
        table.insert(info, {status=1})
    end
    if not self:checksignin() then
        table.insert(info, {status=0})
    end
    return table.array(info)
end

return signin7model
