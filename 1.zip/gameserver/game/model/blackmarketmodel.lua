local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
local blackmarketlogic  = require "blackmarketlogic"
local viplogic   = require "viplogic"
local usermodel  = require "usermodel"
require "functions"

--黑市模型

local cnf = blackmarketlogic.getconf()

local blackmarketmodel = {}

function blackmarketmodel:init(num, t1, t2)
    self.refresh_num = checkint(num)
    if #table.keys(t1) <= 0 then
        t1 = blackmarketlogic.randomdiscount()
        local ok = skynet.call(".blackmarketd", "lua", "save", UID, self.refresh_num ,t1)
    end
    self.discount = {}
    self.buy = {}
    for k,v in pairs(cnf) do
        self.discount[v.key_id] = checkint(t1[k])
        self.buy[checkint(v.key_id)] = checkint(t2[k])
    end
end

function blackmarketmodel:getrefreshnum()
    return self.refresh_num
end

function blackmarketmodel:getrefreshspeed()
    return blackmarketlogic.getrefreshspeed(self.refresh_num)
end


function blackmarketmodel:checkbuy(id)
    return self.buy[checkint(id)]
end

--获取金砖价格
function blackmarketmodel:getprice(id)
    local cfg = blackmarketlogic.getconfbyid(id)
    assert(cfg~=nil, "blackmarket conf not found")
    local gold = cfg.gold
    local d = self.discount[id]
    return checkint(gold * d / 10)
end


function blackmarketmodel:dobuy(id)
    id = checkint(id)
    self.buy[id] = 1
    local ok = skynet.call(".blackmarketd", "lua", "buy", UID, self.refresh_num, id)
end

function blackmarketmodel:chechrefresh()
    local vip_lv = usermodel:getviplv()
    local total = 3 + viplogic.getmarketrefreshnum(vip_lv)
    if self.refresh_num >= total then
        return false
    end
    return true
end

function blackmarketmodel:refresh()
    local rews = blackmarketlogic.randomdiscount()
    for k,v in pairs(cnf) do
        self.discount[v.key_id] = checkint(rews[k])
        self.buy[v.key_id] = 0
    end
    self.refresh_num = self.refresh_num + 1
    local ok = skynet.call(".blackmarketd", "lua", "save", UID, self.refresh_num ,rews)
end


function blackmarketmodel:serialize()
    local resp = {}
    resp.refresh_num = self.refresh_num
    local vip_lv = usermodel:getviplv()
    resp.refresh_total = 3 + viplogic.getmarketrefreshnum(vip_lv)
    resp.late_time = dateutils.getdayex()
    local goods = {}
    for k,v in pairs(self.discount) do
        goods[tostring(k)] = {id=k, discount=v, is_buy=self.buy[k]}
    end
    resp.goods = goods

    return resp
end


return blackmarketmodel
