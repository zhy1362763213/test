local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
require "functions"

--挂机模型

local guajimodel = {}

function guajimodel:init(data, receives)
    data        = data or {}
    self.base_time  = checkint(data.base_time or 4) --基础时长
    self.guaji_time  = checkint(data.guaji_time) --挂机时长
    self.guaji_lv    = checkint(data.guaji_lv) --基础等级
    self.last_receive_time = checkint(data.last_receive_time) --最后领取挂机奖励时间

    if self.last_receive_time == 0 then
        self.last_receive_time = os.time()
    end

    self.last_share_time   = checkint(data.last_share_time)
    self.receives = {}
    for k,v in pairs(receives) do
        self.receives[checkint(k)] = true
    end
end


function guajimodel:setbasetime(time)
    self.base_time = checkint(time)
    self:save()
end

function guajimodel:caltotalguajitime()
    return self.base_time * 3600 + self.guaji_time
end


--领取挂机收益
function guajimodel:receiveguajireward()
    local time = math.min(self:calguajitime(), self:caltotalguajitime()) --挂机时长 秒
    self.last_receive_time = os.time() --最后领取收益的时间
    self:save()
    --TODO:根据挂机时长计算奖励
    return time
end

--计算已经挂机的时长
function guajimodel:calguajitime()
    local t = math.min(os.time() - self.last_receive_time, self:caltotalguajitime())
    return t
end

function guajimodel:getguajilv()
    return math.max(1, self.guaji_lv)
end

function guajimodel:guajilvup()
    self.guaji_lv = self:getguajilv() + 1
    self:save()
end


function guajimodel:receive(id)
    self.receives[checkint(id)] = true
    skynet.call(".guajid", "lua", "receive", UID, id)
end

function guajimodel:checkreceive(id)
    return self.receives[checkint(id)]
end

function guajimodel:receiveid()
    local t = {}
    for k,v in pairs(self.receives) do
        table.insert(t, k)
    end
    return t
end

--计算可以分享的次数
function guajimodel:calsharnum()
    local s = os.time() - self.last_share_time
    local k = math.ceil(s/(2*3600))
    local e = math.min(4, k)
    return e
end

--计算剩余挂机时长
function guajimodel:calrestguajitime()
    local run_time = self:calguajitime() --挂机了多少秒
    return math.max(self:caltotalguajitime() - run_time, 0)
end

function guajimodel:addguajitime()
    self.guaji_time = self.guaji_time + 2*3600
    self.last_share_time = os.time() --最后分享时间
    self:save()
end

function guajimodel:serialize()
    local info = {}
    info.base_guaji_timelong     = self.base_guaji_timelong
    info.cur_guaji_timelong      = self:calguajitime()
    info.rest_guaji_timelong     = self:calrestguajitime()
    info.guaji_lv                = self:getguajilv()
    info.share_num               = self:calsharnum()
    local receives = {}
    for k, v in pairs(self.receives) do
        table.insert(receives, k)
    end
    info.receives = table.array(receives)
    return info
end

function guajimodel:save()
    local data = {}
    data.base_time   = self.base_time  --基础时长
    data.guaji_time  = self.guaji_time --挂机时长
    data.guaji_lv    = self:getguajilv()  --基础等级
    data.last_receive_time = self.last_receive_time --最后领取挂机奖励时间
    data.last_share_time   = self.last_share_time
    local ok = skynet.call(".guajid", "lua", "save", UID, data)
    DEBUG("guajid save ok = ", ok)
end

return guajimodel
