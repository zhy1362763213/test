local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
require "functions"

--邮件模型

local towermodel = {}

function towermodel:init(laststatus)
    self.laststatus = laststatus
end

function towermodel:openbox()
    self.laststatus = 1
end

return towermodel
