local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
local fukalogic  = require "fukalogic"
require "functions"

--福卡模型

local fukamodel = {}

function fukamodel:init(t1, t2)
    self.fuka = {}

    for k,v in pairs(t1) do
        self.fuka[checkint(k)] = tonumber(v)
    end

    self.receives = {}
    for k,v in pairs(t2) do
        self.receives[checkint(k)] = v
    end
end

function fukamodel:checkbuy(fukaid)
    fukaid = checkint(fukaid)
    return self.fuka[fukaid]
end

--购买福卡
function fukamodel:buyfuka(fukaid)
    fukaid = checkint(fukaid)
    local cfg = fukalogic.getconfbyid(fukaid)
    self.fuka = self.fuka or {}
    if cfg.card_day == -1 then
        local ex = -1
        self.fuka[fukaid] = ex
        skynet.call(".fukad", "lua", "buy", UID, fukaid, ex)
    else
        local ex = os.time() + cfg.card_day * 86400
        self.fuka[fukaid] = ex
        skynet.call(".fukad", "lua", "buy", UID, fukaid, ex)
    end
end


function fukamodel:getfukabyid(fukaid)
    fukaid = checkint(fukaid)
    return self.fuka[fukaid]
end

function fukamodel:getreceiveinfo(fukaid)
    fukaid = checkint(fukaid)
    return self.receives[fukaid]
end

--领取福卡福利
function fukamodel:receive(fukaid)
    fukaid = checkint(fukaid)
    self.receives[fukaid] = os.time()
    skynet.call(".fukad", "lua", "receive", UID, fukaid, os.time())
end

function fukamodel:serialize()
    local resp = {}
    local cfg = fukalogic.getconf()
    for k, v in pairs(cfg) do
        local temp = {}
        temp.id = k
        local status = 0
        if v.price == 0 or (self.fuka[checkint(k)] and (self.fuka[checkint(k)] == -1 or self.fuka[checkint(k)] > os.time())) then
            status = 1
            if self.receives[checkint(k)] then
                status = 2
            end
        end
        temp.status = status
        resp[k] = temp
    end
    return resp
end

return fukamodel
