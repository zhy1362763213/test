local skynet = require "skynet"
local cjson  = require "cjson"
require "functions"

local crystalmodel = class(crystalmodel)

function crystalmodel:ctor(data)
    data = data or {}
end



function crystalmodel:serialize()
    local info     = {}
    return info
end

return crystalmodel
