local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils = require "dateutils"
local viplogic  = require "viplogic"

require "functions"

--点金模型

local coingetmodel = {}


function coingetmodel:init(usermodel, num)
    self.usermodel  = usermodel
    self.num        = checkint(num)
    self.day        = dateutils.getday()
end


function coingetmodel:reset()
    if tonumber(self.day) ~= dateutils.getday() then
        self.num = 0
    end
end


function coingetmodel:coingetnum()
    return self.num
end


function coingetmodel:coingettotalnum()
    return 10 + viplogic.getcoingetnum(self.usermodel:getviplv())
end


function coingetmodel:coinget(num)
    num = checkint(num)
    self.num = self.num + num
    self.day = dateutils.getday()
    local ok = skynet.call(".coingetd", "lua", "incrby", UID, num)
end

return coingetmodel
