local skynet = require "skynet"
local cjson  = require "cjson"
local equipmentlogic  = require "equipmentlogic"
local mqhelper  = require "mqhelper"
local settings  = require "settings"
require "functions"
local equipmentmodel  = class(equipmentmodel)


local KYES = {weapon=1, cloth=2, head=3, horse=4}

function equipmentmodel:ctor(heromodel, heroid, tp, data)
    self.heromodel           = heromodel
    self.heroid              = heroid
    self.tp                  = tp
    self.type                = KYES[tp]
    data = data or {}
    self.lv                  = data.lv or 1
    self.incr_val            = data.incr_val or 0--属性额外增加数值
    self.pos1                = {open_status=0, lock_status=0, attr_id=0, prize_ratio=0, attr_ratio=0}
    self.pos2                = {open_status=0, lock_status=0, attr_id=0, prize_ratio=0, attr_ratio=0}
    self.pos3                = {open_status=0, lock_status=0, attr_id=0, prize_ratio=0, attr_ratio=0}
    self.pos4                = {open_status=0, lock_status=0, attr_id=0, prize_ratio=0, attr_ratio=0}
    self.pos5                = {open_status=0, lock_status=0, attr_id=0, prize_ratio=0, attr_ratio=0}
end


function equipmentmodel:getid()
    return self.id
end

function equipmentmodel:getlv()
    return self.lv
end

function equipmentmodel:calsetnum(t)
    table.sort(t)
    local t1 ={}
    for _,v in pairs(t) do
        if t1[v] == nil then
            t1[v] = 1
        else
            t1[v] = t1[v] + 1
        end
    end
end


function equipmentmodel:calsetattr(stage)
    local eqps = self.heromodel:getequipment(self.heroid)
    local n = 0
    for k,v in pairs(eqps) do
        if v:getcolor() == stage then
            n = n + 1
        end
    end
    return equipmentlogic.getsetattr(stage, n)
end

function equipmentmodel:serialize()
    local info     = {}
    local color          = equipmentlogic.getcolor(self.lv)
    info.id              = equipmentlogic.getid(color, self.type)
    info.lv              = self.lv
    info.type            = self.type
    info.atk             = self:getatk()
    info.hp              = self:gethp()
    info.def             = self:getdef()
    info.color           = color
    info.setattr         = self:calsetattr(info.color) -- 套装属性
    return info
end

--保存数据
function equipmentmodel:save2serialize()
    local info           = {}
    info.lv              = self.lv
    info.incr_val        = self.incr_val or 0--属性额外增加数值
    -- info.pos1            = {open_status=0, lock_status=0, attr_id=0, prize_ratio=0, attr_ratio=0}
    -- info.pos2            = {open_status=0, lock_status=0, attr_id=0, prize_ratio=0, attr_ratio=0}
    -- info.pos3            = {open_status=0, lock_status=0, attr_id=0, prize_ratio=0, attr_ratio=0}
    -- info.pos4            = {open_status=0, lock_status=0, attr_id=0, prize_ratio=0, attr_ratio=0}
    -- info.pos5            = {open_status=0, lock_status=0, attr_id=0, prize_ratio=0, attr_ratio=0}
    return info
end

function equipmentmodel:getcolor()
    return equipmentlogic.getcolor(self.lv)
end

function equipmentmodel:getatk()
    return equipmentlogic.getatk(self.tp, self.lv)
end

function equipmentmodel:getdef()
    return equipmentlogic.getdef(self.tp, self.lv)
end


function equipmentmodel:gethp()
    return equipmentlogic.gethp(self.tp, self.lv)
end


function equipmentmodel:getspeed()
    return equipmentlogic.getspeed(self.tp, self.lv)
end


function equipmentmodel:lvup(lv)
    self.lv = self.lv + lv
    self.heromodel:save(self.heroid)
end

function equipmentmodel:setlv(lv)
    self.lv = lv
    self.heromodel:save(self.heroid)
end

function equipmentmodel:reborn()
    self.lv = 1
    self.heromodel:save(self.heroid)
end

function equipmentmodel:calcurlvusejingtie()
    return equipmentlogic.calcurlvusejingtie(self.lv)
end

return equipmentmodel
