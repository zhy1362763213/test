local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
require "functions"

--基金模型

local fundmodel = {}

function fundmodel:init(data)
    self.fund = {}
    for fundid, task in pairs(data) do
        local ok, t = pcall(cjson.decode, task)
        assert(ok, "init fund failed")
        if ok then
            fundid = checkint(fundid)
            self.fund[tostring(fundid)] = t
        end
    end
end

--购买基金
function fundmodel:buyfund(fundid)
    fundid = checkint(fundid)
    self.fund[tostring(fundid)] =  {}
    local ok = pcall(skynet.call, ".fundd", "lua", "buy", UID, fundid, cjson.encode(self.fund[tostring(fundid)]))
end


--是否购买基金
function fundmodel:getmyfund()
    return self.fund
end


function fundmodel:gettasks(fundid)
    fundid = checkint(fundid)
    local tasks = {}
    for _, taskid in ipairs(self.fund[tostring(fundid)]) do
        tasks[tostring(taskid)] = true
    end
    return tasks
end

--领取基金
function fundmodel:receive(fundid, taskid)
    fundid = checkint(fundid)
    taskid = checkint(taskid)
    table.insert(self.fund[tostring(fundid)], tostring(taskid))
    local ok = pcall(skynet.call, ".fundd", "lua", "receive", UID, fundid, cjson.encode(self.fund[tostring(fundid)]))
end


--获取基金信息
function fundmodel:serialize()
    local temp = {}
    for k,v in pairs(self.fund) do
        local t = {}
        t.id = k
        t.tasks = {}
        for _,v1 in ipairs(v) do
            table.insert(t.tasks, v1)
        end
        t.tasks = table.array(t.tasks)
        table.insert(temp, t)
    end
    return table.array(temp)
end


return fundmodel
