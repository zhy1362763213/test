local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
local dailydeallogic  = require "dailydeallogic"


require "functions"

--每日特惠礼模型

local dailydealmodel = {}

function dailydealmodel:init(temp1, temp2)
    self.buys   = {}
    for k,v in pairs(temp1) do
        self.buys[checkint(k)] = checkint(v)
    end

    self.gets = {}
    for k, v in pairs(temp2) do
        local t1 = string.split(k, ":") --{id:day}
        local id = t1[1]
        id = checkint(id)
        self.gets[id] = self.gets[id] or {}
        table.insert(self.gets[id], tonumber(v))
    end
end


function dailydealmodel:serialize()
    local temps     = {}
    local cfg = dailydeallogic.getdailydealconf()
    for k, v in pairs(cfg) do
        local id = checkint(k)
        local temp          = {}
        temp.id             = k
        temp.day_limit      = self.buys[id] or 0
        temp.today_get_num  = self:caltodaygetnum(id) --今日领取次数
        temp.total_day_num  = self:caltotalgetnum(id) --总共领取天数
        table.insert(temps, temp)
    end
    return temps
end

--购买礼包
function dailydealmodel:buydailydeal(id)
    id = checkint(id)
    local cfg = dailydeallogic.getconf(id)
    local relation = cfg.relation
    if #relation > 1 then
        local daylimit = os.time() + cfg.card_day * 86400
        self.buys[id] = daylimit
        local ok = pcall(skynet.call, ".dailydeald", "lua", "buydailydeal", UID, id, daylimit)
        for i,v in ipairs(relation) do
            self.buys[v] = daylimit
            local ok = pcall(skynet.call, ".dailydeald", "lua", "buydailydeal", UID, v, daylimit)
        end
    else
        self.buys[id] = cfg.card_day --有效时间
        local ok = pcall(skynet.call, ".dailydeald", "lua", "buydailydeal", UID, id, cfg.card_day)
    end
end

--检查是否购买礼包
function dailydealmodel:checkbuy(id)
    id = checkint(id)
    if self.buys[id] then
        return true
    end
    return false
end

--检查有效时间
function dailydealmodel:checkcardday(id)
    id = checkint(id)
    local d = self.buys[id]
    if tonumber(d) == -1 then
        return true
    end
    if d < os.time() then
         return false
    end
    return true
end

--是否可以领取
function dailydealmodel:checktodaycanget(id)
    id = checkint(id)
    local cfg = dailydeallogic.getconf(id)
    local limit = cfg.limit
    local d = self.buys[id]
    if tonumber(d) == -1 then
        local gets = self.gets[id] or {}
        if #gets >= cfg.limit then
            return false
        end
    end
    if self:caltodaygetnum(id) >= limit then
        return false
    end
    return true
end

--今日领取次数
function dailydealmodel:caltodaygetnum(id)
    id = checkint(id)
    local gets = self.gets[id] or {}
    local n = 0
    for i,v in pairs(gets) do
        if dateutils.getday(v) == dateutils.getday() then
            n = n + 1
        end
    end
    return n
end

--一共领取天数
function dailydealmodel:caltotalgetnum(id)
    id = checkint(id)
    local gets = self.gets[id] or {}
    local t = {}
    local day = 0
    for i,v in pairs(gets) do
        local d = dateutils.getday(v)
        if not t[d] then
            day = day + 1
        end
        t[d] = true
    end
    return day
end


function dailydealmodel:caltodayget(id)
    id = checkint(id)
    local gets = self.gets[id] or {}
    for i,v in pairs(gets) do
        if dateutils.getday(v) == dateutils.getday() then
            return true
        end
    end
    return false
end


--领取奖励
function dailydealmodel:receive(id)
    id = checkint(id)
    local rews = {}
    self.gets[id] = self.gets[id] or {}
    table.insert(self.gets[id], os.time())
    table.insert(rews, id)
    local ok = pcall(skynet.call, ".dailydeald", "lua", "receive", UID, id)
    local cfg = dailydeallogic.getconf(id)
    local relation = cfg.relation
    if #relation > 1 then
        for i,v in ipairs(relation) do
            rid = checkint(v)
            if not self:caltodayget(rid) then
                self.gets[rid] = self.gets[rid] or {}
                table.insert(self.gets[rid], os.time())
                table.insert(rews, rid)
                local ok = pcall(skynet.call, ".dailydeald", "lua", "receive", UID, rid)
            end
        end
    else
        table.insert(rews, id)
        local ok = pcall(skynet.call, ".dailydeald", "lua", "receive", UID, id)
    end
    return rews
end


return dailydealmodel
