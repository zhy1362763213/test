local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
local activitylogic  = require "activitylogic"
require "functions"

local heishimodel = {}

function heishimodel:init(data, start_time, end_time)
    self.buys = {}
    data = data or {}
    for k, v in pairs(data) do
        self.buys[k] = checkint(v)
    end
    self.start_time = start_time
    self.end_time = end_time
end

function heishimodel:checkbuy(id)
    id = checkint(id)
    if not self.buys[tostring(id)] then
        return true
    end
    local cfg = activitylogic.getheishiconfbyid(id)
    assert(cfg ~= nil)
    if self.buys[tostring(id)] < cfg.limit then
        return true
    end
    return false
end

function heishimodel:buy(id, num)
    id = checkint(id)
    self.buys[tostring(id)] = self.buys[tostring(id)] or 0
    self.buys[tostring(id)] = self.buys[tostring(id)] + num
    local ok = skynet.call(".activityd", "lua", "buyheishi", UID, id, num)
end

function heishimodel:serialize()
    local resp = {}
    resp.tabs = {{id=101, infos = self.buys }}
    resp.score = 0
    resp.start_time = self.start_time
    resp.end_time = self.end_time
    return resp
end


return heishimodel
