-- 用户数据模型
local skynet = require "skynet"
local cjson  = require "cjson"
local bagmodel     = require "bagmodel"
local heromodel    = require "heromodel"
local mqhelper     = require "mqhelper"
local settings     = require "settings"
local lordlogic    = require "lordlogic"
local viplogic     = require "viplogic"
local boxlogic     = require "boxlogic"
local booklogic    = require "booklogic"
local dateutils    = require "dateutils"
local utils        = require "utils"


local pattern = "(%d+)-(%d+)-(%d+) (%d+):(%d+):(%d+)"

local usermodel       = {}

require "functions"

function usermodel:init(user)
    self.uid                = user.uid
    self.serverid           = user.serverid
    self.openid             = user.openid
    self.unionid            = user.unionid
    self.nickname           = user.nickname
    self.avatar             = user.avatar
    self.is_update          = user.is_update or 0
    self.lv                 = user.lv or 1--主公等级
    self.stage              = user.stage or 0 --当前阶
    self.max_level          = user.max_level or 1--关卡
    self.owner              = user.owner or 0
    self.recharge_total     = user.recharge_total or 0 --充值总数
    self.recruit_num        = user.recruit_num or 0 --招募次数
    self.openbox_num        = user.openbox_num or 0 --宝箱开启次数
    self.blackmarket_num    = user.blackmarket_num or 0  --黑市购买次数
    self.coinget_num        = user.coinget_num or 0 --点金次数
    self.click_num          = user.click_num or 0   --点击次数
    self.tower_level        = user.tower_level or 1 --咸将塔 关
    self.online_status      = user.online_status
    self.login_day          = user.login_day or 0 --登录天数
    self.box_score          = user.box_score or 0
    self.box_stage          = user.box_stage or 1
    self.emblemstar         = user.emblemstar or 0 --徽星数量
    self.emblemstarid       = user.emblemstarid or 0
    self.fishing_score      = user.fishing_score or 0
    self.fishing_num_lv1    = user.fishing_num_lv1 or 0
    self.fishing_num_lv2    = user.fishing_num_lv2 or 0
    self.last_use_xyg_time  = user.last_use_xyg_time or 0
    self.last_use_nengliang_time  = user.last_use_nengliang_time or 0
    self.arena_level        = user.arena_level or 1 -- 竞技场等级
    self.last_recruit_time  = user.last_recruit_time or 0
    self.last_fishing_time  = user.last_fishing_time or 0
    self.last_login_time    = user.last_login_time
    self.last_logout_time   = user.last_logout_time
end


function usermodel:login()
    self.last_login_time = os.date("%Y-%m-%d %H:%M:%S")
    self.online_status = 1
end

function usermodel:getserverid()
    return self.serverid
end

function usermodel:getServer()
    return utils.getserver(self.serverid)
end

--获取竞技场组
function usermodel:getArenaServer()
    return utils.getarenserver(self.serverid, self.arena_level)
end

function usermodel:getBaiFuServer()
    return utils.getbaifuserver(self.serverid)
end

--更新招募时间
function usermodel:updaterecruittime()
    self.last_recruit_time = os.time()
    self:save({last_recruit_time=self.last_recruit_time})
end

--检查是否免费 true 免费
function usermodel:checkrecruit()
    if self.last_recruit_time == 0 then
        return true
    end
    local d = dateutils.calday(os.time() ,self.last_recruit_time)
    if d ~= 0 then
        return true
    end
    return false
end


--更新钓鱼时间
function usermodel:updatefishingtime()
    self.last_fishing_time = os.time()
    self:save({last_fishing_time=self.last_fishing_time})
end

--检查是否免费钓鱼 true 免费
function usermodel:checkfishing()
    if self.last_fishing_time == 0 then
        return true
    end
    if os.time() - self.last_fishing_time >= 8*3600 then
        return true
    end
    return false
end

function usermodel:caloverfishingtimelong()
    if os.time() - self.last_fishing_time >= 8*3600 then
        return 0
    end
    local t = os.time() - self.last_fishing_time
    return math.max(0, 8*3600 - t)
end

function usermodel:caloverrecruittimelong()
    local d = dateutils.calday(os.time() ,self.last_recruit_time)
    if d ~= 0 then
        return 0
    end
    return math.max(0, dateutils.onedayover() - os.time())
end

--添加招募次数
function usermodel:addrecruitnum(num)
    self.recruit_num = self.recruit_num + num
end

function usermodel:addopenboxnum(num)
    self.openbox_num = self.openbox_num + num
end

function usermodel:addblackmarketnum(num)
    self.blackmarket_num = self.blackmarket_num + num
end

function usermodel:addcoingetnum(num)
    self.coinget_num = self.coinget_num + num
end

function usermodel:addclicknum(num)
    self.click_num = self.click_num + num
end

--增加徽星
function usermodel:incremblemstar(star)
    self.emblemstar = self.emblemstar + star
    -- self:save({emblemstar=self.emblemstar})
end

--是否可以领取
function usermodel:canreceiveremblemstar()
    local emblemstarid = self.emblemstarid
    local cfg = booklogic.getcurbookstage(emblemstarid + 1)
    local start = cfg.start
    local emblemstar = self.emblemstar
    if emblemstar >= start then
        return true
    end
    return false
end


--领取
function usermodel:receiveremblemstar()
    self.emblemstarid = self.emblemstarid + 1
end

function usermodel:incrboxscore(num)
    self.box_score = self.box_score + num
end

function usermodel:decrboxscore(num)
    self.box_score = self.box_score - num
end

function usermodel:updateboxscore(score)
    self.box_score = score
end

function usermodel:updateboxstage(stage)
    self.box_stage = stage
end

function usermodel:boxstageup()
    local cfg = boxlogic.getstageconf()
    if self.box_stage == 9 then
        self.box_stage = 1
    else
        self.box_stage = self.box_stage + 1
    end
end

function usermodel:checkcanreceivebox()
    local cfg = boxlogic.getstageconfbystage(self.box_stage)
    assert(cfg ~= nil, "配置获取失败")
    local limit = cfg.limit
    if self.box_score >= limit then
        return true
    end
    return false
end

function usermodel:getcurattr()
    local userinfo          = {}
    userinfo.uid            = self.uid
    userinfo.lv             = self.lv --主公等级
    userinfo.stage          = self.stage
    return userinfo
end

function usermodel:serialize()
    local userinfo          = {}
    userinfo.uid            = self.uid
    userinfo.serverid       = self.serverid
    userinfo.nickname       = self.nickname
    userinfo.avatar         = self.avatar
    userinfo.lv             = self.lv --主公等级
    userinfo.stage          = self.stage
    userinfo.max_level      = self.max_level --关卡
    userinfo.tower_level    = self.tower_level
    userinfo.cur_tower_level = self:calcurtowerlevel()
    userinfo.vip_lv         = self:getviplv() --vip等级
    userinfo.recharge_total = self.recharge_total --充值总数
    userinfo.recharge_day   = self.recharge_day
    userinfo.emblemstar     = self.emblemstar
    userinfo.emblemstarid   = self.emblemstarid
    userinfo.fishing_score  = self.fishing_score
    userinfo.fishing_num_lv1= self.fishing_num_lv1
    userinfo.fishing_num_lv2= self.fishing_num_lv2
    userinfo.owner          = self.owner
    userinfo.last_use_xyg_time        = self.last_use_xyg_time
    userinfo.last_use_nengliang_time  = self.last_use_nengliang_time
    userinfo.recruit_over_timelong    = self:caloverrecruittimelong()
    userinfo.fishing_over_timelong    = self:caloverfishingtimelong()
    userinfo.box_score      = self.box_score
    userinfo.box_stage      = self.box_stage
    userinfo.clk            = self:getclk()
    userinfo.atk            = self:getatk()
    userinfo.hp             = self:gethp()
    userinfo.def            = self:getdef()
    userinfo.zhanli         = self:getzhanli()
    return userinfo
end

function usermodel:getclk()
    return lordlogic.getclk(self.lv - 1)
end

function usermodel:getatk()
    return lordlogic.getatk(self.lv - 1)
end

function usermodel:gethp()
    return lordlogic.gethp(self.lv - 1)
end

function usermodel:getdef()
    return lordlogic.getdef(self.lv - 1)
end


function usermodel:getlordorderext(k)
    return lordlogic.getlordorderext(k, self.stage)
end

--[[
    战斗力=攻击力*1+血量*0.21+防御*0.74+速度*1
]]
function usermodel:getzhanli()
    return heromodel:gettotalzhanli()
end

--当前塔的阶段
function usermodel:calcurtowerstage()
    return math.ceil(self.tower_level/10)
end

--上一个塔的阶段
function usermodel:callasttowerstage()
    return math.floor((self.tower_level - 1)/10)
end

--当前塔的层数
function usermodel:calcurtowerlevel()
    return math.floor((self.tower_level - 1)%10 + 1)
end

function usermodel:towerlevelup()
    self.tower_level = self.tower_level + 1
    self:save({tower_level=self.tower_level})
end

function usermodel:settowerstatus(status)
    self.tower_status = status
end

--获取到他人可以看到的信息
function usermodel:get_look_info()
    local userinfo     = {}
    userinfo.uid       = self.uid
    userinfo.serverid  = self.serverid
    userinfo.nickname  = self.nickname
    userinfo.avatar    = self.avatar
    userinfo.max_level = self.max_level
    return userinfo
end


--使用小鱼干
function usermodel:usexiaoyugan()
    self.last_use_xyg_time = os.time()
    self:save({last_use_xyg_time=self.last_use_xyg_time})
end

--使用能量
function usermodel:usenengliang()
    self.last_use_nengliang_time = os.time()
    self:save({last_use_nengliang_time=self.last_use_nengliang_time})
end

--升级
function usermodel:lvup(num)
    self.lv = self.lv + num
    self:save({lv=self.lv})
end

function usermodel:stageup()
    self.stage = self.stage + 1
    self:save({stage=self.stage})
end

--下一关
function usermodel:incrlevel()
    self.max_level = self.max_level + 1
    self:save({max_level=self.max_level})
end

function usermodel:incrrechargetotal(t)
    self.recharge_total = self.recharge_total + t
    self:save({recharge_total=self.recharge_total})
end

function usermodel:getviplv()
    local lv = viplogic.getviplv(self.recharge_total)
    return lv
end


function usermodel:getfishingnum(lv)
    return self["fishing_num_lv"..lv] or 0
end

function usermodel:incrfishingnum(lv, num)
    self["fishing_num_lv"..lv] = self["fishing_num_lv"..lv] + num
end

--添加捕获积分
function usermodel:incrfishingscore(num)
    self.fishing_score = self.fishing_score + num
    self:save({fishing_score=self.fishing_score})
end

--添加捕获积分
function usermodel:decrfishingscore(num)
    self.fishing_score = self.fishing_score - num*20
    self:save({fishing_score=self.fishing_score})
end

--用户离线
function usermodel:logout()
    skynet.error(string.format("user %d logout", UID))
    self.last_logout_time = os.date("%Y-%m-%d %H:%M:%S")
    self.online_status = 0
    self:save({last_logout_time=self.last_logout_time, online_status=self.online_status})
end

function usermodel:savenickname(nickname)
    self.nickname = nickname
    self.is_update = 1
    self:save({nickname=self.nickname, is_update=self.is_update})
end

function usermodel:saveavatar(avatar)
    self.avatar = avatar
    self:save({avatar=self.avatar})
end

--全量保存
function usermodel:saveall()
    local userinfo          = {}
    userinfo.is_update          = self.is_update
    userinfo.lv                 = self.lv
    userinfo.stage              = self.stage
    userinfo.max_level          = self.max_level
    userinfo.recharge_total     = self.recharge_total
    userinfo.recruit_num        = self.recruit_num
    userinfo.openbox_num        = self.openbox_num
    userinfo.blackmarket_num    = self.blackmarket_num
    userinfo.coinget_num        = self.coinget_num
    userinfo.click_num          = self.click_num
    userinfo.tower_level        = self.tower_level
    userinfo.online_status      = self.online_status
    userinfo.login_day          = self.login_day
    userinfo.box_score          = self.box_score
    userinfo.box_stage          = self.box_stage
    userinfo.emblemstar     = self.emblemstar
    userinfo.emblemstarid   = self.emblemstarid
    userinfo.fishing_score  = self.fishing_score
    userinfo.fishing_num_lv1= self.fishing_num_lv1
    userinfo.fishing_num_lv2= self.fishing_num_lv2
    userinfo.owner          = self.owner
    userinfo.last_use_xyg_time        = self.last_use_xyg_time
    userinfo.last_use_nengliang_time  = self.last_use_nengliang_time
    userinfo.last_recruit_time  = self.last_recruit_time
    userinfo.last_fishing_time  = self.last_fishing_time
    self:save(userinfo)
end

--保存用户信息
function usermodel:save(data)
    skynet.error(string.format("user %d save to db", UID))
    DEBUG("save data = ", DUMP(data))
    assert(not table.empty(data), " user save data 数据错误 ")
    local ok = skynet.call(".usercenterd", "lua", "saveuser", UID, data)
    local ok = mqhelper.exec("upsert", UID, settings.user_mongodb_key.tname, settings.user_mongodb_key.cname, {["$set"]=data}, {uid=UID})
end


return usermodel
