local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
require "functions"

--邮件模型

local mailmodel = {}

function mailmodel:init(mails)
    self.mails = {}
    for i, v in ipairs(mails) do
        self.mails[checkint(v.id)] = v
    end
end

function mailmodel:newmail(mail)
    self.mails[checkint(mail.id)] = mail
end

function mailmodel:checkunread(tp)
    for i,v in pairs(self.mails) do
        if v.tp == tp and (v.status == 0 or v.receive == 0) then
            return true
        end
    end
    return false
end

function mailmodel:checkread(tp)
    for i,v in pairs(self.mails) do
        if v.tp == tp and v.status == 1 then
            return true
        end
    end
    return false
end

function mailmodel:getmail(id)
    return self.mails[id]
end

function mailmodel:readbyid(id)
    local mail = self:getmail(id)
    assert(mail~=nil, "邮件不存在")
    mail.status = 1
    local ok = skynet.call(".maild", "lua", "readmail",id, {status=1})
    assert(ok, "修改邮件失败")
end

function mailmodel:receivereward(id)
    local mail = self:getmail(id)
    assert(mail~=nil, "邮件不存在")
    mail.receive = 1
    local ok = skynet.call(".maild", "lua", "readmail",id, {receive=1})
    assert(ok, "修改邮件失败")
end


function mailmodel:getallrewards()
    local rewards = {}
    for _, v in pairs(self.mails) do
        if v.status == 0 then
            local rws = v.rewards
            if #rws > 0 then
                for _, reward in ipairs(rws) do
                    table.insert(rewards, reward)
                end
            end
        end
    end
    return rewards
end


function mailmodel:readall(tp)
    for i,v in pairs(self.mails) do
        if v.tp == tp then
            v.status = 1
            v.receive = 1
        end
    end
    local ok = skynet.call(".maild", "lua", "readallmail", UID, tp, {status=1, receive=1})
    DEBUG("readall ok = ", ok)
    assert(ok, "修改邮件失败")
end

function mailmodel:delmailbyid(id)
    self.mails[id] = nil
    local ok = skynet.call(".maild", "lua", "delone", id)
    assert(ok, "删除邮件失败")
end

function mailmodel:delreadall(tp)
    local removes = {}
    for k,v in pairs(self.mails) do
        if v.tp == tp and v.status == 1 then
            table.insert(removes, k)
        end
    end

    for _,v in ipairs(removes) do
        self.mails[v] = nil
    end

    local ok = skynet.call(".maild", "lua", "delreadall", UID, tp)
    assert(ok, "删除邮件失败")
end

function mailmodel:serialize()
    local  resp = {}
    local  system_mails = {}
    local  daily_mails = {}
    local  game_mails = {}
    for i,v in pairs(self.mails) do
        v.params = table.array(v.params or {})
        v.rewards = table.array(v.rewards or {})
        v.receive = checkint(v.receive)
        if v.tp == "system" then
            table.insert(system_mails, v)
        end
        if v.tp == "daily" then
            table.insert(daily_mails, v)
        end
        if v.tp == "game" then
            table.insert(game_mails, v)
        end
    end
    resp.system_mails = table.array(system_mails)
    resp.daily_mails = table.array(daily_mails)
    resp.game_mails = table.array(game_mails)
    return resp
end

return mailmodel
