local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
local activitylogic  = require "activitylogic"
require "functions"

local zhaomumodel = {}

--t1, t2, t3
--[[
    t1 = 购买
    t2 = 领取
    t3 = 分
]]
function zhaomumodel:init(t1, t2, t3, t4, start_time, end_time)
    self.buys = {}
    t1 = t1 or {}
    for k, v in pairs(t1) do
        self.buys[k] = checkint(v)
    end

    self.receivebuys = {}
    t2 = t2 or {}
    for k, v in pairs(t2) do
        self.receivebuys[k] = checkint(v)
    end

    self.receives = {}
    t3 = t3 or {}
    for k, v in pairs(t3) do
        self.receives[k] = checkint(v)
    end

    self.score = checkint(t4)
    self.start_time = start_time
    self.end_time = end_time
end

function zhaomumodel:incrscore(val)
    local rounds = activitylogic.getzhaomuroundconf()
    local round = 1
    local score = 0
    local myscore = 0
    for k,v in pairs(rounds) do
        score = score + v
        if self.score < score then
            myscore = self.score - (score - v)
            break
        end
        round = round + 1
    end

    local cfg = activitylogic.getzhaomuconfbyround(round)
    local last_score = myscore
    local cur_score = myscore + val
    for i,v in ipairs(cfg) do
        if last_score < v.points and cur_score >= v.points then
            local ok = pcall(skynet.call, ".maild", "lua", "zhaomuactivity", UID, v.rewards)
        end
    end
    self.score = self.score + val
    local ok = skynet.call(".activityd", "lua", "incrzhaomuscore", UID, val)
end

function zhaomumodel:checkbuy(id)
    id = checkint(id)
    local cfg = activitylogic.getzhaomushangchengconfbyid(id)
    assert(cfg ~= nil)
    local buy_num = self.buys[tostring(id)] or 0
    local receive_num = self.receivebuys[tostring(id)] or 0
    if cfg.price <= 0 then
        buy_num = cfg.limit
    end
    if receive_num < buy_num then
        return true
    end
    return false
end

function zhaomumodel:checkreceive(id)
    id = checkint(id)
    local cfg = activitylogic.getzhaomuconfbyid(id)
    if not self.receives[tostring(id)] and cfg.points >= self.socre then
        return true
    end
    return false
end

function zhaomumodel:receive(id)
    id = checkint(id)
    self.receives[tostring(id)] = os.time()
    local ok = skynet.call(".activityd", "lua", "receivezhaomu", UID, id)
end

function zhaomumodel:buy(id)
    id = checkint(id)
    self.buys[tostring(id)] = self.buys[tostring(id)] or 0
    self.buys[tostring(id)] = self.buys[tostring(id)] + 1
    local ok = skynet.call(".activityd", "lua", "buyzhaomu", UID, id, 1)
end

function zhaomumodel:checkreceivebuy(id)
    id = checkint(id)
    local cfg = activitylogic.getzhaomushangchengconfbyid(id)
    local buy_num = self.buys[tostring(id)] or 0
    if cfg.price <= 0 then
        buy_num = cfg.limit
    end
    local receive_num = self.receivebuys[tostring(id)] or 0
    if buy_num > receive_num then
        return true
    end
    return false
end

function zhaomumodel:receivebuy(id)
    id = checkint(id)
    self.receivebuys[tostring(id)] = self.receivebuys[tostring(id)] or 0
    self.receivebuys[tostring(id)] = self.receivebuys[tostring(id)] + 1
    local ok = skynet.call(".activityd", "lua", "receivebuyzhaomu", UID, id, 1)
end

function zhaomumodel:serialize()
    local resp = {}
    local infos = {}
    local cfg = activitylogic.getzhaomushangchengconf()
    for k,v in pairs(cfg) do
        local buy_num = self.buys[k] or 0
        if v.price <= 0 then
            buy_num = v.limit
        end
        infos[k] = {buy_num=buy_num, receive_num=self.receivebuys[k] or 0}
    end

    resp.tabs = {{id=301, infos = infos }, {id=302, infos = self.receives}}
    resp.score = self.score
    resp.start_time = self.start_time
    resp.end_time = self.end_time
    return resp
end


return zhaomumodel
