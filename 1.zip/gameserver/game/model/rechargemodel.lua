local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
require "functions"

--充值模型

local rechargemodel = {}

function rechargemodel:init(data)
    self.total = data or 0
end

function rechargemodel:initrecharge(data)
    self.total = data or 0
end

function rechargemodel:incrtotal(t)
    self.total = self.total + t
end


return rechargemodel
