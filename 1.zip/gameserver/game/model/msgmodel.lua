local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
require "functions"

--消息
local msgmodel = {}

function msgmodel:serialize()
    local msgindex = {}
    msgindex.mailindex = checkint(self.mailindex)
    msgindex.clubindex = checkint(self.clubindex)
    msgindex.recruitindex = checkint(self.recruitindex)
    msgindex.arenaindex = checkint(self.arenaindex)
    msgindex.baifuindex = checkint(self.baifuindex)
    msgindex.applyindex = checkint(self.applyindex)
    msgindex.agreeindex = checkint(self.agreeindex)
    msgindex.giveindex  = checkint(self.giveindex)
    msgindex.friendindex = checkint(self.friendindex)
    return msgindex
end

return msgmodel
