local skynet = require "skynet"
local cjson  = require "cjson"
local settings = require "settings"
local mysqlhelper = require "mysqlhelper"
local itemconf    = require "itemconf"
local mqhelper    = require "mqhelper"
local dateutils   = require "dateutils"
require "functions"

local bagmodel= {}

function bagmodel:init(usermodel, data)
    self.usermodel = usermodel
    data = data or {}
    for k, _ in pairs(itemconf) do
        self[k] = data[k] or 0
    end
end

function bagmodel:getxiaoyugan()
    local lasttime = self.usermodel.last_use_xyg_time or nil
    if not lasttime then
        self.xiaoyugan = 10
    else
        local t = os.time() - lasttime
        local n = math.floor(t/(30*60))
        self.xiaoyugan = math.min(self.xiaoyugan+n, 10)
    end
    return self.xiaoyugan
end

function bagmodel:serialize()
    local data   = {}
    for k,v in pairs(itemconf) do
        if k =="xiaoyugan" then
            local lasttime = self.usermodel.last_use_xyg_time or nil
            if not lasttime then
                data[k] = 10
            else
                local t = os.time() - lasttime
                local n = math.floor(t/(30*60))
                -- local n = math.floor(t/(60))
                data[k] = math.min(self[k]+n, 10)
            end
        elseif k == "nengliang" then
            local lasttime = self.usermodel.last_use_nengliang_time or nil
            if not lasttime then
                data[k] = 10
            else
                local t = os.time() - lasttime
                local n = math.floor(t/(5*60))
                data[k] = math.min(self[k]+n, 100)
            end
        else
            data[k] = self[k] or 0
        end

    end
    return data
end

function bagmodel:getnum(k)
    return self[k] or 0
end


function bagmodel:getboxnum(lv)
    lv = math.floor(lv)
    return self["box_lv"..lv] or 0
end

function bagmodel:gethuobanum(lv)
    return self["huoba_lv"..lv] or 0
end

function bagmodel:getyugannum(lv)
    return self["yugan_lv"..lv] or 0
end


function bagmodel:openbox(lv, num)
    lv = math.floor(lv)
    assert(self["box_lv"..lv] >= num, "数量不足")
    self["box_lv"..lv] = self["box_lv"..lv] - num
    self:save({["box_lv"..lv]=self["box_lv"..lv]})
end


function bagmodel:incrBagA(tp, num)
    self[tp] = self[tp] or 0
    self[tp] = self[tp] + num
    self:save({[tp]=self[tp]})
end


function bagmodel:incrBagB(params)
    local t = {}
    for k,v in pairs(params) do
        self[k] = self[k] or 0
        self[k] = self[k] + v
        t[k] = self[k]
    end
    self:save(t)
end


function bagmodel:decrBagA(tp, num)
    assert(num >= 0, " decrBagA 数量错误")
    self[tp] = self[tp] or 0
    assert(self[tp] >= num, tp .. " 数量不足 ...")
    self[tp] = self[tp] - num
    self:save({[tp]=self[tp]})
end

function bagmodel:decrBagB(params)
    local t = {}
    for k,v in pairs(params) do
        self[k] = self[k] or 0
        assert(self[k] >= v, tp .. " 数量不足 ...")
        self[k] = self[k] - v
        t[k] = self[k]
    end
    self:save(t)
end

--保存记录
function bagmodel:save2log(params, description)
    local log = {
        uid=UID,
        params=params,
        description=description,
        created_at=dateutils.get_datetime()
    }
    local ok = mqhelper.exec("insert", UID, settings.bag_log_mongodb_key.tname, settings.bag_log_mongodb_key.cname, log)
end


function bagmodel:save(data)
    skynet.error(string.format("user bag %d save to db", UID))
    local data = data or self:serialize()
    DEBUG("bag save data = ", DUMP(data))
    assert(not table.empty(data), " 数据错误 ")
    local ok = skynet.call(".usercenterd", "lua", "savebag", UID, data)
    local ok = mqhelper.exec("upsert", UID, settings.bag_mongodb_key.tname, settings.bag_mongodb_key.cname, {["$set"]=data}, {uid=UID})
end

return bagmodel
