local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
require "functions"

--竞技场

local arenamodel = {}

function arenamodel:init(server, level, groupid)
    self.server  = server
    self.level   = level
    self.groupid = groupid
end

function arenamodel:calcurserverid()
    if not self._init then
        return 0
    end
    return self.server * 100000 + self.level * 10000 + self.groupid
end

return arenamodel
