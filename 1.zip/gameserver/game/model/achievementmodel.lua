local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
local usermodel = require "usermodel"
local heromodel = require "heromodel"
local eventemitter = require "eventemitter"
local achievementlogic = require "achievementlogic"
local achievementtasklist  = require "achievementtasklist"
local achievementconf  = require "achievementconf"
--成就模型
local cnf = achievementlogic.getconf()

local achievementmodel = {}

local function getval(id, list)
    for k,v in pairs(list) do
        if checkint(k) == id then
            return v
        end
    end
end

function achievementmodel:init(d1, d2)
    self.achievements = {}
    d1 = d1 or {}
    for _, v in pairs(cnf) do
        local func = handler(self, self["initach"..v.key_id])
        func(checkint(getval(id, d1)))
    end
    self.receives = {}
    d2 = d2 or {}
    for k,v in pairs(achievementtasklist) do
        self.receives[checkint(k)] = {achievement_id=v.achievement_id, status=checkint(d2[k])}
    end

    self.eventEmitter = eventemitter:new()
    self:registerEvent()
    self:registerCallback()
end

function achievementmodel:initach1(val)
    self.achievements[1] = usermodel.login_day
end

function achievementmodel:getach1()
    self.achievements[1] = usermodel.login_day
end

function achievementmodel:initach2(val)
    self.achievements[2] = usermodel.max_level or 1
end

function achievementmodel:getach2()
    self.achievements[2] = usermodel.max_level or 1
    if self._init then
        self:send2client()
    end
end

function achievementmodel:initach3(val)
    self.achievements[3] = usermodel.click_num or 0
end

function achievementmodel:getach3()
    self.achievements[3] = usermodel.click_num or 0
    if self._init then
        self:send2client()
    end
end

function achievementmodel:initach4(val)
    self.achievements[4] = heromodel:getheronum()
end

function achievementmodel:getach4()
    self.achievements[4] = heromodel:getheronum()
    if self._init then
        self:send2client()
    end
end

function achievementmodel:initach5(val)
    self.achievements[5] = usermodel.lv
end

function achievementmodel:getach5(val)
    self.achievements[5] = usermodel.lv
    if self._init then
        self:send2client()
    end
end

function achievementmodel:initach6(val)
    self.achievements[6] = val
end

function achievementmodel:getach6()
    local val = usermodel:getzhanli()
    if val > self.achievements[6] then
        self.achievements[6] = val
        local ok = pcall(skynet.call, ".achievementd", "lua", "setcomplete", UID, 6, val)
        if self._init then
            self:send2client()
        end
    end
end

function achievementmodel:initach7(val)
    self.achievements[7] = val
end

function achievementmodel:getach7()
    local val = heromodel:getconfirmuptotallv()
    if val > self.achievements[7] then
        local ok = pcall(skynet.call, ".achievementd", "lua", "setcomplete", UID, 7, val)
        self.achievements[7] = val
        if self._init then
            self:send2client()
        end
    end
end

function achievementmodel:initach8(val)
    self.achievements[8] = heromodel:gettotalstar()
end

function achievementmodel:getach8()
    self.achievements[8] = heromodel:gettotalstar()
    if self._init then
        self:send2client()
    end
end

function achievementmodel:initach9(val)
    self.achievements[9] = val
end

function achievementmodel:getach9()
    local val = heromodel:geteqptotallv()
    if val > self.achievements[9] then
        local ok = pcall(skynet.call, ".achievementd", "lua", "setcomplete", UID, 7, val)
        self.achievements[9] = val
        if self._init then
            self:send2client()
        end
    end
end

function achievementmodel:initach10(val)
    self.achievements[10] = usermodel.recruit_num or 0
end

function achievementmodel:getach10()
    self.achievements[10] = usermodel.recruit_num or 0
    if self._init then
        self:send2client()
    end
end

function achievementmodel:initach11(val)
    self.achievements[11] = usermodel.openbox_num or 0
end

function achievementmodel:getach11()
    self.achievements[11] = usermodel.openbox_num or 0
    if self._init then
        self:send2client()
    end
end

function achievementmodel:initach12(val)
    self.achievements[12] = usermodel.blackmarket_num or 0
end

function achievementmodel:getach12()
    self.achievements[12] = usermodel.blackmarket_num or 0
    if self._init then
        self:send2client()
    end
end

function achievementmodel:initach13(val)
    self.achievements[13] = usermodel.coinget_num or 0
end

function achievementmodel:getach13()
    self.achievements[13] = usermodel.coinget_num or 0
    if self._init then
        self:send2client()
    end
end

function achievementmodel:initach14(val)
    self.achievements[14] = val
end

function achievementmodel:getach14()
    local val = skynet.call(".usercenterd", "lua", "getmyrank", UID)
    if val < self.achievements[14] then
        local ok = pcall(skynet.call, ".achievementd", "lua", "setcomplete", UID, 14, val)
        self.achievements[14] = val
    end
    if self._init then
        self:send2client()
    end
end

function achievementmodel:initach15(val)
    self.achievements[15] = usermodel.recharge_total
end

function achievementmodel:getach15()
    self.achievements[15] = usermodel.recharge_total
    if self._init then
        self:send2client()
    end
end


function achievementmodel:emit(event, ...)
    self.eventEmitter:emit(event, ...)
end

function achievementmodel:registerEvent()
    self.eventEmitter:registerEvent("login", "用户登录")
    self.eventEmitter:registerEvent("lordlvup", "主公升级")
    self.eventEmitter:registerEvent("herolvup", "武将升级")
    self.eventEmitter:registerEvent("eqplvup", "装备升级")
    self.eventEmitter:registerEvent("openbox", "开启宝箱")
    self.eventEmitter:registerEvent("recruit", "招募")
    self.eventEmitter:registerEvent("blackmarket", "黑市购买")
    self.eventEmitter:registerEvent("coinget", "点金")
    self.eventEmitter:registerEvent("rank", "排行榜排名")
    self.eventEmitter:registerEvent("recharge", "充值")
    self.eventEmitter:registerEvent("levelup", "主线通关")
    self.eventEmitter:registerEvent("click", "点击次数")
    self.eventEmitter:registerEvent("maxzhanli", "最高战力")
    self.eventEmitter:registerEvent("addhero", "增加咸将")
    self.eventEmitter:registerEvent("starup", "咸将升星")
end


function achievementmodel:registerCallback()
    self.eventEmitter:registerCallback("login", self.getach1)
    self.eventEmitter:registerCallback("levelup", self.getach2)
    self.eventEmitter:registerCallback("click", self.getach3)
    self.eventEmitter:registerCallback("addhero", self.getach4)
    self.eventEmitter:registerCallback("lordlvup", self.getach5)
    self.eventEmitter:registerCallback("maxzhanli", self.getach6)
    self.eventEmitter:registerCallback("herolvup", self.getach7)
    self.eventEmitter:registerCallback("starup", self.getach8)
    self.eventEmitter:registerCallback("eqplvup", self.getach9)
    self.eventEmitter:registerCallback("recruit", self.getach10)
    self.eventEmitter:registerCallback("openbox", self.getach11)
    self.eventEmitter:registerCallback("blackmarket", self.getach12)
    self.eventEmitter:registerCallback("coinget", self.getach13)
    self.eventEmitter:registerCallback("rank", self.getach14)
    self.eventEmitter:registerCallback("recharge", self.getach15)
end

function achievementmodel:checknum(id)
    id = checkint(id)
    local cfg = achievementlogic.gettaskconfbyid(id)
    local aid = cfg.achievement_id
    local n = self.achievements[aid]
    if n >= cfg.complete_value then
        return true
    end
    return false
end

function achievementmodel:checkreceive(id)
    id = checkint(id)
    return self.receives[id].status
end

function achievementmodel:receive(id)
    self.receives[id].status = 1
    local ok = skynet.call(".achievementd", "lua", "receive", UID, id)
    return "ok"
end

function achievementmodel:send2client()
    local cmd = {c = "user",m = "loadachievement",data = {errcode = 0, errmsg = "", data = {achievement = self:serialize()}}}
    skynet.send(skynet.self(), "lua", "nativesend", cmd)
    return "ok"
end

function achievementmodel:save()

end

function achievementmodel:serialize()
    local achievements = {}
    local function gettaskid(id)
        id = checkint(id)
        local big
        for k, v in pairs(self.receives) do
            if v.achievement_id == id and v.status ~= 0 then
                if not big or k > big then
                    big = k
                end
            end
        end
        if not big then
            local small
            for k, v in pairs(self.receives) do
                if v.achievement_id == id and v.status == 0 then
                    if not small or k < small then
                        small = k
                    end
                end
            end
            return small - 1
        end
        return big
    end
    for k,v in pairs(self.achievements) do
        local receiveid = gettaskid(k) + 1
        local status = 0
        if not achievementlogic.gettask(k, receiveid) then
            status = 1
            receiveid = receiveid - 1
        end
        achievements[tostring(k)] = {receiveid=receiveid, val=v, status=status}
    end
    return achievements
end

return achievementmodel
