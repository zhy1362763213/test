local skynet = require "skynet"
local cjson  = require "cjson"
local utils  = require "utils"
local dateutils  = require "dateutils"
local dailytaskconf = require "dailytaskconf"
local daylimitconf = require "daylimitconf"
local weeklimitconf = require "weeklimitconf"
require "functions"

--每日任务模型

local DEFAULT = {
    login=1,
    share=2,
    friend=3,
    recruit=4,
    guaji=5,
    coinget=6,
    openbox=7,
    arena=8,
    blackmarket=9,
    pot=10
}

local taskmodel = {}

function taskmodel:init(data)
    self.weeklyactval = checkint(data[4]) or 0
    self.weeklyreceiveid = checkint(data[6]) or 0

    self.dailyactval = checkint(data[3]) or 0
    self.dailyreceiveid = checkint(data[5]) or 0

    self.tasks = {}
    local t1 = utils.redis_pack(data[1])
    for k,v in pairs(dailytaskconf) do
        self.tasks[checkint(k)] = checkint(t1[k])
    end
    self.receives = {}
    local t2 = utils.redis_pack(data[2])
    for k,v in pairs(dailytaskconf) do
        self.receives[checkint(k)] = checkint(t2[k])
    end
end


--添加进度
function taskmodel:addtasknum(id, num)
    self.tasks[id] = self.tasks[id] or 0
    self.tasks[id] = self.tasks[id] + num
    local max = dailytaskconf[tostring(id)].complete_value
    self.tasks[id] = math.min(max, self.tasks[id])
    local ok = skynet.call(".taskd", "lua", "addtasknum", UID, id, 1)
end

function taskmodel:checkcompletetask(id)
    local num = dailytaskconf[tostring(id)].complete_value
    -- DEBUG("checkcompletetask num = ", num, " tasks = ", DUMP(self.tasks))
    -- DEBUG("self.tasks[id] = ", self.tasks[id])
    return self.tasks[id] >= num
end



function taskmodel:checkreceivetask(id)
    return self.receives[id] == 1
end

--领取活跃积分
function taskmodel:receivetask(id)
    --TODO:领取任务奖励 增加积分
    local score = dailytaskconf[tostring(id)].reward_points
    self.receives[id] = 1
    self.dailyactval = self.dailyactval + score
    self.weeklyactval = self.weeklyactval + score
    local ok = skynet.call(".taskd", "lua", "receivetask", UID, id, score)
end



--领取周活跃
function taskmodel:checkreceivedailyact()
    local id = 0
    for k,v in pairs(daylimitconf) do
        if v.key_id > self.dailyreceiveid and self.dailyactval >= v.limit then
            id =  v.key_id
        end
    end
    if id ~= 0 then
        return true
    end
    return false
end

--领取日活跃
function taskmodel:receivedailyact()
    local rewards = {}
    local id = 0
    for k,v in pairs(daylimitconf) do
        if v.key_id > self.dailyreceiveid and self.dailyactval >= v.limit then
            id =  v.key_id
            for _, reward in ipairs(v.rewards) do
                table.insert(rewards, reward)
            end
        end
    end
    if id ~= 0 then
        self.dailyreceiveid = id
        local ok = skynet.call(".taskd", "lua", "receivedaily", UID, id)
    end
    return rewards
end

--领取周活跃
function taskmodel:checkreceiveweeklyact()
    local id = 0
    for k,v in pairs(weeklimitconf) do
        if v.key_id > self.weeklyreceiveid and self.weeklyactval >= v.limit then
            id =  v.key_id
        end
    end
    if id ~= 0 then
        return true
    end
    return false
end

--领取周活跃
function taskmodel:receiveweeklyact()
    local rewards = {}
    local id = 0
    for k,v in pairs(weeklimitconf) do
        if v.key_id > self.weeklyreceiveid and self.weeklyactval >= v.limit then
            id =  v.key_id
            for _, reward in ipairs(v.rewards) do
                table.insert(rewards, reward)
            end
        end
    end
    if id ~= 0 then
        self.weeklyreceiveid = id
        local ok = skynet.call(".taskd", "lua", "receiveweekly", UID, id)
    end
    return rewards
end


function taskmodel:serialize()
    local resp = {}
    resp.dailyact    = {val=self.dailyactval, id=self.dailyreceiveid}
    resp.weeklyact   = {val=self.weeklyactval, id=self.weeklyreceiveid}

    local tasks = {}
    for k,v in pairs(self.tasks) do
        tasks[tostring(k)] = {num=v, receive=self.receives[checkint(k)]}
    end
    resp.tasks = tasks

    return resp
end


return taskmodel
