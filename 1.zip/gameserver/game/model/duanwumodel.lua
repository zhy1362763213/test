local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
local activitylogic  = require "activitylogic"
require "functions"

local duanwumodel = {}

function duanwumodel:init(t1, t2, t3, t4, t5, start_time, end_time)
    self.buys = {}
    t1 = t1 or {}
    for k, v in pairs(t1) do
        self.buys[k] = checkint(v)
    end

    self.receivebuys = {}
    t2 = t2 or {}
    for k, v in pairs(t2) do
        self.receivebuys[k] = checkint(v)
    end

    self.receives = {}
    t3 = t3 or {}
    for k, v in pairs(t3) do
        self.receives[k] = checkint(v)
    end

    self.score = checkint(t4)

    self.duihuans = {}
    t5 = t5 or {}
    for k, v in pairs(t5) do
        self.duihuans[k] = checkint(v)
    end

    self.start_time = start_time
    self.end_time = end_time
end

function duanwumodel:checkbuy(id)
    id = checkint(id)
    local cfg = activitylogic.getduanwuxiangouconfbyid(id)
    assert(cfg ~= nil)
    local num = self.buys[tostring(id)] or 0
    if num < cfg.limit then
        return true
    end
    return false
end


function duanwumodel:buy(id)
    id = checkint(id)
    self.buys[tostring(id)] = self.buys[tostring(id)] or 0
    self.buys[tostring(id)] = self.buys[tostring(id)] + 1
    local ok = skynet.call(".activityd", "lua", "buyduanwu", UID, id, 1)
end

function duanwumodel:checkreceivebuy(id)
    id = checkint(id)
    local cfg = activitylogic.getduanwuxiangouconfbyid(id)
    local buy_num = self.buys[tostring(id)] or 0
    local receive_num = self.receivebuys[tostring(id)] or 0
    if buy_num > receive_num then
        return true
    end
    return false
end

function duanwumodel:receivebuy(id)
    id = checkint(id)
    self.receivebuys[tostring(id)] = self.receivebuys[tostring(id)] or 0
    self.receivebuys[tostring(id)] = self.receivebuys[tostring(id)] + 1
    local ok = skynet.call(".activityd", "lua", "receivebuyduanwu", UID, id, 1)
end

function duanwumodel:incrscore(num)
    self.score = self.score + num
    local ok = skynet.call(".activityd", "lua", "incrduanwuscore", UID, num)
    return self.score
end

function duanwumodel:checkreceive(id)
    id = checkint(id)
    local cfg = activitylogic.getduanwuleichongconfbyid(id)
    assert(cfg ~= nil)
    if not self.receives[tostring(id)] and self.score >= cfg.amount  then
        return true
    end
    return false
end

function duanwumodel:receive(id)
    id = checkint(id)
    self.receives[tostring(id)] = 1
    local ok = skynet.call(".activityd", "lua", "receiveduanwu", UID, id)
end

function duanwumodel:checkduihuan(id)
    id = checkint(id)
    local cfg = activitylogic.getduanwuduihuanconfbyid(id)
    assert(cfg ~= nil)
    if not self.duihuans[tostring(id)] or self.duihuans[tostring(id)] < cfg.limit then
        return true
    end
    return false
end

function duanwumodel:duihuan(id)
    id = checkint(id)
    self.duihuans[tostring(id)] = self.duihuans[tostring(id)] or 0
    self.duihuans[tostring(id)] = self.duihuans[tostring(id)] + 1
    local ok = skynet.call(".activityd", "lua", "duihuanduanwu", UID, id, 1)
end


function duanwumodel:serialize()
    local resp = {}
    local infos = {}
    local cfg = activitylogic.getduanwuxiangouconf()
    for k,v in pairs(cfg) do
        local buy_num = self.buys[k] or 0
        infos[k] = {buy_num=buy_num, receive_num=self.receivebuys[k] or 0}
    end

    resp.tabs = {{id=401, infos = infos }, {id=402, infos = self.receives}, {id=403, infos = self.duihuans}}
    resp.score = self.score
    resp.start_time = self.start_time
    resp.end_time = self.end_time
    return resp
end


return duanwumodel
