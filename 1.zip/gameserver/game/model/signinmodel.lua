local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
require "functions"

--签到模型

local signinmodel = {}

function signinmodel:init(data)
    data        = data or {}
    self.login_count    = checkint(data.login_count)
    self.sign_count     = checkint(data.sign_count)
end


--是否可以签到
function signinmodel:checksign()
    return self.login_count > self.sign_count
end

--签到
function signinmodel:signin()
    local rews = {}
    for i = self.sign_count + 1,  self.login_count do
        table.insert(rews, i)
        self.sign_count = self.sign_count + 1
    end
    local ok = skynet.call(".signind", "lua", "sign", UID, #rews)
    return rews
end

--签到信息
function signinmodel:serialize()
    local info  = {}
    info.login_count = self.login_count
    info.sign_count  = self.sign_count
    return info
end



return signinmodel
