local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
require "functions"

--宝箱周模型

local boxweekmodel = {}

function boxweekmodel:init(data)
    data        = data or {}
end

return boxweekmodel
