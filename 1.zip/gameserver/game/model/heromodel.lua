local skynet = require "skynet"
local cjson  = require "cjson"
local mysqlhelper = require "mysqlhelper"
local equipmentmodel    = require "equipmentmodel"
local crystalmodel  = require "crystalmodel"
local artifactmodel = require "artifactmodel"
local mqhelper    = require "mqhelper"
local settings    = require "settings"
local herologic   = require "herologic"
local clublogic   = require "clublogic"
local equipmentlogic   = require "equipmentlogic"
local utils       = require "utils"
require "functions"

local heromodel = {}

function heromodel:init(usermodel, heros)
    self.usermodel = usermodel
    self.heros     = {}
    if heros then
        for _,v in ipairs(heros) do
            local temp    = {}
            temp.id       = v.id
            temp.heroid   = v.heroid
            temp.serverid = v.serverid
            temp.work   = v.work --1战士 2肉盾 3辅助 4法师 5刺客 6射手
            temp.lv     = v.lv or 1
            temp.stage  = v.stage or 0
            temp.star   = v.star or 0
            temp.pos    = v.pos or 0

            temp.collect_emblemstar = v.collect_emblemstar or 0 --收集徽星次数

            local skill           = {}
            skill.awake_active    = v.awake_active or 0
            skill.awake_passive1  = v.awake_passive1 or 0
            skill.awake_passive2  = v.awake_passive2 or 0
            skill.awake_passive3  = v.awake_passive3 or 0
            temp.skill            = skill

            local equipment           = {}
            equipment.weapon          = equipmentmodel.new(self, v.heroid, "weapon", v.equipment.weapon) --刀
            equipment.cloth           = equipmentmodel.new(self, v.heroid, "cloth", v.equipment.cloth) --甲
            equipment.head            = equipmentmodel.new(self, v.heroid, "head", v.equipment.head) --头
            equipment.horse           = equipmentmodel.new(self, v.heroid, "horse", v.equipment.horse)  --马
            temp.equipment            = equipment

            local skin                = {} --皮肤

            temp.skin                 = skin

            self.heros[temp.heroid] = temp
        end
    end
end

--添加英雄
function heromodel:add(data)
    assert(not self.heros[data.heroid])
    local temp  = {}
    temp.id        = data.id
    temp.heroid    = data.heroid
    temp.serverid  = data.serverid
    temp.lv     = data.lv or 1
    temp.stage  = data.stage or 0
    temp.star   = data.star or 0
    temp.pos    = data.pos or 0
    temp.collect_emblemstar = data.collect_emblemstar or 0 --徽星次数
    --技能
    local skill = {}
    skill.awake_active    = data.awake_active or 0
    skill.awake_passive1  = data.awake_passive1 or 0
    skill.awake_passive2  = data.awake_passive2 or 0
    skill.awake_passive3  = data.awake_passive3 or 0
    temp.skill            = skill
    --装备
    local equipment           = {}
    equipment.weapon          = equipmentmodel.new(self, data.heroid, "weapon", nil) --刀
    equipment.cloth           = equipmentmodel.new(self, data.heroid, "cloth", nil) --甲
    equipment.head            = equipmentmodel.new(self, data.heroid, "head", nil) --头
    equipment.horse           = equipmentmodel.new(self, data.heroid, "horse", nil)  --马
    temp.equipment            = equipment
    self.heros[data.heroid]   = temp
    --TODO:落地
    self:save(data.heroid)
end


function heromodel:getheros()
     return self.heros
end

function heromodel:getheronum()
    local n = 0
    for k,v in pairs(self.heros) do
        n = n + 1
    end
    return n
end

--获取上阵总等级
function heromodel:getconfirmuptotallv()
    local lv = 0
    for k,v in pairs(self.heros) do
        if v.pos > 0 then
            lv = lv + v.lv
        end
    end
    return lv
end

function heromodel:gettotalstar()
    local star = 0
    for k,v in pairs(self.heros) do
        star = star + v.star
    end
    return star
end

function heromodel:geteqptotallv()
    local lv = 0
    for k,v in pairs(self.heros) do
        local eqps = self:getequipment(v.heroid)
        for _, eqp in pairs(eqps) do
            lv = lv + eqp:getlv()
        end
    end
    return lv
end



--获取空位置
function heromodel:getemptypos()
    local t = {}
    for k,v in pairs(self.heros) do
        if v.pos > 0 then
            t[v.pos] = true
        end
    end
    for pos=1,5 do
        if not t[pos] then
            return pos
        end
    end
end

--上阵武将数量
function heromodel:getupnum()
    local n = 0
    for k,v in pairs(self.heros) do
        if v.pos > 0 then
            n = n + 1
        end
    end
    return n
end

function heromodel:getherobypos(pos)
    for k,v in pairs(self.heros) do
        if v.pos == pos then
            return v
        end
    end
end

function heromodel:changepos(heroid, pos)
    assert(self.heros[heroid], "not found")
    self.heros[heroid].pos = pos
    self:save(heroid)
end

function heromodel:changehero(heroid, hero)
    assert(self.heros[heroid], "not found")
    hero.id = nil
    hero.heroid = nil
    hero.skill = nil
    hero.collect_emblemstar = nil
    hero.star = nil
    for k,v in pairs(hero) do
        self.heros[heroid][k] = v
    end
    self:save(heroid)
end

function heromodel:update(heroid, data)
    assert(self.heros[heroid], "not found")
    for k,v in pairs(data) do
        self.heros[heroid][k] = v
    end
    self:save(heroid)
end

--重生
function heromodel:reborn(heroid)
    assert(self.heros[heroid], "not found")
    local hero = self.heros[heroid]
    hero.pos = 0
    hero.lv = 1
    hero.stage = 0
    hero.equipment.weapon.lv = 1
    hero.equipment.cloth.lv = 1
    hero.equipment.head.lv = 1
    hero.equipment.horse.lv = 1
    self:equipmentreborn(heroid)
    -- self:save(heroid)
end

--计算武将当前等级消耗的所有材料
function heromodel:caltotalresource(heroid)
    assert(self.heros[heroid], "not found")
    local coin = herologic.calcurlvusecoin(self.heros[heroid].lv)
    local jinjieshi = herologic.calcurlvusejinjieshi(self.heros[heroid].stage)
    local jingtie = 0
    for k,v in pairs(self.heros[heroid].equipment) do
        jingtie = jingtie + v:calcurlvusejingtie()
    end
    return {coin=coin, jinjieshi=jinjieshi, jingtie=jingtie}
end


function heromodel:lvup(heroid, num)
    assert(self.heros[heroid], "not found")
    self.heros[heroid].lv = self.heros[heroid].lv + num
    --TODO:升级数据落地
    self:save(heroid)
end

function heromodel:starup(heroid)
    assert(self.heros[heroid], "not found")
    self.heros[heroid].star = self.heros[heroid].star + 1
    self:save(heroid)
end


function heromodel:stageup(heroid)
    assert(self.heros[heroid], "not found")
    self.heros[heroid].stage = self.heros[heroid].stage + 1
    self:save(heroid)
end


--收集徽星
function heromodel:collectemblemstar(heroid)
    assert(self.heros[heroid], "not found")
    local hero = self.heros[heroid]
    local c = hero.star + 1
    assert(hero.collect_emblemstar < c, " 收集失败 ")
    hero.collect_emblemstar = hero.collect_emblemstar + 1
    -- self:save(heroid)
end


--获取收集徽星的阶段
function heromodel:getcollectemblemstar(heroid)
    assert(self.heros[heroid], "not found")
    local hero = self.heros[heroid]
    return hero.collect_emblemstar
end


function heromodel:getatk(heroid)
    assert(self.heros[heroid], "not found")
    local born_atk = herologic.getbornatk(heroid)
    local lord_atk = self.usermodel:getatk()
    local shuijing_atk = self:getshuijingattrabs("atk", heroid)
    local eqp_atk = self:getequipmentatk(heroid)
    local yuling_atk = self:getyulingattrabs("atk", heroid)
    local lvup_atk = self:getlvupext("atk", heroid)
    local lord_ext = self.usermodel:getlordorderext("atk_ratio")
    local shuijing_ext = self:getshuijingattrext("atk_ratio", heroid)
    local yuling_ext = self:getyulingattrext("atk_ratio", heroid)
    local yuling_limit_ext = self:getyulinglimitattrext("atk_ratio", heroid)
    local stageup_ext = self:getstageupattrext("atk_ratio", heroid)
    local starup_ext = self:getstarupattrext("atk_ratio", heroid)
    local club_ext = self:getclubext("atk_ratio")
    local skill_ext = self:getskillext("atk_ratio", heroid)
    local halo_ext = self:gethaloext("atk_ratio")
    return utils.round((born_atk + lord_atk + shuijing_atk + eqp_atk + yuling_atk + lvup_atk) * (1 + lord_ext) * (1 + shuijing_ext) * (1 + yuling_ext) * (1 + yuling_limit_ext) * (1 + stageup_ext) * (1 + starup_ext) * (1 + club_ext) * (1 + skill_ext) * (1 + halo_ext))
end

function heromodel:getdef(heroid)
    assert(self.heros[heroid], "not found")
    local born_def = herologic.getborndef(heroid)
    local lord_def = self.usermodel:getdef()
    local shuijing_def = self:getshuijingattrabs("def", heroid)
    local eqp_def = self:getequipmentdef(heroid)
    local yuling_def = self:getyulingattrabs("def", heroid)
    local lvup_def = self:getlvupext("def", heroid)
    local lord_ext = self.usermodel:getlordorderext("def_ratio")
    local shuijing_ext = self:getshuijingattrext("def_ratio", heroid)
    local yuling_ext = self:getyulingattrext("def_ratio", heroid)
    local yuling_limit_ext = self:getyulinglimitattrext("def_ratio", heroid)
    local stageup_ext = self:getstageupattrext("def_ratio", heroid)
    local starup_ext = self:getstarupattrext("def_ratio", heroid)
    local club_ext = self:getclubext("def_ratio")
    local skill_ext = self:getskillext("def_ratio", heroid)
    return utils.round((born_def + lord_def + shuijing_def + eqp_def + yuling_def + lvup_def) * (1 + lord_ext) * (1 + shuijing_ext) * (1 + yuling_ext) * (1 + yuling_limit_ext) * (1 + stageup_ext) * (1 + starup_ext) * (1 + club_ext) * (1 + skill_ext))
end

function heromodel:gethp(heroid)
    assert(self.heros[heroid], "not found")
    local born_hp = herologic.getbornhp(heroid)
    local lord_hp = self.usermodel:gethp()
    local shuijing_hp = self:getshuijingattrabs("hp", heroid)
    local eqp_hp = self:getequipmenthp(heroid)
    local yuling_hp = self:getyulingattrabs("hp", heroid)
    local lvup_hp = self:getlvupext("hp", heroid)
    local lord_ext = self.usermodel:getlordorderext("hp_ratio")
    local shuijing_ext = self:getshuijingattrext("hp_ratio", heroid)
    local set_ext = self:calsetattr(heroid) --套装加成
    local yuling_ext = self:getyulingattrext("hp_ratio", heroid)
    local yuling_limit_ext = self:getyulinglimitattrext("hp_ratio", heroid)
    local stageup_ext = self:getstageupattrext("hp_ratio", heroid)
    local starup_ext = self:getstarupattrext("hp_ratio", heroid)
    local club_ext = self:getclubext("hp_ratio")
    local skill_ext = self:getskillext("hp_ratio", heroid)
    local halo_ext = self:gethaloext("hp_ratio")
    return utils.round((born_hp + lord_hp + shuijing_hp + eqp_hp + yuling_hp + lvup_hp) * (1 + lord_ext) * (1 + shuijing_ext) * (1 + set_ext) *  (1 + yuling_ext) * (1 + yuling_limit_ext) * (1 + stageup_ext) * (1 + starup_ext) * (1 + club_ext) * (1 + skill_ext) * (1 + halo_ext))
end

function heromodel:getspeed(heroid)
    assert(self.heros[heroid], "not found")
    local bornspeed = herologic.getbornspeed(heroid)
    local shuijingspeed = 0
    local yulingspeed = self:getyulingattrabs("spd", heroid)
    local lvupspeed = self:getlvupext("spd", heroid)
    local skillspeed = self:getskillext("spd", heroid)
    return utils.round(bornspeed + shuijingspeed + yulingspeed + lvupspeed + skillspeed)
end


function heromodel:getequipmentatk(heroid)
     assert(self.heros[heroid], "not found")
     local eqps = self.heros[heroid].equipment
     local atk = 0
     for k,v in pairs(eqps) do
         atk = atk + v:getatk()
     end
     return atk
end

function heromodel:getequipmentdef(heroid)
     assert(self.heros[heroid], "not found")
     local eqps = self.heros[heroid].equipment
     local def = 0
     for k,v in pairs(eqps) do
         def = def + v:getdef()
     end
     return def
end

function heromodel:getequipmenthp(heroid)
     assert(self.heros[heroid], "not found")
     local eqps = self.heros[heroid].equipment
     local hp = 0
     for k,v in pairs(eqps) do
         hp = hp + v:gethp()
     end
     return hp
end


function heromodel:getequipmentspeed(heroid)
     assert(self.heros[heroid], "not found")
     local eqps = self.heros[heroid].equipment
     local speed = 0
     for k,v in pairs(eqps) do
         speed = speed + v:getspeed()
     end
     return speed
end

function heromodel:getshuijingattrabs(k,heroid)
     return 0
end

--水晶加成
function heromodel:getshuijingattrext(k, heroid)
     return 0
end


function heromodel:getyulingattrabs(k, heroid)
    assert(self.heros[heroid], "not found")
   return artifactmodel:getattrabs(k, heroid)
end

function heromodel:getyulingattrext(k, heroid)
    assert(self.heros[heroid], "not found")
    return artifactmodel:getattrext(k, heroid)
end

function heromodel:getyulinglimitattrext(k, heroid)
    assert(self.heros[heroid], "not found")
    return artifactmodel:getlimitattrext(k, heroid)
end

function heromodel:getstageupattrext(k, heroid)
     assert(self.heros[heroid], "not found")
     return herologic.getstageupattrext(k, self.heros[heroid].stage)
end


function heromodel:getstarupattrext(k, heroid)
     return herologic.getstarupattrext(k, self.heros[heroid].star)
end

function heromodel:calsetattr(heroid)
    local eqps = self:getequipment(heroid)
    local sets = {}
    for k,v in pairs(eqps) do
        local color = v:getcolor()
        sets[color] = sets[color] or 0
        sets[color] = sets[color] + 1
    end
    local ext = 0
    for k,v in pairs(sets) do
        local attrs = equipmentlogic.getsetattr(k, v)
        for i,v in ipairs(attrs) do
            ext = ext + v.hp_ratio
        end
    end
    return ext
end

function heromodel:getclubext(k)
    --TODO: 获取俱乐部科技
    local clublv = {0,0,0,0,0,0,0,0}
    return clublogic.getclubresearchattrnum(self.work, 0, k, clublv)
end


function heromodel:getskillext(k, heroid)
    assert(self.heros[heroid], "not found")
    return herologic.getskillext(k, heroid, self.heros[heroid].stage, self.heros[heroid].skill)
end

function heromodel:getlvupext(k, heroid)
     assert(self.heros[heroid], "not found")
     local lv = self.heros[heroid].lv
     local up = herologic.getlvupext(k, heroid)
     return up * (lv -1)
end


function heromodel:getotherattr(heroid)
    assert(self.heros[heroid], "not found")
    return 100
end

function heromodel:getzhanli(heroid)
    assert(self.heros[heroid], "not found")
    local r1 = self:getatk(heroid) * 1
    local r2 = self:gethp(heroid) * 0.21
    local r3 = self:getdef(heroid) * 0.74
    local r4 = self:getspeed(heroid) * 1
    return utils.round(r1 + r2 + r3 + r4)
end

function heromodel:gettotalzhanli()
    local zhanli = 0
    for i,v in pairs(self.heros) do
        if v.pos > 0 then
            local myzhanli = self:getzhanli(v.heroid)
            zhanli = zhanli + myzhanli
        end
    end
    return zhanli
end

--检查是否拥有英雄
function heromodel:checkhero(heroid)
    if self.heros[heroid] ~= nil then
        return true
    end
    return false
end

function heromodel:gethero(heroid)
    assert(self.heros[heroid], "not found")
    return self.heros[heroid]
end


function heromodel:getherobyheroid(heroid)
    assert(self.heros[heroid], "not found")
    return self.heros[heroid]
end


function heromodel:getherobyid(id)
    for k,v in pairs(self.heros) do
        if v.id == id then
            return v
        end
    end
end

function heromodel:getequipment(heroid)
    local hero = self:getherobyheroid(heroid)
    return hero.equipment
end

--计算所有装备消耗
function heromodel:calequipmentconsume(heroid)
    local eqps = self:getequipment(heroid)
    local jingtie = 0
    for k,v in pairs(eqps) do
        jingtie = jingtie + v:calcurlvusejingtie()
    end
    return jingtie
end

--重生装备
function heromodel:equipmentreborn(heroid)
    local eqps = self:getequipment(heroid)
    for k,v in pairs(eqps) do
        v:reborn()
    end
    self:save(heroid)
end

--""
function heromodel:gethaloext(tp)
    local attrs = self:gethaloattrs()
    local ext = 0
    if attrs ~= nil then
        for _, attr in ipairs(attrs) do
            local n = attr[tp] or 0
            ext = ext + n
        end
    end
    return ext
end

function heromodel:gethaloattrs()
    local temps = {}
    for k,v in pairs(self.heros) do
        local cfg = herologic.getconf(v.heroid)
        if v.pos > 0 and cfg.color == 3 then
            local club = cfg.club
            temps[club] = temps[club] or 0
            temps[club] = temps[club] + 1
        end
    end
    local function found(temps)
        for k,v in pairs(temps) do
            if v >= 3 then
                return k, v
            end
        end
    end
    local club, num = found(temps)
    if club and num then
        local attrs = herologic.gethaloattrs(club, num)
        return attrs
    end
end

function heromodel:getall()
    local t = {}
    for k,v in pairs(self.heros) do
        table.insert(t, v)
    end
    return t
end

function heromodel:gethaveheros()
    local t = {}
    for k,v in pairs(self.heros) do
        t[v.heroid] = true
    end
    return t
end

function heromodel:serializebyheroid(heroid)
    local hero = self:getherobyheroid(heroid)
    local temp  = {}
    temp.id     = hero.id
    temp.heroid = hero.heroid
    temp.serverid = hero.serverid
    temp.lv     = hero.lv
    temp.stage  = hero.stage
    temp.star   = hero.star
    temp.pos    = hero.pos
    temp.collect_emblemstar = hero.collect_emblemstar
    temp.atk    = self:getatk(heroid)
    temp.hp     = self:gethp(heroid)
    temp.def    = self:getdef(heroid)
    temp.spd    = self:getspeed(heroid)
    temp.zhanli = self:getzhanli(heroid)
    local equipment    = {}
    equipment.weapon   = hero.equipment.weapon:serialize()
    equipment.cloth    = hero.equipment.cloth:serialize()
    equipment.head     = hero.equipment.head:serialize()
    equipment.horse    = hero.equipment.horse:serialize()
    temp.equipment     = equipment
    local art          = artifactmodel:getartbyheroid(heroid)
    temp.yuling = {}
    if art ~= nil then
        temp.yuling    = art
    end
    return temp
end

function heromodel:serialize()
    local t = {}
    for k,v in pairs(self.heros) do
        local temp  = {}
        temp.id     = v.id
        temp.heroid = v.heroid
        temp.serverid = v.serverid
        temp.lv     = v.lv
        temp.stage  = v.stage
        temp.star   = v.star
        temp.pos    = v.pos
        temp.collect_emblemstar = v.collect_emblemstar
        temp.atk    = self:getatk(v.heroid)
        temp.hp     = self:gethp(v.heroid)
        temp.def    = self:getdef(v.heroid)
        temp.spd    = self:getspeed(v.heroid)
        temp.zhanli = self:getzhanli(v.heroid)
        local equipment    = {}
        equipment.weapon   = v.equipment.weapon:serialize()
        equipment.cloth    = v.equipment.cloth:serialize()
        equipment.head     = v.equipment.head:serialize()
        equipment.horse    = v.equipment.horse:serialize()
        temp.equipment     = equipment
        local art          = artifactmodel:getartbyheroid(v.heroid)
        temp.yuling = {}
        if art ~= nil then
            temp.yuling    = art
        end
        table.insert(t, temp)
    end
    return table.array(t)
end


function heromodel:save(heroid)
    assert(self.heros[heroid], "not found")
    local hero   = self.heros[heroid]
    local temp   = {}
    temp.id      = hero.id
    temp.uid     = UID
    temp.heroid  = hero.heroid
    temp.serverid= hero.serverid
    temp.lv      = hero.lv
    temp.stage   = hero.stage
    temp.star    = hero.star
    temp.pos     = hero.pos
    temp.collect_emblemstar = hero.collect_emblemstar
    local equipment    = {}
    equipment.weapon   = hero.equipment.weapon:save2serialize()
    equipment.cloth    = hero.equipment.cloth:save2serialize()
    equipment.head     = hero.equipment.head:save2serialize()
    equipment.horse    = hero.equipment.horse:save2serialize()
    temp.equipment     = equipment
    local ok = skynet.call(".usercenterd", "lua", "savehero", UID, temp)
    local ok = mqhelper.exec("upsert", UID, settings.hero_mongodb_key.tname, settings.hero_mongodb_key.cname, {["$set"]=temp}, {id=hero.id})
end

function heromodel:saveall()
    for heroid,hero in pairs(self.heros) do
        self:save(heroid)
    end
end

return heromodel
