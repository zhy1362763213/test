local skynet = require "skynet"
local cjson  = require "cjson"
local dateutils  = require "dateutils"
require "functions"

--俱乐部模型

local clubmodel = {}

function clubmodel:init(clubid, signin_day, researchs)
    self.clubid      = clubid
    self.signin_day  = signin_day
    self.researchs   = {} --我的科技列表
    for k,v in pairs(researchs) do
        self.researchs[k] = math.floor(v)
    end
end

function clubmodel:getclubid()
    return self.clubid or 0
end


function clubmodel:signin()
    self.signin_day   = dateutils.getday()
    skynet.call(".clubcenterd", "lua", "signin", self.clubid, UID, self.signin_day)
end

function clubmodel:researchlvup(id, lv)
    self.researchs[id] = self.researchs[id] or 0
    self.researchs[id] = self.researchs[id] + lv
    skynet.call(".clubcenterd", "lua", "researchlvup", UID, id, lv)
end

--科技重置
function clubmodel:reset(work, type)
    local parms = {}
    for k,v in pairs(self.researchs) do
        self.researchs[k] = 0
        parms[k] = 0
    end
    skynet.call(".clubcenterd", "lua", "reset", parms)
end

function clubmodel:getsignin()
    return self.signin_day
end

function clubmodel:getresearchs()
    return self.researchs
end

return clubmodel
