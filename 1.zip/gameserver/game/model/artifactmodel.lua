local skynet = require "skynet"
local cjson  = require "cjson"
local artifactlogic = require "artifactlogic"
local mqhelper = require "mqhelper"
local settings = require "settings"

require "functions"

local artifactmodel = {}

function artifactmodel:init(arts)
    arts = arts or {}
    self.arts = {}
    for _, v in ipairs(arts) do
        if v.num > 0 then
            local art    = {}
            art.id       = self:getid(v.artid, v.star)
            art.artid    = v.artid
            art.star     = v.star
            art.num      = v.num
            art.collect_emblemstar = v.collect_emblemstar or 0 --收集徽星次数
            art.heroid   = v.heroid or {}
            table.insert(self.arts, art)
        end
    end

end

function artifactmodel:getid(artid, star)
    return math.floor(artid * 1000 + star)
end

function artifactmodel:add(data)
    local id = self:getid(data.artid, 1)
    local art = self:getart(id)
    if art ~= nil then
        art.num = art.num + 1
        self:save(art.id)
    else
        local art  = {}
        art.id       = id
        art.artid    = data.artid
        art.star     = 1
        art.num      = 1
        art.heroid   = {}
        art.collect_emblemstar = 0
        table.insert(self.arts, art)
        self:save(art.id)
    end
end

function artifactmodel:getart(id)
    for i,art in ipairs(self.arts) do
        if art.id == id then
            return art
        end
    end
end

function artifactmodel:getartbyartid(artid)
    local star = 0
    for i,art in ipairs(self.arts) do
        if artid == art.artid and art.star > star then
            star = art.star
        end
    end
    return star
end

--获取收集过的次数
function artifactmodel:getcollectcount(artid)
    local n = 0
    for i,art in ipairs(self.arts) do
        if artid == art.artid then
            n = n + art.collect_emblemstar
        end
    end
    return n
end

--收集徽星
-- function artifactmodel:collectemblemstar(artid, n)
--     local art = self:getart(id)
--     -- DEBUG("collectemblemstar art = ", DUMP(art))
--     assert(art~=nil, " collectemblemstar 不存在的鱼灵 ")
--     assert(art.collect_emblemstar < art.star, " 收集失败 ")
--     art.collect_emblemstar = art.collect_emblemstar + 1
--     self:save(id)
-- end

--收集徽星
function artifactmodel:collectemblemstar(artid)
    local t = {}
    for i,art in ipairs(self.arts) do
        if artid == art.artid then
            table.insert(t, art)
        end
    end
    table.sort( t, function(a, b) return a.star < b.star end)
    for _, art in ipairs(t) do
        if art.collect_emblemstar == 0 then
            art.collect_emblemstar = 1
            self:save(art.id)
            return art.star
        end
    end
    return 0
end

--获取收集徽星的阶段
function artifactmodel:getcollectemblemstar(id)
    local art = self:getart(id)
    assert(art~=nil, " getcollectemblemstar 不存在的鱼灵 ")
    return art.collect_emblemstar
end


function artifactmodel:wear(id, heroid)
    local art = self:getart(id)
    assert(art~=nil and art.num > 0, "不存在的鱼灵")
    table.insert(art.heroid, heroid)
    self:save(id)
end


function artifactmodel:getartbyheroid(heroid)
    for artid, art in ipairs(self.arts) do
        local h = art.heroid
        for i,v in ipairs(h) do
            if v == heroid then
                return art
            end
        end
    end
end

function artifactmodel:takeoffqi(heroid)
    local found = false
    for artid, art in ipairs(self.arts) do
        for i,v in ipairs(art.heroid) do
            if checkint(v) == heroid then
                table.remove(art.heroid, i)
                found = true
                self:save(art.id)
                break
            end
        end
        if found then
            break
        end
    end
end

function artifactmodel:serialize()
    local temps = {}
    for k,v in ipairs(self.arts) do
        local temp  = {}
        if v.num > 0 then
            temp.id       = self:getid(v.artid, v.star)
            temp.artid    = v.artid
            temp.star     = v.star
            temp.num      = v.num
            temp.heroid   = table.array(v.heroid)
            table.insert(temps, temp)
        end
    end
    return table.array(temps)
end


--图鉴
function artifactmodel:serializebook()

    local function checkstar(a, t)
        local found = false
        for i,v in ipairs(t) do
            if a.artid == v.artid then
                found = true
                break
            end
        end
        if found then
            for i,v in ipairs(t) do
                if a.artid == v.artid and a.star > v.star then
                    return true
                end
            end
        else
            return true
        end
        return false
    end

    local temps = {}
    for k,v in ipairs(self.arts) do
        local temp  = {}
        if v.num > 0 and checkstar(v, temps) then
            temp.id       = self:getid(v.artid, v.star)
            temp.artid    = v.artid
            temp.star     = v.star
            temp.num      = v.num
            temp.heroid   = table.array(v.heroid)
            temp.collect_emblemstar =  v.collect_emblemstar
            table.insert(temps, temp)
        end
    end
    return table.array(temps)
end

--序列化可以穿身上的鱼灵
function artifactmodel:serializewaer()
    local arts = {}
    for artid, art in ipairs(self.arts) do
        if art.num > #art.heroid then
             table.insert(arts, art)
        end
    end
    return arts
end

--检查鱼灵升星
function artifactmodel:checkstarup(id)
    local art = self:getart(id)
    assert(art~=nil, " starup 不存在的鱼灵 ")
    local cnf = artifactlogic.getconf(id)
    local spend = cnf.spend
    local h = art.heroid
    if spend <= 0 or art.num - #h <= spend then
        return false
    end
    return true
end

--鱼灵升星
function artifactmodel:starup(id)
    local art = self:getart(id)
    assert(art~=nil, " starup 不存在的鱼灵 ")
    local h = art.heroid
    local cnf = artifactlogic.getconf(id)
    local spend = cnf.spend
    assert(spend > 0, " 不能升星 ")
    assert(art.num - #h > spend, " 鱼灵数量不够 ")
    local artid = art.artid
    local star = art.star + 1
    local newid = self:getid(artid, star)
    local newart = self:getart(newid)
    --存在高星鱼灵
    if newart ~= nil then
        newart.num   = newart.num + 1
        self:save(newart.id)
    else
        local newart = {}
        newart.id       = self:getid(artid, star)
        newart.artid    = artid
        newart.star     = star
        newart.num      = 1
        newart.heroid   = {}
        newart.collect_emblemstar = 0
        table.insert(self.arts, newart)
        self:save(newart.id)
    end
    art.num      = art.num - spend - 1
    self:save(art.id)
    DEBUG("starup arts = ", DUMP(arts))
end


function artifactmodel:getattrabs(k, heroid)
    local art = self:getartbyheroid(heroid)
    if art ~= nil then
        return artifactlogic.getattrabs(k, art.id)
    end
    return 0
end


function artifactmodel:getattrext(k, heroid)
    local art = self:getartbyheroid(heroid)
    if art ~= nil then
        return artifactlogic.getattrext(k, art.id)
    end
    return 0
end

function artifactmodel:getlimitattrext(k, heroid)
    local art = self:getartbyheroid(heroid)
    if art ~= nil then
        return artifactlogic.getlimitattrext(k, heroid, art.id)
    end
    return 0
end


function artifactmodel:save(id)
    local art = self:getart(id)
    assert(art~=nil, " save 不存在的鱼灵 ")
    local data = clone(art)
    data.id = nil
    DEBUG("artifactmodel save = ", cjson.encode(data))
    local ok = skynet.call(".usercenterd", "lua", "saveartifact", UID, data)
    local ok = mqhelper.exec("upsert", UID, settings.artifact_mongodb_key.tname, settings.artifact_mongodb_key.cname, {["$set"]=data}, {artid=data.artid, star=data.star, uid=UID})
end

return artifactmodel
