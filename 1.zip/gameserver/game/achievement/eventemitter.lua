local channel       = require "channel"

local EventEmitter = {}
function EventEmitter:new()
    local obj = {
        events = {},  -- 监听的所有事件
        channels = {}, -- event: channel
    }
    setmetatable(obj, self)
    self.__index = self
    return obj
end

function EventEmitter:registerEvent(name, desc)
    self.events[name] = desc
end

function EventEmitter:registerCallback(event, callback)
    assert(event)
    assert(callback)
    if not self.events[event] then
        error("not register event: "..event)
    end
    local ch = self.channels[event]
    if not ch then
        ch = channel:new(event)
        self.channels[event] = ch
    end
    ch:on(callback)
end

function EventEmitter:emit(event, ...)
    if not self.events[event] then
        error("not register event: "..event)
    end

    local ch = self.channels[event]
    if not ch then return end

    for _, listener in ipairs(ch.listeners) do
        listener.callback(...)
    end
end
return EventEmitter