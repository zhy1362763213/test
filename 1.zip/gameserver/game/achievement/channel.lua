local listener       = require "listener"

local Channel = {}
function Channel:new(event)
    assert(event)
    local obj = {
        listeners = {},
        event = event,
    }
    setmetatable(obj, self)
    self.__index = self
    return obj
end

function Channel:on(callback)
    local li = listener:new(self, callback)
    table.insert(self.listeners, li)
end

return Channel