------------------------------------------------------ 事件触发器
local Listener = {}
function Listener:new(channel, callback)
    local obj = {
        callback = callback,
        channel = channel,
    }
    setmetatable(obj, self)
    self.__index = self
    return obj
end


local Channel = {}
function Channel:new(event)
    assert(event)
    local obj = {
        listeners = {},
        event = event,
    }
    setmetatable(obj, self)
    self.__index = self
    return obj
end

function Channel:on(callback)
    listener = Listener:new(self, callback)
    table.insert(self.listeners, listener)
end


local EventEmitter = {}
function EventEmitter:new()
    local obj = {
        events = {},  -- 监听的所有事件
        channels = {}, -- event: channel
    }
    setmetatable(obj, self)
    self.__index = self
    return obj
end

function EventEmitter:setEvents(events)
    self.events = events
end

function EventEmitter:on(event, callback)
    assert(event)
    assert(callback)
    if not self.events[event] then
        error("not register event: "..event)
    end
    local channel = self.channels[event]
    if not channel then
        channel = Channel:new(event)
        self.channels[event] = channel
    end
    channel:on(callback)
end

function EventEmitter:emit(event)
    if not self.events[event] then
        error("not register event: "..event)
    end

    local channel = self.channels[event]
    if not channel then return end

    for _, listener in ipairs(channel.listeners) do
        listener.callback()
    end
end
----------------------------------------------------- 装备模块
local eventEmitter = EventEmitter:new()
eventEmitter:setEvents({
    ["equipStrengthen"] = "装备强化",
})


function equipStrengthen()
    -- 装备强化逻辑
    eventEmitter:emit("equipStrengthen")
end

------------------------------------------------------ 成就模块
function checkAchievement()
    print('checkAchievement')
end

eventEmitter:on("equipStrengthen", checkAchievement)  -- 成就模块注册监听

------------------------------------------------------ 时装模块
function checkObtainFashion()
    print('checkObtainFashion')
end

eventEmitter:on("equipStrengthen", checkObtainFashion)  -- 时装模块注册监听
------------------------------------------------------------------------------------
function main()
    equipStrengthen()
end

main()