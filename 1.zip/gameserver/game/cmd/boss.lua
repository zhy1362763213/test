local skynet        = require "skynet"
local netpack       = require "websocketnetpack"
local msgutils      = require "msgutils"
local cjson         = require "cjson"
local usermodel     = require "usermodel"
local bagmodel      = require "bagmodel"
local heromodel     = require "heromodel"
local settings      = require "settings"
local dateutils     = require "dateutils"
local usermodel     = require "usermodel"
local heromodel     = require "heromodel"
local bagmodel      = require "bagmodel"
local bosslogic     = require "bosslogic"

local boss = {}

function boss.load(cmd)
    local list = skynet.call(".bossd", "lua", "loadrank", UID, usermodel:getServer())
    -- DEBUG("boss load list = ", DUMP(list))
    local rank = {}
    local players = {}
    for k,v in pairs(list) do
        table.insert(rank, {uid=checkint(k), harm=checkint(v)})
        table.insert(players, checkint(k))
    end

    table.sort( rank, function(a, b)
        if a.harm == b.harm then
            return tonumber(a.uid) > tonumber(b.uid)
        end
        return a.harm > b.harm
    end)
    DEBUG("boss load players = ", cjson.encode(players))
    local ok, ret = pcall(skynet.call, ".usercenterd", "lua", "getuserinfolist", players)
    local myrank = 0
    local found = false
    if ok then
        for i,v in ipairs(rank) do
            v.nickname = ret[v.uid].nickname
            v.avatar = ret[v.uid].avatar
            v.zhanli = ret[v.uid].zhanli
            if tonumber(v.uid) == UID then
                found = true
                myrank = i
            end
        end
    end
    if not found then
        local r = skynet.call(".bossd", "lua", "loadmyrank", UID, usermodel:getServer())
        myrank = r
    end
    --获取我的伤害
    local harm = skynet.call(".bossd", "lua", "loadmyharm", UID, usermodel:getServer()) or 0
    local max_harm = 0
    if #rank > 0 then
        max_harm = rank[1].harm
    end
    return {c = "boss",m = "load", data = {errcode = 0, errmsg = "", data = {harm=tonumber(harm), max_harm=max_harm, rank=table.array(rank), myrank=myrank, overtime=dateutils.getdayex(), boss_id = bosslogic.getcurboss()}}}
end


function boss.success(cmd)
    local harm = cmd.data.harm
    if not harm then
        return {c = "boss",m = "success", data = {errcode = 10001, errmsg = "请求异常,请稍后再试", data = {}}}
    end
    harm = checkint(harm)
    -- local conf = bosslogic.getconf()
    local oldhm = skynet.call(".bossd", "lua", "loadmyharm",  UID, usermodel:getServer()) or 0
    oldhm = checkint(oldhm)
    local rews = {}
    if harm > oldhm then
        local rewards = bosslogic.getbossrewards(oldhm, harm)

        local param = {}
        for i,v in ipairs(rewards) do
            param[v.key] = param[v.key] or 0
            param[v.key] = param[v.key] + v.value
            table.insert(rews, {tp="item", id=v.key, count=v.value})
        end

        if duanwumodel._init then
            if #rewards > 0 then
                param["zongzi_lv1"] = #rewards
                table.insert(rews, {tp="item", id="zongzi_lv1", count=#rewards})
            end
        end

        if #table.keys(param) > 0 then
            bagmodel:incrBagB(param)
        end
        skynet.call(".bossd", "lua", "success", UID, usermodel:getServer(), harm)
    end
    return {c = "boss",m = "success", data = {errcode = 0, errmsg = "", data = { rewards = table.array(rews)}}}
end

return boss