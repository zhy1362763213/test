local skynet        = require "skynet"
local netpack       = require "websocketnetpack"
local msgutils      = require "msgutils"
local cjson         = require "cjson"
local usermodel     = require "usermodel"
local bagmodel      = require "bagmodel"
local heromodel     = require "heromodel"
local settings      = require "settings"
local dateutils     = require "dateutils"
local usermodel     = require "usermodel"
local heromodel     = require "heromodel"
local bagmodel      = require "bagmodel"
local mongohelper   = require "mongohelper"
local friendmodel   = require "friendmodel"
local clubmodel     = require "clubmodel"
local msgmodel      = require "msgmodel"
local clublogic   = require "clublogic"

local club = {}

--加载俱乐部信息
function club.loadclub(cmd)
    local myclub = skynet.call(".clubcenterd", "lua", "loadclubinfo", UID)
    if not myclub then
        return {c = "club",m = "loadclub", data = {errcode = 10001, errmsg = "未加入俱乐部", data = {}}}
    end
    if not clubmodel._init or clubmodel._init ~= dateutils.getday() then
        local signin    = skynet.call(".clubcenterd", "lua", "loadsignin", UID)
        assert(signin ~= nil , "签到信息获取失败")
        local researchs = skynet.call(".clubcenterd", "lua", "loadresearch", UID)
        assert(researchs ~= nil , "科技信息获取失败")
        clubmodel:init(myclub.id, signin, researchs)
        clubmodel._init = dateutils.getday()
    end
    myclub._id = nil
    myclub.signin = clubmodel:getsignin()
    myclub.researchs = clubmodel:getresearchs()
    return {c = "club",m = "loadclub", data = {errcode = 0, errmsg = "", data = {club=myclub}}}
end


function club.loadmembers(cmd)
    local clubid = cmd.data.clubid
    local members = skynet.call(".clubcenterd", "lua", "loadclubmembers", clubid)
    local players = {}
    for i,v in ipairs(members) do
        table.insert(players, v.uid)
    end
    local ret = skynet.call(".usercenterd", "lua", "getuserinfolist", players)
    local users = {}
    for i,v in ipairs(members) do
        local u = ret[v.uid]
        u.identity = v.identity
        table.insert(users, u)
    end
    return {c = "club",m = "loadmembers", data = {errcode = 0, errmsg = "", data = {users=table.array(users)}}}
end



--获取俱乐部消息
function club.loadclubmsg(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "club",m = "loadclubmsg",data = {errcode = 10001,errmsg = "请求异常, 请稍后再试!", data = { }}}
    end
    id = checkint(id)
    if clubmodel._init then
        local clubid = clubmodel:getclubid()
        local msgs = skynet.call(".msgcenterd", "lua", "loadclubmsg", clubid, id)
        if #msgs > 0 then
            local lastid = msgs[#msgs].id
            msgmodel.clubindex = lastid
        end
        return {c = "club",m = "loadclubmsg", data = {errcode = 0, errmsg = "", data = { msgs =  table.array(msgs)}}}
    end
    return {c = "club",m = "loadclubmsg", data = {errcode = 0, errmsg = "", data = { msgs =  table.array({})}}}
end


--获取招募消息
function club.loadrecruitmsg(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "club",m = "loadrecruitmsg",data = {errcode = 10001,errmsg = "请求异常, 请稍后再试!", data = { }}}
    end
    id = checkint(id)
    local msgs = skynet.call(".msgcenterd", "lua", "loadrecruitmsg", usermodel:getserverid(), id)
    if #msgs > 0 then
        local lastid = msgs[#msgs].id
        msgmodel.recruitindex = lastid
    end
    return {c = "club",m = "loadrecruitmsg", data = {errcode = 0, errmsg = "", data = { msgs = msgs}}}
end

--获取推荐俱乐部
function club.loadrecomclub(cmd)
    local list = skynet.call(".clubcenterd", "lua", "loadrecomclub", usermodel:getArenaServer())
    return {c = "club",m = "loadrecomclub", data = {errcode = 0, errmsg = "", data = {list=table.array(list)}}}
end

--搜索俱乐部
function club.searchclub(cmd)
    local text = cmd.data.text
    if not text then
        return {c = "club",m = "searchclub",data = {errcode = 10001,errmsg = "请求异常, 请稍后再试!", data = { }}}
    end
    local list = skynet.call(".clubcenterd", "lua", "searchclub", usermodel:getArenaServer(), text)
    return {c = "club",m = "searchclub", data = {errcode = 0, errmsg = "", data = {list=table.array(list)}}}
end

--获取伤害排行
function club.loadharmrank(cmd)
    local clubid = cmd.data.clubid
    local myrank, rank = skynet.call(".clubcenterd", "lua", "loadharmrank", UID, clubid)
    local players = {}
    for k,v in pairs(rank) do
        table.insert(players, checkint(k))
    end
    local ret = skynet.call(".usercenterd", "lua", "getuserinfolist", players)
    local users = {}
    for k,v in pairs(rank) do
        local u = ret[checkint(k)]
        u.harm = checkint(v)
        table.insert(users, u)
    end
    return {c = "club",m = "loadmembers", data = {errcode = 0, errmsg = "", data = {myrank=myrank, users=table.array(users)}}}
end

--创建俱乐部
function club.createclub(cmd)
    local name = cmd.data.name
    local description = cmd.data.description
    if not name or not description then
        return {c = "club",m = "createclub",data = {errcode = 10001,errmsg = "请求异常, 请稍后再试!", data = { }}}
    end
    local is_valid = skynet.call(".word_crab", "lua", "is_valid", name)
    if not is_valid then
        return {c = "user",m = "sendmsg",data = {errcode = 10002, errmsg = "名称存在违规词!", data = { }}}
    end
    local is_valid = skynet.call(".word_crab", "lua", "is_valid", description)
    if not is_valid then
        return {c = "user",m = "sendmsg",data = {errcode = 10003, errmsg = "描述存在违规词!", data = { }}}
    end
    local ok = skynet.call(".clubcenterd", "lua", "loadclubinfo", UID)
    if ok then
        return {c = "club",m = "createclub", data = {errcode = 10004, errmsg = "不能创建俱乐部", data = {}}}
    end
    local id = skynet.call(".id_service", "lua", "genid", "club")
    local info = {
        id=id,
        uid=UID,
        serverid=usermodel.serverid,
        name=name,
        avatar=usermodel.avatar,
        description=description,
        exp=0,
        lv=1,
        bossid=1,
        created_at = dateutils.get_datetime()
    }
    local ok = skynet.call(".clubcenterd", "lua", "create", id, info)
    mongohelper.insert(settings.club_mongodb_key.tname, settings.club_mongodb_key.cname, info)
    local member = {
        clubid=id,
        uid=UID,
        identity=1,
        created_at = dateutils.get_datetime()
    }
    local ok = skynet.call(".clubcenterd", "lua", "saveuser", UID, member)
    mongohelper.insert(settings.club_member_mongodb_key.tname, settings.club_member_mongodb_key.cname, member)
    --TODO:减少金砖
    bagmodel:decrBagA("gold",1000)
    bagmodel:save2log({gold=-1000}, "创建俱乐部")
    return {c = "club",m = "createclub", data = {errcode = 0, errmsg = "", data = {club=info}}}
end

function club.updatename(cmd)
    local text = cmd.data.text
    if not text then
        return {c = "club",m = "updatename",data = {errcode = 10001,errmsg = "请求异常, 请稍后再试!", data = { }}}
    end
    if text == "" then
        return {c = "club",m = "updatename",data = {errcode = 10002,errmsg = "请求异常, 请稍后再试!", data = { }}}
    end
    local is_valid = skynet.call(".word_crab", "lua", "is_valid", text)
    if not is_valid then
        return {c = "user",m = "sendmsg",data = {errcode = 10003, errmsg = "存在违规词!", data = { }}}
    end
    if usermodel.gold < 4000 then
        return {c = "club",m = "updatename",data = {errcode = 10003,errmsg = "金砖数量不足", data = { }}}
    end
    bagmodel:decrBagA("gold", 4000)
    local data = {
        name=text,
        updated_at=dateutils.get_datetime()
    }
    local ok = skynet.call(".clubcenterd", "lua", "save", clubmodel.clubid, data)
    return {c = "club",m = "updatename",data = {errcode = 0,errmsg = "", data = { }}}
end

function club.updatedescription(cmd)
    local text = cmd.data.text
    if not text then
        return {c = "club",m = "updatedescription",data = {errcode = 10001,errmsg = "请求异常, 请稍后再试!", data = { }}}
    end
    if text == "" then
        return {c = "club",m = "updatedescription",data = {errcode = 10002,errmsg = "请求异常, 请稍后再试!", data = { }}}
    end
    local is_valid = skynet.call(".word_crab", "lua", "is_valid", text)
    if not is_valid then
        return {c = "user",m = "sendmsg",data = {errcode = 10003, errmsg = "存在违规词!", data = { }}}
    end
    local data = {
        description=text,
        updated_at=dateutils.get_datetime()
    }
    local ok = skynet.call(".clubcenterd", "lua", "save", clubmodel.clubid, data)
    return {c = "club",m = "updatedescription",data = {errcode = 0,errmsg = "", data = { }}}
end


function club.updateavatar(cmd)
    local text = cmd.data.text
    if not text then
        return {c = "club",m = "updateavatar",data = {errcode = 10001,errmsg = "请求异常, 请稍后再试!", data = { }}}
    end
    if text == "" then
        return {c = "club",m = "updateavatar",data = {errcode = 10002,errmsg = "请求异常, 请稍后再试!", data = { }}}
    end

    local data = {
        avatar=text,
        updated_at=dateutils.get_datetime()
    }
    local ok = skynet.call(".clubcenterd", "lua", "save", clubmodel.clubid, data)
    return {c = "club",m = "updateavatar",data = {errcode = 0,errmsg = "", data = { }}}
end


function club.sendmail(cmd)
    local text = cmd.data.text
    if not text then
        return {c = "club",m = "sendmail", data = {errcode = 10001, errmsg = "请求异常", data = {}}}
    end
    if text == "" then
        return {c = "club",m = "sendmail", data = {errcode = 10002, errmsg = "请输入邮件内容", data = {}}}
    end
    local is_valid = skynet.call(".word_crab", "lua", "is_valid", text)
    if not is_valid then
        return {c = "user",m = "sendmsg",data = {errcode = 10003, errmsg = "存在违规词!", data = { }}}
    end
    local num = skynet.call(".clubcenterd", "lua", "getsendmailnum", clubmodel.clubid)

    if num >= 3 then
        return {c = "club",m = "sendmail", data = {errcode = 10003, errmsg = "发送邮件已达上限", data = {}}}
    end

    local members = skynet.call(".clubcenterd", "lua", "loadclubmembers", clubmodel.clubid)
    skynet.fork(function()
        for i,v in ipairs(members) do
            local id = skynet.call(".id_service", "lua", "genid", "mail")
            local mail = {
                id=id,
                tp="system",
                sender=usermodel.nickname,
                receiver=v.uid,
                status=0, --未读
                title="【军团邮件】",
                content=text,
                rewards = {},
                created_at=dateutils.get_datetime()
            }
            skynet.send(".maild", "lua", "sendmail", v.uid, mail)
        end
    end)
    --添加发送邮件次数
    local num = skynet.call(".clubcenterd", "lua", "addsendmailnum", clubmodel.clubid)
    return {c = "club",m = "sendmail", data = {errcode = 0, errmsg = "", data = { sendmailnum = num}}}
end

--俱乐部签到
function club.signin(cmd)

    if not clubmodel.sign_day or clubmodel.sign_day == dateutils.getday() then
        return {c = "club",m = "signin", data = {errcode = 10001, errmsg = "签到失败", data = {}}}
    end

    clubmodel:signin()
    bagmodel:incrBagA("juntuanbi", 30)
    bagmodel:save2log({juntuanbi=30}, "俱乐部签到成功")
    local rewards = {
        {tp="item", id="juntuanbi", count=30},
        {tp="exp", id="exp", count=30}
    }
    return {c = "club",m = "signin", data = {errcode = 0, errmsg = "", data = {rewards=rewards}}}
end

function club.attackboss(cmd)
    local clubid = cmd.data.clubid
    local bossid = cmd.data.bossid
    local harm = cmd.data.harm
    if not clubid or not bossid or not harm then
        return {c = "club",m = "attackboss",data = {errcode = 10001,errmsg = "请求异常, 请稍后再试!", data = { }}}
    end
    local ok, errmsg = skynet.call(".clubcenterd", "lua", "attackboss", UID, clubid, bossid, harm)
    if not ok then
        return {c = "club",m = "attackboss", data = {errcode = 10002, errmsg = errmsg, data = {}}}
    end
    --TODO 击败奖励
    local params = {
        juntuanbi=34,
        coin=34000
    }
    bagmodel:incrBagB(params)
    bagmodel:save2log(params, "攻打boss成功")
    local rewards = {
        {tp="juntuanbi", count=34},
        {tp="coin", count=34000}
    }
    return {c = "club",m = "attackboss", data = {errcode = 0, errmsg = errmsg, data = {rewards=rewards}}}
end


--科技升级
function club.researchlvup(cmd)
    local id = cmd.data.id
    local lv = cmd.data.lv
    if not id or not lv then
        return {c = "club",m = "researchlvup",data = {errcode = 10001,errmsg = "请求异常, 请稍后再试!", data = { }}}
    end
    --金币
    local speedcoin = 100
    local speedjuntuanbi = 100
    if bagmodel.coin < speedcoin or bagmodel.juntuanbi < speedjuntuanbi then
        return {c = "club",m = "researchlvup",data = {errcode = 10002,errmsg = "资源不足", data = { }}}
    end
    local params = {
        coin=speedcoin,
        juntuanbi=speedjuntuanbi
    }
    bagmodel:decrBagB(params)
    clubmodel:researchlvup(id, lv)
    return {c = "club",m = "researchlvup", data = {errcode = 0, errmsg = "", data = {}}}
end

--重置
function club.reset(cmd)
    local tp = cmd.data.tp
    if not tp then
        return {c = "club",m = "reset",data = {errcode = 10001,errmsg = "请求异常, 请稍后再试!", data = { }}}
    end

    return {c = "club",m = "reset", data = {errcode = 0, errmsg = "", data = {}}}
end

--发送招募消息
function club.sendrecruitmsg(cmd)
    local content = cmd.data.content
    if not content then
        return {c = "club",m = "sendrecruitmsg",data = {errcode = 10001, errmsg = "请求异常, 请稍后再试!", data = { }}}
    end
    if content == "" then
        return {c = "club",m = "sendrecruitmsg",data = {errcode = 10002, errmsg = "消息不能为空!", data = { }}}
    end
    local is_valid = skynet.call(".word_crab", "lua", "is_valid", content)
    if not is_valid then
        return {c = "user",m = "sendmsg",data = {errcode = 10003, errmsg = "存在违规词!", data = { }}}
    end
    local myclub = skynet.call(".clubcenterd", "lua", "loadclubinfo", clubmodel.clubid)
    assert(myclub~=nil, "俱乐部信息获取失败")
    local num = skynet.call(".clubcenterd", "lua", "loadclubmembernum", clubmodel.clubid)
    assert(num~=nil, "成员数量获取失败")
    local id = skynet.call(".id_service", "lua", "genid", "recruitmsg")
    assert(id~=nil, "id 获取失败")
    local msg = {
        id=id,
        serverid=usermodel:getserverid(),
        clubid=myclub.id,
        clubname=myclub.name,
        clublv=myclub.lv,
        size=checkint(num).."/"..checkint(myclub.size),
        sender=usermodel:get_look_info(),
        content=content,
        created_at=dateutils.get_datetime()
    }
    skynet.call(".msgcenterd", "lua", "sendrecruitmsg", usermodel:getserverid(), msg)
    skynet.send(".msgd", "lua", "sendrecruitmsg", usermodel:getserverid(), msg)
    return {c = "club",m = "sendrecruitmsg", data = {errcode = 0, errmsg = "", data = {}}}
end

--俱乐部聊天
function club.sendmsg(cmd)
    local content = cmd.data.content
    if not content then
        return {c = "club",m = "sendmsg",data = {errcode = 10001, errmsg = "请求异常, 请稍后再试!", data = { }}}
    end
    if content == "" then
        return {c = "club",m = "sendmsg",data = {errcode = 10002, errmsg = "消息不能为空!", data = { }}}
    end
    local is_valid = skynet.call(".word_crab", "lua", "is_valid", content)
    if not is_valid then
        return {c = "user",m = "sendmsg",data = {errcode = 10003, errmsg = "存在违规词!", data = { }}}
    end
    local id = skynet.call(".id_service", "lua", "genid", "clubmsg")
    assert(id~=nil, "id 获取失败")
    local msg = {
        id=id,
        clubid=clubmodel.clubid,
        sender=usermodel:get_look_info(),
        content=content,
        created_at=dateutils.get_datetime()
    }
    skynet.call(".msgcenterd", "lua", "sendclubmsg", clubmodel.clubid, msg)
    skynet.send(".msgd", "lua", "sendclubmsg", clubmodel.clubid, msg)
    return {c = "club",m = "sendmsg", data = {errcode = 0, errmsg = "", data = {}}}
end


return club