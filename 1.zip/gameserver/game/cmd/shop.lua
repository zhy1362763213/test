local skynet        = require "skynet"
local netpack       = require "websocketnetpack"
local msgutils      = require "msgutils"
local cjson         = require "cjson"
local usermodel     = require "usermodel"
local bagmodel      = require "bagmodel"
local heromodel     = require "heromodel"
local settings      = require "settings"
local dateutils     = require "dateutils"
local shoplogic     = require "shoplogic"
local mongohelper   = require "mongohelper"
--金砖商城


local shop = {}

--商城购买金砖
function shop.buy(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "shop",m = "buy",data = {errcode = 10001, errmsg = "请求异常, 请稍后再试!",data = { } }}
    end
    local conf = shoplogic.getconf(id)

    if conf == nil then
        return {c = "shop",m = "buy",data = {errcode = 10002, errmsg = "配置获取失败, 请稍后再试!",data = { } }}
    end

    local order_no = skynet.call(".id_service", "lua", "getuuid")

    local log = {
        uid=UID,
        openid=usermodel.openid,
        regionid=usermodel.regionid,
        serverid=usermodel.serverid,
        order_no=order_no,
        description = "购买金砖",
        prepay_id="",
        payment=conf.price,
        pay_status=0,
        pay_type="goldshop",
        recharge_id=tostring(id),
        recharge_conf=conf,
        complete=0,
        completed_at="",
        created_at=dateutils.get_datetime()
    }
    local ok = mongohelper.insert(settings.recharge_mongodb_key.tname, settings.recharge_mongodb_key.cname, log)
    if not ok then
        return {c = "shop",m = "buy",data = {errcode = 10003, errmsg = "充值失败, 请稍后再试", data = { } }}
    end
    return {c = "shop",m = "buy", data = {errcode = 0, errmsg = "",data = { order = log } }}
end


return shop