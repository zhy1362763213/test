local skynet        = require "skynet"
local netpack       = require "websocketnetpack"
local msgutils      = require "msgutils"
local cjson         = require "cjson"
local usermodel     = require "usermodel"
local bagmodel      = require "bagmodel"
local heromodel     = require "heromodel"
local settings      = require "settings"
local dateutils     = require "dateutils"
local fundlogic     = require "fundlogic"
local mongohelper   = require "mongohelper"
local mqhelper      = require "mqhelper"
local coingetmodel = require "coingetmodel"
local dailydealmodel = require "dailydealmodel"
local fundmodel = require "fundmodel"
local fukamodel = require "fukamodel"
local daybuymodel = require "daybuymodel"
local signinmodel = require "signinmodel"
local limitshopmodel = require "limitshopmodel"
local friendmodel = require "friendmodel"
local arenamodel  = require "arenamodel"
local signinlogic = require "signinlogic"
local redishelper = require "redishelper"

--竞技场

local function loadbottleusers()
    local ok, ret =  pcall(skynet.call, ".arenad", "lua", "loaduserscore", UID, usermodel:getArenaServer(), checkint(usermodel.arena_level))
    local myscore = checkint(ret[1])
    local myrank = checkint(ret[2])
    local min = math.max(0, myscore - 200)
    local max = checkint(myscore + 200)
    local ok, rands = pcall(skynet.call, ".arenad", "lua", "loadbackupusers", UID, usermodel:getArenaServer(), checkint(usermodel.arena_level), min, max, myrank)
    local players = {}
    for k,v in pairs(rands) do
        table.insert(players, v.uid)
    end
    local ok, users = pcall(skynet.call, ".usercenterd", "lua", "getuserinfolist", players)
    local list = {}
    for k,v in pairs(rands) do
        local u = users[v.uid]
        u.score = math.max(1000, checkint(u.score) + 1000)
        table.insert(list, u)
    end
    return list
end


local function loadrandmousers()
    local ok, ret = pcall(skynet.call, ".arenad", "lua", "loaduserscore", UID, usermodel:getArenaServer(), checkint(usermodel.arena_level))
    assert(ok, "排行榜获取失败")
    assert(ret ~= nil)
    local myscore = checkint(ret[1])
    local myrank = checkint(ret[2])
    local min = math.max(0, myscore - 200)
    local max = checkint(myscore + 200)
    local ok, rands = pcall(skynet.call, ".arenad", "lua", "loadrandmousers", UID, usermodel:getArenaServer(), checkint(usermodel.arena_level), min, max, myrank+1)
    local players = {}
    for k,v in pairs(rands) do
        table.insert(players, v.uid)
    end
    local ok, users = pcall(skynet.call, ".usercenterd", "lua", "getuserinfolist", players)
    local list = {}
    for k,v in pairs(rands) do
        local u = users[v.uid]
        u.score = math.max(1000, checkint(u.score) + 1000)
        table.insert(list, u)
    end
    return list
end

local function checkopen()
    local h = dateutils.get_hour()
    if h < 6 or h > 22 then
        return false
    end
    return true
end

local function tablesort(ranks)
    table.sort( ranks, function(a, b)
        if a.score == b.score then
            return a.uid < b.uid
        end
        return a.score > b.score
    end)
    return ranks
end


--获取我的信息
local function getme(uid, ranks)
    for i,v in ipairs(ranks) do
        if v.uid == uid then
            return i, v.score
        end
    end
    return 99999, 1000
end

local function canlvup(level, rankno)
    if level == 1 then
        if rankno <= 30 then
            return 1
        end
    end
    if level == 2 then
        if rankno <= 20 then
            return 1
        end
        if rankno > 40 then
            return -1
        end
    end
    if level == 3 then
        if rankno <= 30 then
            return 1
        end
        if rankno > 70 then
            return -1
        end
    end
    if level == 4 then
        if rankno <= 20 then
            return 1
        end
        if rankno > 60 then
            return -1
        end
    end
    if level == 5 then
        if rankno <= 20 then
            return 1
        end
        if rankno > 120 then
            return -1
        end
    end
    return 0
end

local arena = {}

function arena.loadarenamsg(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "arena",m = "loadarenamsg",data = {errcode = 10001,errmsg = "请求异常, 请稍后再试!", data = { }}}
    end
    id = checkint(id)
    if arenamodel._init then
        local msgs = skynet.call(".msgcenterd", "lua", "loadarenamsg", arenamodel:calcurserverid(), id)
        if #msgs > 0 then
            local lastid = msgs[#msgs].id
            msgmodel.arenaindex = lastid
        end
        return {c = "arena",m = "loadarenamsg", data = {errcode = 0, errmsg = "", data = { msgs = table.array(msgs)}}}
    end
    return {c = "arena",m = "loadarenamsg", data = {errcode = 0, errmsg = "", data = { msgs = table.array({})}}}
end

--加载竞技场
function arena.loadarena(cmd)
    if not checkopen() then
        return {c = "arena",m = "loadarena", data = {errcode = 10001, errmsg = "竞技场未到开放时间", data = {}}}
    end

    local groupid = skynet.call(".arenad", "lua", "getgroupid", UID)
    if not groupid then
        if dateutils.get_week() == 7 and dateutils.get_hour() > 20 then
            return {c = "arena",m = "loadarena", data = {errcode = 10002, errmsg = "分组时间已停止", data = {}}}
        end
        local ok, rank = pcall(skynet.call, ".arenad", "lua", "loadlastweekrank", UID, usermodel:getArenaServer(), checkint(usermodel.arena_level))
        local ranks = {}
        for k,v in pairs(rank) do
            table.insert(ranks, {uid=k, score=math.max(1000, checkint(v) + 1000)})
        end
        local ranks = tablesort(ranks)
        local rankno, _ = getme(UID, ranks)
        if checkint(usermodel.arena_level) <= 5 then
            local r = canlvup(checkint(usermodel.arena_level), rankno)
            usermodel.arena_level = usermodel.arena_level + r
        else
            local t = #ranks
            t = math.floor(t * 0.3)
            if rankno > t then
                usermodel.arena_level = usermodel.arena_level - 1
            end
        end
        -- DEBUG("usermodel.arena_level = ", usermodel.arena_level)
    end

    if not arenamodel._init or arenamodel._init ~= dateutils.getday() then
        local ok, groupid = pcall(skynet.call, ".arenad", "lua", "joingroup", UID, usermodel:getArenaServer(), checkint(usermodel.arena_level))
        assert(ok, "分组失败")
        arenamodel:init(usermodel:getArenaServer(), checkint(usermodel.arena_level), groupid)
        arenamodel._init = dateutils.getday()
    end

    local ok, rank = pcall(skynet.call, ".arenad", "lua", "loadrank", UID, usermodel:getArenaServer(), checkint(usermodel.arena_level))
    assert(ok, "排行榜获取失败")
    assert(rank ~= nil)

    local players = {}
    for k,v in pairs(rank) do
        table.insert(players, checkint(k))
    end

    local ok, users = pcall(skynet.call, ".usercenterd", "lua", "getuserinfolist", players)
    local ranks = {}
    for k,v in pairs(rank) do
        local u = users[checkint(k)]
        u.score = math.max(1000, checkint(v) + 1000)
        table.insert(ranks, u)
    end
    local ranks = tablesort(ranks)
    local myrank, myscore = getme(UID, ranks)
    assert(myrank ~= nil, "我的数据获取失败")
    return {c = "arena",m = "loadarena", data = {errcode = 0, errmsg = "", data = {myrank=myrank, myscore=myscore, ranks=table.array(ranks)}}}
end

--设置防守阵容
function arena.setdeflineup(cmd)
    if not checkopen() then
        return {c = "arena",m = "setdeflineup", data = {errcode = 10001, errmsg = "竞技场未到开放时间", data = {}}}
    end
    local lineup =  cmd.data.lineup -- {{heroid=heroid, pos=pos}, {heroid=heroid, pos=pos}}
    if not lineup then
        return {c = "arena",m = "setdeflineup", data = {errcode = 10001, errmsg = "请求异常", data = {}}}
    end

    if #lineup <= 0 then
        return {c = "arena",m = "setdeflineup", data = {errcode = 10002, errmsg = "没有上阵任何武将", data = {}}}
    end
    local ret = {}
    local heros = {}
    for _,v in ipairs(lineup) do
        local heroid = checkint(v.heroid)
        local pos = checkint(v.pos)
        local hero = heromodel:serializebyheroid(heroid)
        assert(hero ~= nil, "英雄未找到")
        hero.pos = pos
        table.insert(heros, hero)
    end
    ret.heros = heros
    ret.lord = usermodel:getcurattr()
    local ok = pcall(skynet.call, ".arenad", "lua", "setdeflineup", UID, cjson.encode(ret)) --防守阵容
    return {c = "arena",m = "setdeflineup", data = {errcode = 0, errmsg = "", data = {}}}
end

--获取挑战用户
function arena.loadbottleusers(cmd)
    if not checkopen() then
        return {c = "arena",m = "loadbottleusers", data = {errcode = 10001, errmsg = "竞技场未到开放时间", data = {}}}
    end
    local list = loadbottleusers()
    local ok, battlenum = pcall(skynet.call, ".arenad", "lua", "getbattlenum", UID) --获取挑战次数
    local ok, refreshnum = pcall(skynet.call, ".arenad", "lua", "getrefreshnum", UID) --获取刷新次数
    return {c = "arena",m = "loadbottleusers", data = {errcode = 0, errmsg = "", data = {users=table.array(list), battlenum=battlenum, refreshnum=refreshnum}}}
end


--刷新挑战列表
function arena.refreshbottleusers(cmd)
    if not checkopen() then
        return {c = "arena",m = "refreshbottleusers", data = {errcode = 10001, errmsg = "竞技场未到开放时间", data = {}}}
    end
    local ok, num = pcall(skynet.call, ".arenad", "lua", "getrefreshnum", UID) --获取挑战次数
    if num >= 1 and bagmodel.gold <= 20 then
        return {c = "arena",m = "refreshbottleusers", data = {errcode = 10002, errmsg = "金砖不足", data = {}}}
    end
    local list = loadrandmousers()
    if #list > 0 then
        bagmodel:decrBagA("gold", 20)
    end
    local ok, refreshnum = pcall(skynet.call, ".arenad", "lua", "incrrefreshnum", UID)
    return {c = "arena",m = "refreshbottleusers", data = {errcode = 0, errmsg = "", data = {users=table.array(list), refreshnum=refreshnum}}}
end


--获取防守阵容
function arena.loaddeflineup(cmd)
    if not checkopen() then
        return {c = "arena",m = "loaddeflineup", data = {errcode = 10001, errmsg = "竞技场未到开放时间", data = {}}}
    end
    local userid = cmd.data.userid
    if not userid then
        return {c = "arena",m = "loaddeflineup", data = {errcode = 10001, errmsg = "请求异常", data = {}}}
    end
    local ok, lineup = pcall(skynet.call, ".arenad", "lua", "getdeflineup", userid)
    local ok, resp = pcall(cjson.decode, lineup)
    if ok then
        return {c = "arena",m = "loaddeflineup", data = {errcode = 0, errmsg = "", data = {lineup=resp}}}
    end
    local ok, lineup = pcall(skynet.call, ".usercenterd", "lua", "loaduserlineup", userid)
    return {c = "arena",m = "loaddeflineup", data = {errcode = 0, errmsg = "", data = {lineup=lineup}}}
end

--挑战
function arena.battle(cmd)
    if not checkopen() then
        return {c = "arena",m = "battle", data = {errcode = 10001, errmsg = "竞技场未到开放时间", data = {}}}
    end
    local tp = cmd.data.tp
    local userid = cmd.data.userid
    local battles =  cmd.data.battles
    if not tp or not userid or not battles then
        return {c = "arena",m = "battle", data = {errcode = 10001, errmsg = "请求异常", data = {}}}
    end
    userid = checkint(userid)
    local ok, users = pcall(skynet.call, ".arenad", "lua", "loadbackupusers", UID, usermodel:getArenaServer(), checkint(usermodel.arena_level), min, max) --获取挑战用户列表
    local found = false
    for i,v in ipairs(users) do
        if v.uid == checkint(userid) then
            found = true
        end
    end
    if not found then
        return {c = "arena",m = "battle", data = {errcode = 10002, errmsg = "挑战用户不存在", data = {}}}
    end
    local ok, num = pcall(skynet.call, ".arenad", "lua", "getbattlenum", UID) --获取挑战次数
    assert(ok, "挑战次数获取失败")
    if checkint(num) < 3 then
        --TODO:增加经济经验
    end
    if checkint(num) >= 3 then
        if bagmodel.xianshenmenpiao <= 0 then
            return {c = "arena",m = "battle", data = {errcode = 10003, errmsg = "门票不足", data = {}}}
        end
        bagmodel:decrBagA("xianshenmenpiao", 1)
    end

    local myscore = 0
    local youscore = 0
    if tp == "success" then
        myscore = 20
        youscore = -20
        local ok, myscore = pcall(skynet.call, ".arenad", "lua", "savescore", UID, userid, usermodel:getArenaServer(), checkint(usermodel.arena_level), myscore, youscore)

    elseif tp == "fail" then
        myscore = -20
        youscore = 20
        local ok, myscore = pcall(skynet.call, ".arenad", "lua", "savescore", UID, userid, usermodel:getArenaServer(), checkint(usermodel.arena_level), myscore, youscore)
    else
        assert(false, "不应该走到这~~~")
    end
    taskmodel:addtasknum(8, 1)
    pcall(skynet.call, ".arenad", "lua", "incrbattlenum", UID)
    local list = loadrandmousers()
    local id = skynet.call(".id_service", "lua", "genid", "arena")
    local log = {
        id=id,
        atk_uid=UID,
        atk_score=myscore,
        def_uid=userid,
        def_score=youscore,
        battles={},
        created_at=dateutils.get_datetime()
    }
    local ok = mqhelper.exec("insert", UID, settings.arena_log_mongodb_key.tname, settings.arena_log_mongodb_key.cname, log)
    return {c = "arena",m = "battle", data = {errcode = 0, errmsg = "", data = {myscore=myscore, youscore=youscore, users=table.array(list)}}}
end


--竞技场消息
function arena.sendmsg(cmd)
    local content = cmd.data.content
    if not content then
        return {c = "arena",m = "sendmsg",data = {errcode = 10001, errmsg = "请求异常, 请稍后再试!", data = { }}}
    end
    if content == "" then
        return {c = "arena",m = "sendmsg",data = {errcode = 10002, errmsg = "消息不能为空!", data = { }}}
    end

    if not arenamodel._init then
        return {c = "arena",m = "sendmsg",data = {errcode = 10003, errmsg = "请先加入竞技场", data = { }}}
    end

    local is_valid = skynet.call(".word_crab", "lua", "is_valid", content)
    if not is_valid then
        return {c = "arena",m = "sendmsg",data = {errcode = 10004, errmsg = "存在违规词!", data = { }}}
    end
    local id = skynet.call(".id_service", "lua", "genid", "arenamsg")
    assert(id~=nil, "id 获取失败")
    local msg = {
        id=id,
        server=arenamodel:calcurserverid(),
        sender=usermodel:get_look_info(),
        content=content,
        created_at=dateutils.get_datetime()
    }
    skynet.call(".msgcenterd", "lua", "sendarenamsg", arenamodel:calcurserverid(), msg)
    skynet.send(".msgd", "lua", "sendarenamsg", arenamodel:calcurserverid(), msg)
    return {c = "arena",m = "sendmsg", data = {errcode = 0, errmsg = "", data = {}}}
end

return arena