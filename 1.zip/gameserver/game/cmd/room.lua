local skynet        = require "skynet"
local netpack       = require "websocketnetpack"
local msgutils      = require "msgutils"
local cjson         = require "cjson"
local usermodel     = require "usermodel"
local bagmodel      = require "bagmodel"
local heromodel     = require "heromodel"
local friendmodel   = require "friendmodel"
local taskmodel     =  require "taskmodel"
local settings      = require "settings"
local bson          = require "bson"
local mqhelper      = require "mqhelper"
local mongohelper   = require "mongohelper"
local dateutils     = require "dateutils"
local artifactmodel = require "artifactmodel"
local artifactlogic = require "artifactlogic"
local saltpotlogic  = require "saltpotlogic"
local coingetlogic  = require "coingetlogic"
--客厅

local room = {}


function room.loadroom(cmd)
    local mypot = skynet.call(".usercenterd", "lua", "getusersaltpot", UID)
    local robpots = skynet.call(".usercenterd", "lua", "getuserrobsaltpots", UID)
    return {c = "room",m = "loadroom", data = {errcode = 0, errmsg = "", data = { mypot=mypot, robpots=robpots}}}
end


--加载战报
function room.loadmail(cmd)
    local mails = skynet.call(".maild", "lua", "loadroommail", UID)
    return {c = "room",m = "loadmail",data = {errcode = 0, errmsg = "", data = { mails = mails}}}
end


--加载好友
function room.loadfriend(cmd)
    local friends = friendmodel:serialize()
    local ids = {}
    for i,v in ipairs(friends) do
        table.insert(ids, v.friendid)
    end
    local list = skynet.call(".usercenterd", "lua", "getsaltpotlist", ids) --获取盐罐信息

    local function getuser(userid, list)
        for i,v in ipairs(list) do
            if v.uid == userid then
                return v
            end
        end
    end

    for i,v in ipairs(friends) do
        local ret = getuser(v.friendid, list)
        if ret then
            v.saltpot = ret.saltpot
            v.owner = ret.owner
        end
    end

    return {c = "room",m = "loadfriend",data = {errcode = 0, errmsg = "", data = { friends=friends }}}
end

--加载排行榜
function room.loadrank(cmd)
    local rank = skynet.call(".usercenterd", "lua", "getsaltpotrank", UID)
    return {c = "room",m = "loadrank",data = {errcode = 0, errmsg = "", data = { rank=rank }}}
end

--占领盐罐
function room.robsaltpot(cmd)
    local userid = cmd.data.userid
    local lineup = cmd.data.lineup --{{heroid=heroid, pos=1}, {heroid=heroid, pos=1}}
    if not userid or not lineup or #lineup <= 0 then
        return {c = "room",m = "robsaltpot",data = {errcode = 10001,errmsg = "请求异常,请稍后再试", data = { }}}
    end

    local n = skynet.call(".roomd", "lua", "getsaltpotnum", UID)
    if #n >= 3 then
        return {c = "room",m = "robsaltpot",data = {errcode = 10002,errmsg = "最多占领3个盐罐", data = { }}}
    end

    userid = math.floor(userid)
    local pot = skynet.call(".usercenterd", "lua", "getusersaltpot", userid)
    if not pot then
        return {c = "room",m = "robsaltpot",data = {errcode = 10003,errmsg = "不存在的盐罐", data = { }}}
    end

    local robpots = skynet.call(".roomd", "lua", "getsaltpotlist", UID)
    for k, v in pairs(robpots) do
        local d = cjson.decode(k)
        if checkint(d.level) == pot.level then
            return {c = "room",m = "robsaltpot",data = {errcode = 10004,errmsg = "已经占领过这种类型的罐子", data = { }}}
        end
    end
    local lineuped = {}
    for k, v in pairs(robpots) do
        local d = cjson.decode(k)
        for _, v1 in ipairs(d.lineup) do
            table.insert(lineuped, v1.heroid)
        end
    end

    local function checkhero(heroid, lineuped)
        for _, hid in ipairs(lineuped) do
            if hid == heroid then
                return true
            end
        end
        return false
    end
    for _,v in ipairs(lineup) do
        if checkhero(v.heroid, lineuped) then
            return {c = "room",m = "robsaltpot",data = {errcode = 10005,errmsg = "防守武将设置失败, 请勿重复设置", data = { }}}
        end
    end
    local num = skynet.call(".roomd", "lua", "incrrobnum", UID)
    if num > 10 then
        return {c = "room",m = "robsaltpot",data = {errcode = 10006,errmsg = "盐罐已达上限", data = { }}}
    end
    local t = saltpotlogic.gettime(checkint(pot.level), num)
    local ok = skynet.call(".usercenterd", "lua", "robsaltpot", UID, userid, lineup, t)

    local ok = skynet.call(".roomd", "lua", "robsaltpot", UID, cjson.encode({userid=userid, level=level, lineup=lineup}), os.time()+t)

    if pot.rob_id > 0 then
        skynet.call(".roomd", "lua", "removesaltpot", pot.rob_id, cjson.encode({userid=pot.rob_id, level=pot.level, lineup=pot.rob_lineup}))
        --TODO 发送一个邮件
    end
    return {c = "room",m = "robsaltpot",data = {errcode = 0, errmsg = "", data = { }}}
end

--收集盐罐
function room.collectsaltpot(cmd)
    local level = cmd.data.level
    if not level then
        return {c = "room",m = "collectsaltpot",data = {errcode = 10001,errmsg = "请求异常,请稍后再试", data = { }}}
    end
    level = math.floor(level)

    local found = false
    local robpots = skynet.call(".roomd", "lua", "getsaltpotlist", UID)
    local member
    for k, v in pairs(robpots) do
        local d = cjson.decode(k)
        if checkint(d.level) == pot.level then
            found = true
            member = k
            break
        end
    end

    if not found then
        return {c = "room",m = "collectsaltpot",data = {errcode = 10003,errmsg = "未占领该等级的盐罐", data = { }}}
    end
    local ok = skynet.call(".usercenterd", "lua", "collectsaltpot", UID, level)
    assert(ok=="ok", "收集盐罐失败")
    skynet.call(".roomd", "lua", "removesaltpot", UID, member)
    --TODO 发送一个邮件
    local coin = coingetlogic.getcoingetnum(usermodel.max_level)
    --TODO 计算奖励
    local rewards = saltpotlogic.getrewards(level)
    local param = {}
    for i,v in ipairs(rewards) do
        if v.key == "coin" then
            v.count = v.value * coin
            param[v.key] = param[v.key] or 0
            param[v.key] = param[v.key] + v.count
        else
            param[v.key] = param[v.key] or 0
            param[v.key] = param[v.key] + v.value
        end
    end
    bagmodel:incrBagB(param)
    taskmodel:addtasknum(10, 1)
    return {c = "room",m = "collectsaltpot",data = {errcode = 0,errmsg = "", data = { rewards = rewards }}}
end

--鱼灵升星
function room.qistarup(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "room",m = "qistarup",data = {errcode = 10001,errmsg = "请求异常,请稍后再试", data = { }}}
    end

    if not artifactmodel:checkstarup(id) then
        return {c = "room",m = "qistarup",data = {errcode = 10002,errmsg = "无法升星", data = { }}}
    end
    artifactmodel:starup(id)
    return {c = "room",m = "qistarup",data = {errcode = 0,data = {}}}
end


--钓鱼
function room.fishing(cmd)
    local lv = cmd.data.lv
    local num = cmd.data.num
    if not lv or not num then
        return {c = "room",m = "fishing", data = {errcode = 10001, errmsg = "请求异常", data = { }}}
    end
    lv = math.floor(lv)
    num = math.floor(num)
    if lv ~= 1 or num > 1 or not usermodel:checkfishing() then
        if bagmodel:getyugannum(lv) < num then
            return {c = "room",m = "fishing", data = {errcode = 10001, errmsg = "资源不足", data = { }}}
        end
    end
    local rewards = artifactlogic.fishing(lv, num, usermodel:getfishingnum(lv))
    if #rewards <= 0 then
        return {c = "room",m = "fishing", data = {errcode = 10002, errmsg = "捕获失败", data = { }}}
    end
    local param = {}
    for i,v in ipairs(rewards) do
        if v.tp == "qi" then
            local art = {}
            art.artid = v.id
            artifactmodel:add(art)
            v.id = artifactmodel:getid(v.id, 1)
        else
            param[v.id] = param[v.id] or 0
            param[v.id] = param[v.id] + 1
        end

    end
    if lv == 1 and num == 1 and usermodel:checkfishing() then
         usermodel:updatefishingtime()
    else
        bagmodel:decrBagA("yugan_lv"..lv, num)
    end
    if #table.keys(param) > 0 then
        bagmodel:incrBagB(param)
    end
    bagmodel:save2log(param, "捕获成功")
    usermodel:incrfishingnum(lv, num)
    if lv == 1 then
        usermodel:incrfishingscore(num)
        -- local s = usermodel.fishing_score%20
        -- if s == 0 then
        --     bagmodel:incrBagA("yugan_lv2", 1)
        -- end
    end
    return {c = "room",m = "fishing", data = {errcode = 0, errmsg = "", data = { rewards = rewards }}}
end

function room.receiveyuguan(cmd)
    local score = usermodel.fishing_score
    if score < 20 then
        return {c = "room",m = "receiveyuguan", data = {errcode = 10001, errmsg = "积分不足", data = { }}}
    end

    local n = math.floor(score/20)
    if n <= 0 then
        return {c = "room",m = "receiveyuguan", data = {errcode = 10002, errmsg = "积分不足", data = { }}}
    end
    usermodel:decrfishingscore(n)
    bagmodel:incrBagA("yugan_lv2", n)
    return {c = "room",m = "receiveyuguan", data = {errcode = 0, errmsg = "", data = { }}}
end

--挑战
function room.battle(cmd)
    local userid = cmd.data.userid
    local tp = cmd.data.tp
    if not userid or not tp then
        return {c = "room",m = "battle", data = {errcode = 10001, errmsg = "请求异常", data = { }}}
    end

    local my = skynet.call(".usercenterd", "lua", "getuserbyid", UID)
    local user = skynet.call(".usercenterd", "lua", "getuserbyid", userid)
    local ownerid = skynet.call(".usercenterd", "lua", "getuserowner", userid)
    if ownerid > 0 then
        local owner = skynet.call(".usercenterd", "lua", "getuserbyid", ownerid)
        skynet.send(".roomd", "lua", "sendcombatreport2myself", tp, my, user, owner) --发送战报
        skynet.send(".roomd", "lua", "sendcombatreport2user", tp, my, user, owner)
        skynet.send(".roomd", "lua", "sendcombatreportowner", tp, my, user, owner)
    else
        skynet.send(".roomd", "lua", "sendcombatreport2myself", tp, my, user) --发送战报
        skynet.send(".roomd", "lua", "sendcombatreport2user", tp, my, user)
    end

    if tp == "success" then
        skynet.call(".usercenterd", "lua", "updateowner", UID, userid)
    end

    return {c = "room",m = "battle", data = {errcode = 0, errmsg = "", data = { }}}
end

return room