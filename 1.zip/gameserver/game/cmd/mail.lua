local skynet        = require "skynet"
local netpack       = require "websocketnetpack"
local msgutils      = require "msgutils"
local cjson         = require "cjson"
local usermodel     = require "usermodel"
local bagmodel      = require "bagmodel"
local heromodel     = require "heromodel"
local settings      = require "settings"
local dateutils     = require "dateutils"
local usermodel     = require "usermodel"
local heromodel     = require "heromodel"
local bagmodel      = require "bagmodel"
local mailmodel     = require "mailmodel"

local mail = {}

local typs = {
    system=true,
    daily=true,
    game=true,
}

local function checktp(tp)
    return typs[tp]
end

--获取邮件信息
function mail.loadmail(cmd)
    if not mailmodel._init or mailmodel._init ~= dateutils.getday()  then
        local mails = skynet.call(".maild", "lua", "loadmail", UID)
        -- DEBUG("mails = ", DUMP(mails))
        assert(mails~=nil, "邮件获取失败")
        mailmodel:init(mails)
        mailmodel._init = dateutils.getday()
    end
    return {c = "mail",m = "loadmail", data = {errcode = 0, errmsg = "", data = {mails=mailmodel:serialize()}}}
end

function mail.read(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "mail",m = "read", data = {errcode = 10000, errmsg = "请求异常", data = {}}}
    end

    local mail = mailmodel:getmail(id)
    assert(mail~=nil, "邮件不存在")
    mailmodel:readbyid(id)
    local rewards = mail.rewards
    if #rewards > 0 then
        local param = {}
        for i,v in ipairs(rewards) do
            param[v.key] = param[v.key] or 0
            param[v.key] = param[v.key] + v.value
        end
        bagmodel:incrBagB(param)
    end
    return {c = "mail",m = "read", data = {errcode = 0, errmsg = "", data = {}}}
end

function mail.receive(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "mail",m = "receive", data = {errcode = 10000, errmsg = "请求异常", data = {}}}
    end

    local mail = mailmodel:getmail(id)
    assert(mail~=nil, "邮件不存在")
    mailmodel:receivereward(id)
    local rewards = mail.rewards
    if #rewards > 0 then
        local param = {}
        for i,v in ipairs(rewards) do
            param[v.key] = param[v.key] or 0
            param[v.key] = param[v.key] + v.value
        end
        bagmodel:incrBagB(param)
    end
    return {c = "mail",m = "receive", data = {errcode = 0, errmsg = "", data = {}}}
end

--一键已读
function mail.readall(cmd)
    local tp = cmd.data.tp
    if not checktp(tp) then
        return {c = "mail",m = "readall", data = {errcode = 10000, errmsg = "请求异常", data = {}}}
    end
    if not mailmodel:checkunread(tp) then
         return {c = "mail",m = "readall", data = {errcode = 10001, errmsg = "没有未读邮件", data = {}}}
    end
    local rewards = mailmodel:getallrewards()
    mailmodel:readall(tp)
    if #rewards > 0 then
        local param = {}
        for i,v in ipairs(rewards) do
            param[v.key] = param[v.key] or 0
            param[v.key] = param[v.key] + v.value
        end
        bagmodel:incrBagB(param)
    end
    return {c = "mail",m = "readall", data = {errcode = 0, errmsg = "", data = {}}}
end


--删除
function mail.del(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "mail",m = "del", data = {errcode = 10000, errmsg = "请求异常", data = {}}}
    end
    local mail = mailmodel:getmail(id)
    assert(mail~=nil, "邮件不存在")
    mailmodel:delmailbyid(id)
    return {c = "mail",m = "del", data = {errcode = 0, errmsg = "", data = {}}}
end

function mail.delreadall(cmd)
    local tp = cmd.data.tp
    if not checktp(tp) then
        return {c = "mail",m = "delreadall", data = {errcode = 10000, errmsg = "请求异常", data = {}}}
    end
    if not mailmodel:checkread(tp) then
         return {c = "mail",m = "delreadall", data = {errcode = 10000, errmsg = "没有已读邮件", data = {}}}
    end
    mailmodel:delreadall(tp)
    return {c = "mail",m = "delreadall", data = {errcode = 0, errmsg = "", data = {}}}
end

return mail