local skynet        = require "skynet"
local netpack       = require "websocketnetpack"
local msgutils      = require "msgutils"
local cjson         = require "cjson"
local usermodel     = require "usermodel"
local bagmodel      = require "bagmodel"
local heromodel     = require "heromodel"
local settings      = require "settings"
local dateutils     = require "dateutils"
local fundlogic     = require "fundlogic"
local mongohelper   = require "mongohelper"
local mqhelper      = require "mqhelper"
local coingetmodel = require "coingetmodel"
local dailydealmodel = require "dailydealmodel"
local fundmodel = require "fundmodel"
local fukamodel = require "fukamodel"
local daybuymodel = require "daybuymodel"
local signinmodel = require "signinmodel"
local limitshopmodel = require "limitshopmodel"
local friendmodel = require "friendmodel"
local heishimodel = require "heishimodel"
local baoxiangmodel = require "baoxiangmodel"
local zhaomumodel   = require "zhaomumodel"
local duanwumodel   = require "duanwumodel"
local invitemodel   = require "invitemodel"
local artifactmodel = require "artifactmodel"
local inviteconf   = require "inviteconf"
local signinlogic = require "signinlogic"
local activitylogic = require "activitylogic"
local fukalogic    = require "fukalogic"
local dailydeallogic = require "dailydeallogic"
local shoplimitlogic = require "shoplimitlogic"

--活动

local activity = {}

--获取签到信息
function activity.loadsignin(cmd)
    --获取用户签到信息
    if not signinmodel._init or signinmodel._init ~= dateutils.getday() then
        local signin = skynet.call(".signind", "lua", "getsignin", UID)
        signinmodel:init(signin)
        signinmodel._init = dateutils.getday()
    end

    return {c = "activity",m = "loadsignin",data = {errcode = 0,data = { signin = signinmodel:serialize()}}}
end

--获取用户每日特惠购买信息
function activity.loaddailydeal(cmd)
    --获取用户每日特惠购买信息
    if not dailydealmodel._init or dailydealmodel._init ~= dateutils.getday() then
        local buyinfo, receiveinfo = skynet.call(".dailydeald", "lua", "getinfo", UID)
        dailydealmodel:init(buyinfo, receiveinfo)
        dailydealmodel._init = dateutils.getday()
    end
    return {c = "activity",m = "loaddailydeal",data = {errcode = 0, data = { dailydeal = dailydealmodel:serialize()}}}
end

--获取积天好礼
function activity.loaddaybuy(cmd)
    --获取积天好礼
    if not daybuymodel._init or daybuymodel._init ~= dateutils.getday() then
        local buyinfo, receiveinfo = skynet.call(".daybuyd", "lua", "getinfo", UID)
        daybuymodel:init(buyinfo, receiveinfo)
        daybuymodel._init = dateutils.getday()
    end
    return {c = "activity",m = "loaddaybuy",data = {errcode = 0, data = { daybuy = daybuymodel:serialize()}}}
end

--获取用户基金信息
function activity.loadfund(cmd)
    --获取用户基金信息
    if not fundmodel._init or fundmodel._init ~= dateutils.getday() then
        local fund = skynet.call(".fundd", "lua", "get", UID)
        fundmodel:init(fund)
        fundmodel._init = dateutils.getday()
    end
    return {c = "activity",m = "loadfund",data = {errcode = 0, data = { fund = fundmodel:serialize()}}}
end


--获取购买的福卡信息
function activity.loadfuka(cmd)
    --获取购买的福卡信息
    if not fukamodel._init or fukamodel._init ~= dateutils.getday() then
        local buyinfo, receiveinfo = skynet.call(".fukad", "lua", "getinfo", UID)
        fukamodel:init(buyinfo, receiveinfo)
        fukamodel._init = dateutils.getday()
    end
    return {c = "activity",m = "loadfuka",data = {errcode = 0, data = { fuka = fukamodel:serialize()}}}
end


--获取限购商城信息
function activity.loadlimitshop(cmd)
    --获取限购商城信息
    if not limitshopmodel._init or limitshopmodel._init ~= dateutils.getday() then
        local shop = skynet.call(".limitshopd", "lua", "loadbuyinfo", UID)
        limitshopmodel:init(shop)
        limitshopmodel._init = dateutils.getday()
    end
    return {c = "activity",m = "loadlimitshop",data = {errcode = 0, data = { limitshop = limitshopmodel:serialize()}}}
end


--购买限购商城
function activity.buylimitshop(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "activity",m = "buylimitshop",data = {errcode = 10001, errmsg = "请求异常, 请稍后再试!",data = { } }}
    end

    id = checkint(id)
    local conf = shoplimitlogic.getconfbyid(id)

    if conf == nil then
        return {c = "activity",m = "buylimitshop",data = {errcode = 10002, errmsg = "配置获取失败, 请稍后再试!",data = { } }}
    end

    if not limitshopmodel:checkbuy(id) then
        return {c = "activity",m = "buylimitshop",data = {errcode = 10003, errmsg = "已到达最大购买次数!",data = { } }}
    end

    local order_no = skynet.call(".id_service", "lua", "getuuid")

    local log = {
        uid=UID,
        openid=usermodel.openid,
        regionid=usermodel.regionid,
        serverid=usermodel.serverid,
        order_no=order_no,
        description = "购买限购商品",
        prepay_id="",
        payment=conf.price,
        pay_status=0,
        pay_type="buylimitshop", --首冲礼包
        recharge_id=tostring(id),
        recharge_conf=conf,
        complete=0,
        completed_at="",
        created_at=dateutils.get_datetime()
    }
    local ok = mongohelper.insert(settings.recharge_mongodb_key.tname, settings.recharge_mongodb_key.cname, log)
    if not ok then
        return {c = "activity",m = "buylimitshop",data = {errcode = 10003, errmsg = "限购商品购买失败, 请稍后再试", data = { } }}
    end
    return {c = "activity",m = "buylimitshop", data = {errcode = 0, errmsg = "",data = { order = log } }}
end



function activity.loadfirstrecharge(cmd)
    return {c = "activity",m = "loadfirstrecharge",data = {errcode = 0, data = { }}}
end

--首冲
-- function activity.firstrecharge(cmd)
--     local id = cmd.data.id
--     if not id then
--         return {c = "activity",m = "firstrecharge",data = {errcode = 10001, errmsg = "请求异常, 请稍后再试!",data = { } }}
--     end
--     local conf = firstrechargeconf.getconf(id)
--     if conf == nil then
--         return {c = "activity",m = "firstrecharge",data = {errcode = 10002, errmsg = "配置获取失败, 请稍后再试!",data = { } }}
--     end

--     local order_no = skynet.call(".id_service", "lua", "getuuid")

--     local log = {
--         uid=UID,
--         openid=usermodel.openid,
--         regionid=usermodel.regionid,
--         serverid=usermodel.serverid,
--         order_no=order_no,
--         description = "购买首冲礼包",
--         prepay_id="",
--         payment=payment,
--         pay_status=0,
--         pay_type="first_recharge", --首冲礼包
--         recharge_id=tostring(id),
--         recharge_conf=conf,
--         completed_at="",
--         created_at=dateutils.get_datetime()
--     }
--     local ok = mongohelper.insert(settings.recharge_mongodb_key.tname, settings.recharge_mongodb_key.cname, log)
--     if not ok then
--         return {c = "activity",m = "firstrecharge",data = {errcode = 10003, errmsg = "首冲礼包购买失败, 请稍后再试", data = { } }}
--     end
--     return {c = "activity",m = "firstrecharge", data = {errcode = 0, errmsg = "",data = { } }}
-- end

--签到
function activity.signin(cmd)

    if not signinmodel:checksign() then
        return {c = "activity",m = "signin",data = {errcode = 10001,errmsg = "签到失败", data = { }}}
    end

    local days = signinmodel:signin()
    local param = {}
    local rewards = {}
    for _, d in ipairs(days) do
        local cnf = signinlogic.getsigninconf(d)
        assert(cnf~= nil, "配置获取失败")
        local reward = cnf.rewards
        for i,v in ipairs(reward) do
            param[v.key] = param[v.key] or 0
            param[v.key] = param[v.key] + v.value
            table.insert(rewards, {tp="item", id=v.key, count=v.value})
        end
    end
    bagmodel:incrBagB(param)
    local data = {
        uid=UID,
        serverid=usermodel.serverid,
        days=days,
        rewards=rewards,
        created_at=dateutils.get_datetime(os.time())
    }
    mqhelper.exec("insert", UID, settings.sign_log_mongodb_key.tname, settings.sign_log_mongodb_key.cname, data)

    return {c = "activity",m = "signin", data = {errcode = 0, data = {}}}
end


--领取积天好礼
function activity.receivedaybuy(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "activity",m = "receivedaybuy", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end

    if daybuymodel:getpaydaynum() < id then
        return {c = "activity",m = "receivedaybuy", data = {errcode = 10002, errmsg = "积天次数不足"}}
    end

    if not daybuymodel:checkcanreceive(id) then
        return {c = "activity",m = "receivedaybuy", data = {errcode = 10003, errmsg = "请勿重复领取"}}
    end
    --TODO:获取奖励
    local cfg = activitylogic.daybuyconf(id)
    local rewards = cfg.rewards
    local param = {}
    for i,v in ipairs(rewards) do
        param[v.key] = param[v.key] or 0
        param[v.key] = param[v.key] + v.value
    end
    bagmodel:incrBagB(param)
    daybuymodel:receive(id)
    return {c = "activity",m = "receivedaybuy", data = {errcode = 0, errmsg = ""}}
end

--购买基金
function activity.buyfund(cmd)
    local fundid = cmd.data.fundid
    if not fundid then
        return {c = "activity",m = "buyfund", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end
    local conf = fundlogic.getconf(fundid)
    assert(conf~=nil)
    local price = conf.price

    local order_no = skynet.call(".id_service", "lua", "getuuid")


    local log = {
        uid=UID,
        openid=usermodel.openid,
        regionid=usermodel.regionid,
        serverid=usermodel.serverid,
        order_no=order_no,
        description = "购买基金",
        prepay_id="",
        payment=price,
        pay_status=0,
        pay_type="buyfund",
        recharge_id=tostring(fundid),
        recharge_conf=conf,
        complete=0,
        completed_at="",
        created_at=dateutils.get_datetime()
    }
    local ok = mongohelper.insert(settings.recharge_mongodb_key.tname, settings.recharge_mongodb_key.cname, log)
    if not ok then
        return {c = "activity",m = "buyfund",data = {errcode = 10003, errmsg = "购买基金失败, 请稍后再试", data = { } }}
    end

    return {c = "activity",m = "buyfund",data = {errcode = 0, errmsg = "", data = { order = log} }}
end



--购买基金
function activity.buyfundios(cmd)
    local fundid = cmd.data.fundid
    if not fundid then
        return {c = "activity",m = "buyfundios", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end
    local conf = fundlogic.getconf(fundid)
    assert(conf~=nil)
    local price = conf.price

    local order_no = skynet.call(".id_service", "lua", "getuuid")


    local log = {
        uid=UID,
        openid=usermodel.openid,
        regionid=usermodel.regionid,
        serverid=usermodel.serverid,
        order_no=order_no,
        description = "购买基金",
        prepay_id="",
        payment=price,
        pay_status=0,
        pay_type="buyfund",
        recharge_id=tostring(fundid),
        recharge_conf=conf,
        complete=0,
        completed_at="",
        created_at=dateutils.get_datetime()
    }
    local ok = mongohelper.insert(settings.recharge_mongodb_key.tname, settings.recharge_mongodb_key.cname, log)
    if not ok then
        return {c = "activity",m = "buyfundios",data = {errcode = 10003, errmsg = "购买基金失败, 请稍后再试", data = { } }}
    end

    return {c = "activity",m = "buyfundios",data = {errcode = 0, errmsg = "", data = { order_no = order_no} }}
end


--领取基金
function activity.getfundtask(cmd)
    local taskid = cmd.data.taskid
    if not taskid then
        return {c = "activity",m = "getfundtask", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end
    local conf = fundlogic.gettaskconf(taskid)
    assert(conf~=nil)
    local fundid = conf.fund_id
    --TODO:判断是否购买该基金
    local myfund = fundmodel:getmyfund()
    if myfund[tostring(fundid)] ~= nil then
        if usermodel.max_level < conf.complete_value then
            return {c = "activity",m = "getfundtask", data = {errcode = 10002, errmsg = "关卡数错误, 请先前往通关"}}
        end
        local tasks = fundmodel:gettasks(fundid)
        if tasks[tostring(taskid)] ~= nil then
            return {c = "activity",m = "getfundtask", data = {errcode = 10003, errmsg = "请勿重复领取"}}
        end
        --TODO:领取基金
        fundmodel:receive(fundid, taskid)
        local rewards = fundlogic.getfundreward(taskid)
        for i,v in ipairs(rewards) do
            bagmodel:incrBagA(v.key, v.value)
        end
        --TODO: 领取基金增加mongo日志
        local log = {
            uid=UID,
            serverid=usermodel.serverid,
            taskid=id,
            rewards=rewards,
            created_at=dateutils.get_datetime()
        }
        mqhelper.exec("insert", UID, settings.fund_log_mongodb_key.tname, settings.fund_log_mongodb_key.cname, log)
        return {c = "activity",m = "getfundtask", data = {errcode = 0, errmsg = ""}}
    else
        return {c = "activity",m = "getfundtask", data = {errcode = 10003, errmsg = "请先购买基金"}}
    end
end

--购买每日特惠礼包
function activity.buydailydeal(cmd)
    local dealid = cmd.data.dealid
    if not dealid then
        return {c = "activity",m = "buydailydeal", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end
    if not dailydealmodel._init then
        return {c = "activity",m = "buydailydeal", data = {errcode = 10002, errmsg = "请先获取数据"}}
    end
    dealid = checkint(dealid)
    local conf = dailydeallogic.getconf(dealid)
    assert(conf~=nil)

    local order_no = skynet.call(".id_service", "lua", "getuuid")

    local log = {
        uid=UID,
        openid=usermodel.openid,
        regionid=usermodel.regionid,
        serverid=usermodel.serverid,
        order_no=order_no,
        description = "购买特惠礼包",
        prepay_id="",
        payment=checkint(conf.price),
        pay_status=0,
        pay_type="buydailydeal",
        recharge_id=tostring(dealid),
        recharge_conf=conf,
        complete=0,
        completed_at="",
        created_at=dateutils.get_datetime()
    }
    local ok = mongohelper.insert(settings.recharge_mongodb_key.tname, settings.recharge_mongodb_key.cname, log)
    if not ok then
        return {c = "activity",m = "buydailydeal",data = {errcode = 10003, errmsg = "购买礼包失败, 请稍后再试", data = { } }}
    end
    return {c = "activity",m = "buydailydeal",data = {errcode = 0, errmsg = "", data = { order = log } }}
end

--领取每日免费礼包(每日特惠)
function activity.receivedailydeal(cmd)
    --TODO:判断今日是否领取过礼包
    local dealid = cmd.data.dealid
    if not dealid then
        return {c = "activity",m = "receivedailydeal", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end
    --今天是否领取过
    if not dailydealmodel:checktodaycanget(dealid) then
        return {c = "activity",m = "receivedailydeal", data = {errcode = 10001, errmsg = "今日已领达领取上限"}}
    end
    dealid = checkint(dealid)
    local conf = dailydeallogic.getconf(dealid)
    assert(conf~=nil)
    if conf.price == 0 then
        local ids = dailydealmodel:receive(dealid)
        local rewards = dailydeallogic.getdailydealreward(ids)
        for i,v in ipairs(rewards) do
            bagmodel:incrBagA(v.key, v.value)
        end        --TODO: 领取每日免费礼包mongo日志
        local log = {
            uid=UID,
            serverid=usermodel.serverid,
            dailyid=dealid,
            rewards=rewards,
            created_at=dateutils.get_datetime()
        }
        mqhelper.exec("insert", UID, settings.daily_log_mongodb_key.tname, settings.daily_log_mongodb_key.cname, log)
        return {c = "activity",m = "receivedailydeal", data = {errcode = 0, errmsg = ""}}
    else
        if not dailydealmodel:checkbuy(dealid) then
            return {c = "activity",m = "receivedailydeal", data = {errcode = 10003, errmsg = "请先购买特惠礼包"}}
        end

        if not dailydealmodel:checkcardday(dealid) then
            return {c = "activity",m = "receivedailydeal", data = {errcode = 10003, errmsg = "已经领取过了"}}
        end

        if not dailydealmodel:checktodaycanget(dealid) then
            return {c = "activity",m = "receivedailydeal", data = {errcode = 10003, errmsg = "今日已领达领取上限"}}
        end
        local ids = dailydealmodel:receive(dealid)
        local rewards = dailydeallogic.getdailydealreward(ids)
        for i,v in ipairs(rewards) do
            bagmodel:incrBagA(v.key, v.value)
        end
        --TODO: 领取每日免费礼包mongo日志
        local log = {
            uid=UID,
            serverid=usermodel.serverid,
            dailyid=dealid,
            rewards=rewards,
            created_at=dateutils.get_datetime()
        }
        mqhelper.exec("insert", UID, settings.daily_log_mongodb_key.tname, settings.daily_log_mongodb_key.cname, log)
        return {c = "activity",m = "receivedailydeal", data = {errcode = 0, errmsg = ""}}
    end
end

--购买福利卡
function activity.buyfuka(cmd)
    local fukaid = cmd.data.fukaid
    if not fukaid then
        return {c = "activity",m = "buyfuka", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end

    if fukamodel:checkbuy(fukaid) then
        return {c = "activity",m = "buyfuka", data = {errcode = 10001, errmsg = "请勿重复购买"}}
    end

    fukaid = checkint(fukaid)
    local conf = fukalogic.getconfbyid(fukaid)
    assert(conf~=nil)
    local price = conf.price
    local order_no = skynet.call(".id_service", "lua", "getuuid")
    local log = {
        uid=UID,
        openid=usermodel.openid,
        regionid=usermodel.regionid,
        serverid=usermodel.serverid,
        order_no=order_no,
        description = "购买福卡",
        prepay_id="",
        payment=price,
        pay_status=0,
        pay_type="buyfuka",
        recharge_id=tostring(fukaid),
        recharge_conf=conf,
        complete=0,
        completed_at="",
        created_at=dateutils.get_datetime()
    }
    local ok = mongohelper.insert(settings.recharge_mongodb_key.tname, settings.recharge_mongodb_key.cname, log)
    if not ok then
        return {c = "activity",m = "buyfuka",data = {errcode = 10003, errmsg = "购买福卡失败, 请稍后再试!", data = { } }}
    end
    --购买成功
    return {c = "activity",m = "buyfuka",data = {errcode = 0, errmsg = "", data = { order = log } }}
end



--购买福利卡 ios
function activity.buyfukabyios(cmd)
    local fukaid = cmd.data.fukaid
    if not fukaid then
        return {c = "activity",m = "buyfukabyios", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end

    fukaid = checkint(fukaid)

    local conf = fukalogic.getconfbyid(fukaid)
    assert(conf~=nil)
    local price = conf.price

    local order_no = skynet.call(".id_service", "lua", "getuuid")
    local log = {
        uid=UID,
        openid=usermodel.openid,
        regionid=usermodel.regionid,
        serverid=usermodel.serverid,
        order_no=order_no,
        description = "购买"..conf.name,
        prepay_id="",
        payment=price,
        pay_status=0,
        pay_type="buyfukabyios",
        recharge_id=tostring(id),
        recharge_conf=conf,
        complete=0,
        completed_at="",
        created_at=dateutils.get_datetime()
    }

    local ok = mongohelper.insert(settings.recharge_mongodb_key.tname, settings.recharge_mongodb_key.cname, log)
    if not ok then
        return {c = "activity",m = "buyfukabyios",data = {errcode = 10003, errmsg = "下单失败, 请稍后再试!", data = { } }}
    end

    return {c = "activity",m = "buyfukabyios",data = {errcode = 0, errmsg = "", data = { order_no = order_no } }}
end

--领取副卡奖励
function activity.receivefuka(cmd)
    local fukaid = cmd.data.fukaid
    if not fukaid then
        return {c = "activity",m = "receivefuka", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end
    fukaid = checkint(fukaid)

    local cfg = fukalogic.getconfbyid(fukaid)
    if cfg.price > 0 then
        local fk = fukamodel:getfukabyid(fukaid)
        -- DEBUG("getfukabyid fk = ", fk, " os time = ", os.time())

        if not fk then
            return {c = "activity",m = "receivefuka", data = {errcode = 10002, errmsg = "请先购买福卡"}}
        end
        if fk > 0 and fk < os.time() then
            return {c = "activity",m = "receivefuka", data = {errcode = 10003, errmsg = "已过期"}}
        end
    end
    local d = fukamodel:getreceiveinfo(fukaid)
    -- DEBUG("getreceiveinfo d = ", d)
    if d and dateutils.getday(d) == dateutils.getday() then
        return {c = "activity",m = "receivefuka", data = {errcode = 10004, errmsg = "今日已领取"}}
    end
    fukamodel:receive(fukaid)
    local rewards = cfg.daily_reward
    for i,v in ipairs(rewards) do
        bagmodel:incrBagA(v.key, v.value)
    end
    return {c = "activity",m = "receivefuka", data = {errcode = 0, errmsg = "", data = { } }}
end

function activity.loadtimelimitactivity(cmd)

    local cnf = skynet.call(".activityd", "lua", "loadallconfig", usermodel.serverid)
    local activitys = {}
    for i,v in ipairs(cnf) do
        if v._id == 1 and v.status == 1 then
            if not heishimodel._init or heishimodel._init ~= dateutils.getday() then
                local data = skynet.call(".activityd", "lua", "loadheishi", UID)
                heishimodel:init(data, v.start_time, v.end_time)
                heishimodel._init = dateutils.getday()
            end
            activitys[tostring(1)] = heishimodel:serialize()
        else
            heishimodel._init = nil
        end
        if v._id == 2 and v.status == 1 then
            if not baoxiangmodel._init or baoxiangmodel._init ~= dateutils.getday() then
                local t1, t2, t3, t4 = skynet.call(".activityd", "lua", "loadbaoxiang", UID)
                baoxiangmodel:init(t1, t2, t3, t4, v.start_time, v.end_time)
                baoxiangmodel._init = dateutils.getday()
            end
            activitys[tostring(2)] = baoxiangmodel:serialize()
        else
            baoxiangmodel._init = nil
        end
        if v._id == 3 and v.status == 1 then
            if not zhaomumodel._init or zhaomumodel._init ~= dateutils.getday() then
                local t1, t2, t3, t4 = skynet.call(".activityd", "lua", "loadzhaomu", UID)
                zhaomumodel:init(t1, t2, t3, t4, v.start_time, v.end_time)
                zhaomumodel._init = dateutils.getday()
            end
            activitys[tostring(3)] = zhaomumodel:serialize()
        else
            zhaomumodel._init = nil
        end
        if v._id == 4 and v.status == 1 then
            if not duanwumodel._init or duanwumodel._init ~= dateutils.getday() then
                local t1, t2, t3, t4, t5 = skynet.call(".activityd", "lua", "loadduanwu", UID)
                duanwumodel:init(t1, t2, t3, t4, t5, v.start_time, v.end_time)
                duanwumodel._init = dateutils.getday()
            end
            activitys[tostring(4)] = duanwumodel:serialize()
        else
            duanwumodel._init = nil
        end
    end
    return {c = "activity",m = "loadtimelimitactivity", data = {errcode = 0, errmsg = "", data = { config = table.array(cnf), activitys = activitys} }}
end


function activity.buyheishi(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "activity",m = "buyheishi", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end

    if not heishimodel._init then
        return {c = "activity",m = "loadheishi", data = {errcode = 10010, errmsg = "请求数据异常, 请稍后再试"}}
    end

    id = checkint(id)
    local cfg = activitylogic.getheishiconfbyid(id)
    assert(cfg ~= nil)
    if cfg.price > 0 then
        if bagmodel.gold < cfg.price then
            return {c = "activity",m = "buyheishi", data = {errcode = 10002, errmsg = "金砖不足"}}
        end
    end
    if not heishimodel:checkbuy(id) then
        return {c = "activity",m = "buyheishi", data = {errcode = 10003, errmsg = "购买数量超上限"}}
    end
    if cfg.price > 0 then
        bagmodel:decrBagA("gold", cfg.price)
    end
    heishimodel:buy(id, 1)
    local rewards = cfg.rewards
    local param = {}
    for i,v in ipairs(rewards) do
        param[v.key] = param[v.key] or 0
        param[v.key] = param[v.key] + v.value
    end
    bagmodel:incrBagB(param)
    return {c = "activity",m = "buyheishi", data = {errcode = 0, errmsg = "", data = {}}}
end

function activity.buybaoxiang(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "activity",m = "buybaoxiang", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end

    if not baoxiangmodel._init then
        return {c = "activity",m = "buybaoxiang", data = {errcode = 10010, errmsg = "请求数据异常, 请稍后再试"}}
    end

    id = checkint(id)
    local cfg = activitylogic.getbaoxiangshangchengconfbyid(id)
    assert(cfg ~= nil)
    local order_no = skynet.call(".id_service", "lua", "getuuid")
    local log = {
        uid=UID,
        openid=usermodel.openid,
        regionid=usermodel.regionid,
        serverid=usermodel.serverid,
        order_no=order_no,
        description = "购买"..cfg.name,
        prepay_id="",
        payment=cfg.price,
        pay_status=0,
        pay_type="buybaoxiang",
        recharge_id=tostring(id),
        recharge_conf=cfg,
        complete=0,
        completed_at="",
        created_at=dateutils.get_datetime()
    }
    local ok = mongohelper.insert(settings.recharge_mongodb_key.tname, settings.recharge_mongodb_key.cname, log)
    if not ok then
        return {c = "activity",m = "buybaoxiang",data = {errcode = 10003, errmsg = "购买宝箱失败, 请稍后再试!", data = { } }}
    end
    return {c = "activity",m = "buybaoxiang", data = {errcode = 0, errmsg = "", data = { order = log}}}
end

function activity.recevicebaoxiangshangcheng(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "activity",m = "recevicebaoxiangshangcheng", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end

    if not baoxiangmodel._init then
        return {c = "activity",m = "recevicebaoxiangshangcheng", data = {errcode = 10010, errmsg = "请求数据异常, 请稍后再试"}}
    end

    id = checkint(id)
    local cfg = activitylogic.getbaoxiangshangchengconfbyid(id)
    assert(cfg ~= nil)

    if not baoxiangmodel:checkreceivebuy(id) then
        return {c = "activity",m = "recevicebaoxiangshangcheng", data = {errcode = 10003, errmsg = "领取失败,请稍后再试"}}
    end

    baoxiangmodel:receivebuy(id)

    local rewards = cfg.rewards
    local param = {}
    for i,v in ipairs(rewards) do
        param[v.key] = param[v.key] or 0
        param[v.key] = param[v.key] + v.value
    end
    bagmodel:incrBagB(param)
    return {c = "activity",m = "recevicebaoxiangshangcheng", data = {errcode = 0, errmsg = "", data = {}}}
end

function activity.receivebaoxiang(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "activity",m = "receivebaoxiang", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end

    if not baoxiangmodel._init then
        return {c = "activity",m = "receivebaoxiang", data = {errcode = 10010, errmsg = "请求数据异常, 请稍后再试"}}
    end

    id = checkint(id)
    local cfg = activitylogic.getbaoxiangconfbyid(id)
    if not baoxiangmodel:checkreceive(id) then
        return {c = "activity",m = "receivebaoxiang", data = {errcode = 10003, errmsg = "领取失败,请稍后再试"}}
    end
    baoxiangmodel:receive(id)
    local rewards = cfg.rewards
    local param = {}
    for i,v in ipairs(rewards) do
        param[v.key] = param[v.key] or 0
        param[v.key] = param[v.key] + v.value
    end
    bagmodel:incrBagB(param)
    return {c = "activity",m = "receivebaoxiang", data = {errcode = 0, errmsg = "", data = {}}}
end

function activity.buyzhaomu(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "activity",m = "buyzhaomu", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end

    if not zhaomumodel._init then
        return {c = "activity",m = "buyzhaomu", data = {errcode = 10010, errmsg = "请求数据异常, 请稍后再试"}}
    end

    id = checkint(id)
    local cfg = activitylogic.getzhaomushangchengconfbyid(id)
    assert(cfg ~= nil)
    local order_no = skynet.call(".id_service", "lua", "getuuid")
    local log = {
        uid=UID,
        openid=usermodel.openid,
        serverid=usermodel.serverid,
        order_no=order_no,
        description = "购买"..cfg.name,
        prepay_id="",
        payment=cfg.price,
        pay_status=0,
        pay_type="buyzhaomu",
        recharge_id=tostring(id),
        recharge_conf=cfg,
        complete=0,
        completed_at="",
        created_at=dateutils.get_datetime()
    }
    local ok = mongohelper.insert(settings.recharge_mongodb_key.tname, settings.recharge_mongodb_key.cname, log)
    if not ok then
        return {c = "activity",m = "buyzhaomu",data = {errcode = 10003, errmsg = "购买宝箱失败, 请稍后再试!", data = { } }}
    end
    return {c = "activity",m = "buyzhaomu", data = {errcode = 0, errmsg = "", data = { order = log }}}
end


function activity.recevicezhaomushangcheng(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "activity",m = "recevicezhaomushangcheng", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end

    if not zhaomumodel._init then
        return {c = "activity",m = "recevicezhaomushangcheng", data = {errcode = 10010, errmsg = "请求数据异常, 请稍后再试"}}
    end

    id = checkint(id)
    local cfg = activitylogic.getzhaomushangchengconfbyid(id)
    assert(cfg ~= nil)

    if not zhaomumodel:checkreceivebuy(id) then
        return {c = "activity",m = "recevicezhaomushangcheng", data = {errcode = 10003, errmsg = "领取失败,请稍后再试"}}
    end

    zhaomumodel:receivebuy(id)

    local rewards = cfg.rewards
    local param = {}
    for i,v in ipairs(rewards) do
        param[v.key] = param[v.key] or 0
        param[v.key] = param[v.key] + v.value
    end
    bagmodel:incrBagB(param)

    return {c = "activity",m = "recevicezhaomushangcheng", data = {errcode = 0, errmsg = "", data = {}}}
end

function activity.receivezhaomu(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "activity",m = "receivezhaomu", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end

    if not zhaomumodel._init then
        return {c = "activity",m = "receivezhaomu", data = {errcode = 10010, errmsg = "请求数据异常, 请稍后再试"}}
    end

    id = checkint(id)
    local cfg = activitylogic.getzhaomuconfbyid(id)
    if not zhaomumodel:checkreceive(id) then
        return {c = "activity",m = "receivezhaomu", data = {errcode = 10003, errmsg = "领取失败,请稍后再试"}}
    end

    zhaomumodel:receive(id)

    local rewards = cfg.rewards
    local param = {}
    for i,v in ipairs(rewards) do
        param[v.key] = param[v.key] or 0
        param[v.key] = param[v.key] + v.value
    end
    bagmodel:incrBagB(param)
    return {c = "activity",m = "receivezhaomu", data = {errcode = 0, errmsg = "", data = {}}}
end

function activity.loadinvite(cmd)
    --获取用户签到信息
    local num, result = skynet.call(".invited", "lua", "getinfo", UID)
    invitemodel:init(num, result)
    return {c = "activity",m = "loadinvite",data = {errcode = 0,data = { invite = invitemodel:serialize()}}}

end


function activity.receiveinvite(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "activity",m = "receiveinvite", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end

    if not invitemodel:checkreceive(id) then
        return {c = "activity",m = "receiveinvite", data = {errcode = 10002, errmsg = "领取要求未达到"}}
    end

    local rewards = inviteconf[id].rewards
    local param = {}
    for i,v in ipairs(rewards) do
        param[v.key] = param[v.key] or 0
        param[v.key] = param[v.key] + v.value
    end
    bagmodel:incrBagB(param)

    invitemodel:receive(id)
    return {c = "activity",m = "receiveinvite",data = {errcode = 0,data = { }}}

end


function activity.buyduanwu(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "activity",m = "buyduanwu", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end

    if not duanwumodel._init then
        return {c = "activity",m = "buyduanwu", data = {errcode = 10010, errmsg = "请求数据异常, 请稍后再试"}}
    end

    if not duanwumodel:checkbuy(id) then
        return {c = "activity",m = "buyduanwu", data = {errcode = 10002, errmsg = "禁止购买"}}
    end

    id = checkint(id)
    local cfg = activitylogic.getzhaomushangchengconfbyid(id)
    assert(cfg ~= nil)
    local order_no = skynet.call(".id_service", "lua", "getuuid")
    local log = {
        uid=UID,
        openid=usermodel.openid,
        serverid=usermodel.serverid,
        order_no=order_no,
        description = "购买"..cfg.name,
        prepay_id="",
        payment=cfg.price,
        pay_status=0,
        pay_type="buyduanwu",
        recharge_id=tostring(id),
        recharge_conf=cfg,
        complete=0,
        completed_at="",
        created_at=dateutils.get_datetime()
    }
    local ok = mongohelper.insert(settings.recharge_mongodb_key.tname, settings.recharge_mongodb_key.cname, log)
    if not ok then
        return {c = "activity",m = "buyduanwu",data = {errcode = 10003, errmsg = "购买宝箱失败, 请稍后再试!", data = { } }}
    end
    return {c = "activity",m = "buyduanwu",data = {errcode = 0,data = { order = log }}}

end


function activity.receiveduanwuxiangou(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "activity",m = "receiveduanwuxiangou", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end

    if not duanwumodel._init then
        return {c = "activity",m = "receiveduanwuxiangou", data = {errcode = 10010, errmsg = "请求数据异常, 请稍后再试"}}
    end

    id = checkint(id)
    local cfg = activitylogic.getduanwuxiangouconfbyid(id)
    assert(cfg ~= nil)

    if not duanwumodel:checkreceivebuy(id) then
        return {c = "activity",m = "receiveduanwuxiangou", data = {errcode = 10003, errmsg = "领取失败,请稍后再试"}}
    end

    duanwumodel:receivebuy(id)

    local rewards = cfg.reward
    local param = {}
    for i,v in ipairs(rewards) do
        param[v.key] = param[v.key] or 0
        param[v.key] = param[v.key] + v.value
    end

    bagmodel:incrBagB(param)

    return {c = "activity",m = "receiveduanwuxiangou", data = {errcode = 0, errmsg = "", data = {}}}
end

function activity.receiveduanwuleichong(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "activity",m = "receiveduanwuleichong", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end

    if not duanwumodel._init then
        return {c = "activity",m = "receiveduanwuleichong", data = {errcode = 10010, errmsg = "请求数据异常, 请稍后再试"}}
    end

    id = checkint(id)
    local cfg = activitylogic.getduanwuleichongconfbyid(id)
    assert(cfg ~= nil)

    if not duanwumodel:checkreceive(id) then
        return {c = "activity",m = "receiveduanwuleichong", data = {errcode = 10003, errmsg = "领取失败,请稍后再试"}}
    end

    duanwumodel:receive(id)

    local rewards = cfg.reward
    local param = {}
    for i,v in ipairs(rewards) do
        param[v.key] = param[v.key] or 0
        param[v.key] = param[v.key] + v.value
    end
    bagmodel:incrBagB(param)

    return {c = "activity",m = "receiveduanwuleichong", data = {errcode = 0, errmsg = "", data = {}}}
end

function activity.duihuanduanwu(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "activity",m = "duihuanduanwu", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end

    if not duanwumodel._init then
        return {c = "activity",m = "duihuanduanwu", data = {errcode = 10010, errmsg = "请求数据异常, 请稍后再试"}}
    end

    id = checkint(id)
    local cfg = activitylogic.getduanwuduihuanconfbyid(id)
    assert(cfg ~= nil)

    if not duanwumodel:checkduihuan(id) then
        return {c = "activity",m = "duihuanduanwu", data = {errcode = 10003, errmsg = "兑换失败,请稍后再试"}}
    end

    local price = cfg.price

    bagmodel:decrBagA("zongzi_lv3", price)

    duanwumodel:duihuan(id)

    local rewards = cfg.goods
    local param = {}
    for i,v in ipairs(rewards) do
        if v.tp == "qi" then
            local art = {}
            art.artid = v.id
            artifactmodel:add(art)
            v.id = artifactmodel:getid(v.id, 1)
        else
            param[v.id] = param[v.id] or 0
            param[v.id] = param[v.id] + v.count
        end
    end

    bagmodel:incrBagB(param)

    return {c = "activity",m = "duihuanduanwu", data = {errcode = 0, errmsg = "", data = {rewards = rewards}}}
end

return activity
