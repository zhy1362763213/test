local skynet        = require "skynet"
local netpack       = require "websocketnetpack"
local msgutils      = require "msgutils"
local cjson         = require "cjson"
local usermodel     = require "usermodel"
local bagmodel      = require "bagmodel"
local heromodel     = require "heromodel"
local artifactmodel = require "artifactmodel"
local coingetmodel = require "coingetmodel"
local achievementmodel     = require "achievementmodel"
local signin7model  = require "signin7model"
local taskmodel     = require "taskmodel"
local huobamodel    = require "huobamodel"
local baoxiangmodel = require "baoxiangmodel"
local zhaomumodel   = require "zhaomumodel"
local friendmodel   = require "friendmodel"
local boxlogic      = require "boxlogic"
local settings      = require "settings"
local bson          = require "bson"
local mqhelper      = require "mqhelper"
local mongohelper   = require "mongohelper"
local dateutils     = require "dateutils"
local signinlogic   = require "signinlogic"
local rechargeconf  = require "rechargeconf"
local lordlogic     = require "lordlogic"
local herologic     = require "herologic"
local coingetlogic  = require "coingetlogic"
local recruitlogic  = require "recruitlogic"
local booklogic     = require "booklogic"
local libaologic    = require "libaologic"
local achievementlogic     = require "achievementlogic"
local blackmarketmodel = require "blackmarketmodel"
local duanwumodel   = require "duanwumodel"
local guajimodel    = require "guajimodel"
local vipmodel      = require "vipmodel"
local levellogic    = require "levellogic"
local goldlogic     = require "goldlogic"
local guajilogic    = require "guajilogic"
local viplogic      = require "viplogic"
local blackmarketlogic = require "blackmarketlogic"

local user = {}

function user.ping(cmd)
    return {c = "user",m = "pong",data = {}}
end


function user.loaduser(cmd)
    if not usermodel._init or usermodel._init ~= dateutils.getday() then
        local user = skynet.call(".usercenterd", "lua", "loaduser", UID)
        assert(user~=nil , "load user fail")
        usermodel:init(user)
        --获取英雄列表
        local heros = skynet.call(".usercenterd", "lua", "loadhero", UID)
        heromodel:init(usermodel, heros)

        local arts = skynet.call(".usercenterd", "lua", "loadartifact", UID)
        artifactmodel:init(arts)

        local bag = skynet.call(".usercenterd", "lua", "loadbag", UID)
        bagmodel:init(usermodel, bag)
        usermodel._init = dateutils.getday()
    end
    local userinfo = usermodel:serialize()
    --TODO:计算战斗力
    return {
        c = "user",
        m = "loaduser",
        data = {
            errcode = 0,
            data = { user = userinfo }
        }
    }
end

function user.loadbag(cmd)
    return {
        c = "user",
        m = "loadbag",
        data = {
            errcode = 0,
            data = { bag = bagmodel:serialize() }
        }
    }
end

--获取我的武将
function user.loadallhero(cmd)
    return {c = "user",m = "loadallhero",data = {errcode = 0,data = { heros = heromodel:serialize()}}}
end

function user.loadguaji(cmd)
    if not guajimodel._init or guajimodel._init ~= dateutils.getday() then
        local info = skynet.call(".guajid", "lua", "getinfo", UID)
        local receives = skynet.call(".guajid", "lua", "getreceiveinfo", UID)
        guajimodel:init(info, receives)
        guajimodel._init = dateutils.getday()
    end
    return {c = "user",m = "loadguaji",data = {errcode = 0,data = { guaji = guajimodel:serialize() }}}
end


function user.loadsignin7(cmd)
    if not signin7model._init or signin7model._init ~= dateutils.getday() then
        local res = skynet.call(".signind", "lua", "getsignin7", UID)
        signin7model:init(res)
        signin7model._init = dateutils.getday()
    end
    return {c = "user",m = "loadsignin7",data = {errcode = 0,data = { signin=signin7model:serialize() }}}
end

--七日签到
function user.signin7(cmd)
    if signin7model:checksignin() == true then
        return {c = "user",m = "signin7",data = {errcode = 10000, errmsg = "请勿重复签到", data = { }}}
    end
    signin7model:signin()
    local day = signin7model:getsignday()
    --天数获取奖励
    local cfg = signinlogic.getsignin7conf(day)
    assert(cfg~= nil, "配置获取失败")
    local param = {}
    local rewards = {}
    local reward = cfg.rewards
    for i,v in ipairs(reward) do
        param[v.key] = param[v.key] or 0
        param[v.key] = param[v.key] + v.value
        table.insert(rewards, {tp="item", id=v.key, count=v.value})
    end
    bagmodel:incrBagB(param)
    return {c = "user",m = "signin7",data = {errcode = 0,data = { signin=signin7model:serialize() }}}
end

--获取点金
function user.loadcoinget(cmd)
    --获取点金次数
    if not coingetmodel._init or coingetmodel._init ~= dateutils.getday() then
        local num = skynet.call(".coingetd", "lua", "get", UID)
        coingetmodel:init(usermodel, num)
        coingetmodel._init = dateutils.getday()
    end
    return {c = "user",m = "loadcoinget",data = {errcode = 0,data = { total = coingetmodel:coingettotalnum(), num=coingetmodel:coingetnum()}}}
end

--获取黑市
function user.loadblackmarket(cmd)
    if not blackmarketmodel._init or blackmarketmodel._init ~= dateutils.getday() then
        local num, res1, res2 = skynet.call(".blackmarketd", "lua", "loaddiscount", UID)
        blackmarketmodel:init(num, res1, res2)
        blackmarketmodel._init = dateutils.getday()
    end
    return {c = "user",m = "loadblackmarket",data = {errcode = 0,data = { blackmarket = blackmarketmodel:serialize()}}}
end


--获取成就
function user.loadachievement(cmd)
    if not achievementmodel._init or achievementmodel._init ~= dateutils.getday() then
        local d1, d2 = skynet.call(".achievementd", "lua", "get", UID)
        achievementmodel:init(d1, d2)
        achievementmodel._init = dateutils.getday()
    end
    return {c = "user",m = "loadachievement",data = {errcode = 0, errmsg = "", data = {achievement = achievementmodel:serialize()}}}
end

--领取成就奖励
function user.receiveachievement(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "user",m = "receiveachievement",data = {errcode = 10001, errmsg = "请求异常,请稍后再试"}}
    end

    id = checkint(id)

    if not achievementmodel:checknum(id) then
        return {c = "user",m = "receiveachievement",data = {errcode = 10002, errmsg = "完成次数未达标"}}
    end

    if achievementmodel:checkreceive(id) == 1 then
        return {c = "user",m = "receiveachievement",data = {errcode = 10003, errmsg = "请勿重复领取"}}
    end

    local cnf = achievementlogic.gettaskconfbyid(id)
    assert(cnf ~= nil, "配置获取失败")
    local rews = cnf.rewards
    local param = {}
    local rewards = {}
    for i,v in ipairs(rews) do
        param[v.key] = param[v.key] or 0
        param[v.key] = param[v.key] + v.value
        table.insert(rewards, {tp="item", id=v.key, count=v.value})
    end
    bagmodel:incrBagB(param)
    achievementmodel:receive(id)
    return {c = "user",m = "receiveachievement",data = {errcode = 0, errmsg = "", data = { rewards = rewards, achievement = achievementmodel:serialize()}}}
end

--获取每日任务
function user.loadtask(cmd)
    if not taskmodel._init or taskmodel._init ~= dateutils.getday() then
        local ok , result = pcall(skynet.call, ".taskd", "lua", "loadtask", UID)
        assert(ok, "加载任务失败")
        taskmodel:init(result)
        taskmodel._init = dateutils.getday()
    end
    return {c = "user",m = "loadtask",data = {errcode = 0, errmsg = "", data = {task = taskmodel:serialize()}}}
end

--获取vip
function user.loadvip(cmd)
    if not vipmodel._init or vipmodel._init ~= dateutils.getday() then
        local result = skynet.call(".vipd", "lua", "get", UID)
        vipmodel:init(result)
        vipmodel._init = dateutils.getday()
    end
    return {c = "user",m = "loadvip",data = {errcode = 0, errmsg = "", data = { vip = vipmodel:serialize() }}}
end

function user.loadhuoba(cmd)
    if not huobamodel._init or huobamodel._init ~= dateutils.getday() then
        local result = skynet.call(".huobad", "lua", "loadhuoba", UID)
        -- DEBUG("loadhuoba result = ", DUMP(result))
        huobamodel:init(usermodel, result)
        huobamodel._init = dateutils.getday()
    end
    return {c = "user",m = "loadhuoba",data = {errcode = 0, errmsg = "", data = { huoba = huobamodel:serialize() }}}
end

--获取百服消息
function user.loadbaifumsg(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "user",m = "loadbaifumsg",data = {errcode = 10001,errmsg = "请求异常, 请稍后再试!", data = { }}}
    end
    id = checkint(id)
    local msgs = skynet.call(".msgcenterd", "lua", "loadbaifumsg", usermodel:getBaiFuServer(), id)
    if #msgs > 0 then
        local lastid = msgs[#msgs].id
        msgmodel.baifuindex = lastid
    end
    return {c = "user",m = "loadbaifumsg", data = {errcode = 0, errmsg = "", data = { msgs = table.array(msgs)}}}
end

--加入消息中心
function user.join_msg_center(cmd)
    if not JOIN_SUCCESS then
        pcall(skynet.call, skynet.self(), "lua", "join_msg_center")
    end
    return {c = "user",m = "join_msg_center",data = {errcode = 0, errmsg = "", data = {}}}
end

--领取任务
function user.receivetask(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "user",m = "receivetask",data = {errcode = 10001, errmsg = "请求异常,请稍后再试"}}
    end
    id = checkint(id)

    if not taskmodel:checkcompletetask(id) then
        return {c = "user",m = "receivetask",data = {errcode = 10002, errmsg = "任务未完成"}}
    end

    if taskmodel:checkreceivetask(id) then
        return {c = "user",m = "receivetask",data = {errcode = 10003, errmsg = "请勿重复领取"}}
    end
    taskmodel:receivetask(id)
    return {c = "user",m = "receivetask",data = {errcode = 0, errmsg = "", data = {}}}
end

--领取日活跃
function user.receivedailytask(cmd)
    if not taskmodel:checkreceivedailyact() then
        return {c = "user",m = "receivedailytask",data = {errcode = 10001, errmsg = "未达到领取条件"}}
    end
    local rewards = taskmodel:receivedailyact()
    local param = {}
    for i,v in ipairs(rewards) do
        param[v.key] = param[v.key] or 0
        param[v.key] = param[v.key] + v.value
    end
    bagmodel:incrBagB(param)
    return {c = "user",m = "receivedailytask",data = {errcode = 0, errmsg = "", data = {}}}
end

--领取周活跃
function user.receiveweeklytask(cmd)
    if not taskmodel:checkreceiveweeklyact() then
        return {c = "user",m = "receiveweeklytask",data = {errcode = 10001, errmsg = "未达到领取条件"}}
    end
    local rewards = taskmodel:receiveweeklyact()
    local param = {}
    for i,v in ipairs(rewards) do
        param[v.key] = param[v.key] or 0
        param[v.key] = param[v.key] + v.value
    end
    bagmodel:incrBagB(param)
    return {c = "user",m = "receiveweeklytask",data = {errcode = 0, errmsg = "", data = {}}}
end


--使用火把
function user.usehuoba(cmd)
    local lv = cmd.data.lv
    if not lv then
        return {c = "user",m = "usehuoba",data = {errcode = 10001, errmsg = "请求异常,请稍后再试"}}
    end
    lv = math.floor(lv)
    local n = bagmodel:gethuobanum(lv)
    if n < 1 then
        return {c = "user",m = "usehuoba",data = {errcode = 10002, errmsg = "资源不足",data = { } }}
    end
    if not huobamodel._init then
        return {c = "user",m = "usehuoba",data = {errcode = 10003, errmsg = "请求异常,请先初始化",data = { } }}
    end
    huobamodel:userhuoba(lv)
    bagmodel:decrBagA("huoba_lv"..lv, 1)
    return {c = "user",m = "usehuoba",data = {errcode = 0, errmsg = "",data = { huoba_lv = usermodel.huoba_lv, huoba_end_time = usermodel.huoba_end_time } }}
end

--邀请好友加火把
function user.incrhuoba(cmd)

    local tp = cmd.data.tp

    if not tp then
        return {c = "user",m = "incrhuoba",data = {errcode = 10001,errmsg = "请求异常,请稍后再试", data = { }}}
    end
    if tp == "share" then
        huobamodel:share()
        taskmodel:addtasknum(2, 1)
    elseif tp == "adv" then
        huobamodel:lookadv()
    else
        assert(false, "不应该走到这~~~")
    end
    bagmodel:incrBagA("huoba_lv1", 1)
    return {c = "user",m = "incrhuoba",data = {errcode = 0, errmsg = "", data={ huoba = huobamodel:serialize()}}}
end


--分享成功
function user.share(cmd)
    taskmodel:addtasknum(2, 1)
    return {c = "user",m = "share",data = {errcode = 0, errmsg = "", data={}}}
end

--点金
function user.coinget(cmd)
    local count = cmd.data.count
    if not count then
        return {c = "user",m = "coinget",data = {errcode = 10001, errmsg = "点金次数错误"}}
    end
    count = math.floor(count)
    coingetmodel:reset() --刷新点金
    local num = coingetmodel.num
    if num >= coingetmodel:coingettotalnum() then
        return {c = "user",m = "coinget",data = {errcode = 10002, errmsg = "点金次数已达上限"}}
    end

    local max_level = usermodel.max_level

    if max_level < 100 then
        return {c = "user",m = "coinget",data = {errcode = 10003, errmsg = "关卡等级错误"}}
    end

    if num >= 3 then
        local coingetcfg = coingetlogic.getconf(usermodel:getviplv())
        local gold = coingetcfg.diamondspend * count
        if gold > bagmodel.gold then
            return {c = "user",m = "coinget",data = {errcode = 10003, errmsg = "金砖数量不足"}}
        end
        -- DEBUG("coinget gold = ", gold)
        bagmodel:decrBagA("gold", gold)
        bagmodel:save2log({gold=-gold}, "点金成功")
    end
    math.randomseed(tostring(os.time()):reverse():sub(1, 6))
    local params = {}
    params.coin = 0
    local rewards = {}
    local coin = coingetlogic.getcoingetnum(max_level)
    for i=1, count do
        local t = {1, 1.5, 2, 2.5, 3} --点金倍数配置
        local r = math.random(1, 5)
        local times = t[r]
        local add_coin = coin * times
        params.coin = params.coin + add_coin
        table.insert(rewards, {tp="item", id="coin", count=add_coin, times=times,})
    end
    bagmodel:incrBagB(params)
    bagmodel:save2log(params, "点金成功")
    --TODO 点金成功
    coingetmodel:coinget(count)
    usermodel:addcoingetnum(count)
    taskmodel:addtasknum(6, count)
    achievementmodel:emit("coinget", achievementmodel)
    return {c = "user",m = "coinget",data = {errcode = 0, errmsg = "", data={rewards=rewards}}}
end


--升星
function user.starup(cmd)

    local heroid = cmd.data.heroid
    if not heroid then
        return {c = "user",m = "starup",data = {errcode = 10001,errmsg = "请求异常,请稍后再试", data = { }}}
    end
    heroid = checkint(heroid)
    --没有武将 则第一次合成
    if not heromodel:checkhero(heroid) then
        local color = herologic.getcolorbyheroid(heroid)
        local num = herologic.getconf(heroid).cardnumber
        local cardnum = bagmodel:getnum("card_"..heroid)
        if cardnum < num then
            return {c = "user",m = "starup",data = {errcode = 10002,errmsg = "升级失败!", data = { }}}
        end
        local hero = {}
        hero.id = UID*1000+heroid
        hero.uid = UID
        hero.serverid = usermodel.serverid
        hero.heroid = heroid
        heromodel:add(hero)
        bagmodel:decrBagA("card_"..heroid, num)
    else
        local hero = heromodel:gethero(heroid)
        local star = hero.star
        -- DEBUG("starup star = ", star)
        local color = herologic.getcolorbyheroid(heroid)
        local num = herologic.getusecardnum(star+1)
        -- DEBUG("starup star num = ", num)
        local cardnum = bagmodel:getnum("card_"..heroid)
        -- DEBUG("starup star cardnum = ", cardnum)
        if cardnum < num then
            return {c = "user",m = "starup",data = {errcode = 10002,errmsg = "碎片不足，无法升星!", data = { }}}
        end
        heromodel:starup(heroid)
        bagmodel:decrBagA("card_"..heroid, num)
        achievementmodel:emit("starup", achievementmodel)
    end
    return {c = "user",m = "starup",data = {errcode = 0,data = {hero=heromodel:serializebyheroid(heroid)}}}
end

--收集徽星
function user.collectemblemstar(cmd)
    local heroid = cmd.data.heroid
    if not heroid then
        return {c = "user",m = "collectemblemstar",data = {errcode = 10001,errmsg = "请求异常,请稍后再试!", data = { }}}
    end
    local hero = heromodel:gethero(heroid)
    if not hero then
        return {c = "user",m = "collectemblemstar",data = {errcode = 10002,errmsg = "升级条件不满足!", data = { }}}
    end
    local c = hero.star + 1
    if hero.collect_emblemstar >= c then
        return {c = "user",m = "collectemblemstar",data = {errcode = 10002,errmsg = "升级条件不满足!", data = { }}}
    end
    heromodel:collectemblemstar(heroid)
    local n = heromodel:getcollectemblemstar(heroid)
    local star = booklogic.getemblemstarnum(heroid, n)
    assert(star ~= nil, "获取徽星数量失败")
    usermodel:incremblemstar(star)
    --TODO:计算是否获得奖励
    return {c = "user",m = "collectemblemstar",data = {errcode = 0,data = {}}}
end


--领取徽星奖励
function user.receiveremblemstar(cmd)
    if not usermodel:canreceiveremblemstar() then
        return {c = "user",m = "receiveremblemstar",data = {errcode = 10001, errmsg = "积分不足，不能领取",data = { } }}
    end
    --奖励
    local conf = booklogic.getcurbookstage(usermodel.emblemstarid + 1)
    local rewards = conf.reward_items
    assert(#rewards > 0, "奖励获取失败")
    local param = {}
    local rews = {}
    for i,v in ipairs(rewards) do
        param[v.key] = param[v.key] or 0
        param[v.key] = param[v.key] + v.value
        table.insert(rews, {tp="item", id=v.key, count=v.value})
    end
    usermodel:receiveremblemstar()
    bagmodel:incrBagB(param)
    bagmodel:save2log(param, "领取图鉴奖励")
    return {c = "user",m = "receiveremblemstar",data = {errcode = 0,data = {emblemstarid=usermodel.emblemstarid, rewards = table.array(rews)}}}
end

--升级
function user.lvup(cmd)
    local tp = cmd.data.tp or "lord"
    local lv = cmd.data.lv
    if not tp or not lv then
        return {c = "user",m = "lvup",data = {errcode = 10001, errmsg = "系统繁忙,请稍后再试!"}}
    end
    if tp == "lord" then --主公升级
        local curlv = usermodel.lv
        if curlv >= 6000 then
            return {c = "user",m = "lvup",data = {errcode = 10002, errmsg = "已升级到最高等级"}}
        end
        local r = lordlogic.neetstageup(curlv, lv)
        if r then
            return {c = "user",m = "lvup",data = {errcode = 10002, errmsg = "升级失败,请勿跨阶"}}
        end

        local orderconf = lordlogic.getlordorderconf(usermodel.stage)
        assert(orderconf~=nil, "进阶配置不存在！")
        if curlv == orderconf.lordlv then
            return {c = "user",m = "lvup",data = {errcode = 10002, errmsg = "请先进阶"}}
        end

        local newlv = curlv + lv
        local speed = lordlogic.callvupspend(curlv, newlv-1)
        local cur_coin = bagmodel.coin
        if cur_coin < speed then
            return {c = "user",m = "lvup",data = {errcode = 10002, errmsg = "金币不足!"}}
        end
        bagmodel:decrBagA("coin", speed)
        usermodel:lvup(lv)
        achievementmodel:emit("lordlvup", achievementmodel)
    else
        local heroid = cmd.data.heroid -- 武将对应的id
        local hero = heromodel:gethero(heroid)
        assert(hero~=nil)
        -- assert(hero.pos > 0, "未上阵")
        local curlv = hero.lv
        if curlv >= 6000 then
            return {c = "user",m = "lvup",data = {errcode = 10002, errmsg = "已升级到最高等级"}}
        end
        local orderconf = herologic.getheroorderconf(hero.stage)

        if curlv == orderconf.hero_lv then
            return {c = "user",m = "lvup",data = {errcode = 10002, errmsg = "请先进阶"}}
        end

        local newlv = curlv + lv --2830 + 5

        if curlv <= orderconf.hero_lv and newlv > orderconf.hero_lv then
            return {c = "user",m = "lvup",data = {errcode = 10005, errmsg = "请先完成进阶"}}
        end

        if newlv > orderconf.hero_lv then
            return {c = "user",m = "lvup",data = {errcode = 10006, errmsg = "请先武将进阶"}}
        end

        if newlv > usermodel.lv then
            return {c = "user",m = "lvup",data = {errcode = 10003, errmsg = "武将等级不能大于主公等级"}}
        end

        local speed = herologic.callvupspend(curlv, newlv-1)
        local cur_coin = bagmodel.coin
        if cur_coin < speed then
            return {c = "user",m = "lvup",data = {errcode = 10004, errmsg = "金币不足!"}}
        end
        bagmodel:decrBagA("coin", speed)
        heromodel:lvup(heroid, lv)
        achievementmodel:emit("herolvup", achievementmodel)
    end

    return {
        c = "user",
        m = "lvup",
        data = {
            errcode = 0,
            data = {  }
        }
    }
end

--进阶
function user.stageup(cmd)
    local tp = cmd.data.tp or "lord"
    if tp == "lord" then --主公进阶
        local cur_stage = usermodel.stage
        local conf = lordlogic.getlordorderconf(cur_stage)
        assert(conf~=nil, "配置不存在！")
        if usermodel.lv ~= conf.lord_lv then
            return {c = "user",m = "stageup",data = {errcode = 10002, errmsg = "进阶等级不符"}}
        end

        local order_spend = conf.order_spend
        local jinjieshi = bagmodel.jinjieshi
        if jinjieshi < order_spend then
            return {c = "user",m = "stageup",data = {errcode = 10002, errmsg = "材料不足!"}}
        end
        bagmodel:decrBagA("jinjieshi", order_spend)
        usermodel:stageup()
        bagmodel:save2log({jinjieshi=-order_spend}, "主公进阶")
    else
        local heroid = cmd.data.heroid -- 武将对应的id
        local hero = heromodel:getherobyheroid(heroid)
        assert(hero~=nil)
        -- assert(hero.pos > 0, "未上阵")
        local conf = herologic.getheroorderconf(hero.stage)
        assert(conf~=nil, "配置不存在！")

        DEBUG("hero.lv = ", hero.lv)
        DEBUG("conf.hero_lv = ", conf.hero_lv)

        if hero.lv ~= conf.hero_lv then
            return {c = "user",m = "stageup",data = {errcode = 10002, errmsg = "进阶等级不符"}}
        end

        local order_spend = conf.order_spend
        local jinjieshi = bagmodel.jinjieshi
        if jinjieshi < order_spend then
            return {c = "user",m = "stageup",data = {errcode = 10002, errmsg = "材料不足!"}}
        end

        bagmodel:decrBagA("jinjieshi", order_spend)
        heromodel:stageup(heroid)
        bagmodel:save2log({jinjieshi=-order_spend}, "武将进阶")
    end

    return {c = "user",m = "stageup",data = {errcode = 0,data = { }}}
end

--上阵
function user.confirmup(cmd)
    local heroid = cmd.data.heroid
    if not heroid then
        return {c = "user",m = "confirmup",data = {errcode = 10001,errmsg = "上阵失败, 请稍后再试!", data = { }}}
    end
    local hero = heromodel:getherobyheroid(heroid)
    if not hero then
        return {c = "user",m = "confirmup",data = {errcode = 10002,errmsg = "武将获取失败, 请稍后再试!", data = { }}}
    end
    local pos = heromodel:getemptypos()
    if not pos then
        return {c = "user",m = "confirmup",data = {errcode = 10003,errmsg = "上阵武将达到数量限制", data = { }}}
    end
    heromodel:changepos(heroid, pos)
    achievementmodel:emit("herolvup", achievementmodel)
    return {c = "user",m = "confirmup",data = {errcode = 0,data = { pos = pos}}}
end

--直接下阵
function user.confirmdown(cmd)
    local heroid = cmd.data.heroid
    if not heroid then
        return {c = "user",m = "confirmdown",data = {errcode = 10001,errmsg = "下阵失败, 请稍后再试!", data = { }}}
    end
    local hero = heromodel:getherobyheroid(heroid)
    if not hero then
        return {c = "user",m = "confirmdown",data = {errcode = 10002,errmsg = "武将获取失败, 请稍后再试!", data = { }}}
    end

    if hero.pos <= 0 then
        return {c = "user",m = "confirmdown",data = {errcode = 10003,errmsg = "武将不在阵上", data = { }}}
    end

    if heromodel:getupnum() == 1 then
        return {c = "user",m = "confirmdown",data = {errcode = 10004,errmsg = "不能下阵所有武将", data = { }}}
    end

    heromodel:changepos(heroid, 0)

    return {c = "user",m = "confirmdown",data = {errcode = 0,data = { }}}
end

--重生下阵
function user.reborndown(cmd)
    local heroid = cmd.data.heroid
    if not heroid then
        return {c = "user",m = "reborndown",data = {errcode = 10001,errmsg = "下阵失败, 请稍后再试!", data = { }}}
    end
    local hero = heromodel:getherobyheroid(heroid)
    if not hero then
        return {c = "user",m = "sign",data = {errcode = 10002,errmsg = "武将获取失败, 请稍后再试!", data = { }}}
    end
    if hero.pos <= 0 then
        return {c = "user",m = "reborndown",data = {errcode = 10003,errmsg = "武将不在阵上", data = { }}}
    end

    if heromodel:getupnum() == 1 then
        return {c = "user",m = "reborndown",data = {errcode = 10004,errmsg = "不能下阵所有武将", data = { }}}
    end
    local t = heromodel:caltotalresource(heroid)
    bagmodel:incrBagB(t)
    heromodel:reborn(heroid)
    return {c = "user",m = "reborndown",data = {errcode = 0,data = { }}}

end

--无损替换
function user.changehero(cmd)
    local heroid1 = cmd.data.heroid1
    local heroid2 = cmd.data.heroid2

    if not heroid1 or not heroid2 then
        return {c = "user",m = "changehero",data = {errcode = 10000,errmsg = "请求异常,请稍后再试", data = { }}}
    end

    if heroid1 == heroid2 then
        return {c = "user",m = "changehero",data = {errcode = 10000,errmsg = "不能替换自己", data = { }}}
    end

    local hero1 = heromodel:getherobyheroid(heroid1)

    if not hero1 then
        return {c = "user",m = "changehero",data = {errcode = 10001,errmsg = "武将获取失败, 请稍后再试!", data = { }}}
    end

    if hero1.pos <= 0 then
        return {c = "user",m = "changehero",data = {errcode = 10002,errmsg = "武将为上阵!", data = { }}}
    end

    local hero2 = heromodel:getherobyheroid(heroid2)

    if not hero2 then
        return {c = "user",m = "changehero",data = {errcode = 10003,errmsg = "武将获取失败, 请稍后再试!", data = { }}}
    end

    if hero2.pos > 0 then
        return {c = "user",m = "changehero",data = {errcode = 10004,errmsg = "禁止替换阵上的武将!", data = { }}}
    end

    local hero1 = clone(hero1)

    local hero2 = clone(hero2)

    heromodel:changehero(heroid1, hero2)
    heromodel:changehero(heroid2, hero1)
    return {c = "user",m = "changehero",data = {errcode = 0,data = { }}}
end

--位置改变
function user.changepos(cmd)
    local pos1 = cmd.data.pos1
    local pos2 = cmd.data.pos2
    if not pos1 or not pos2 then
        return {c = "user",m = "changepos",data = {errcode = 10001,errmsg = "请求异常,请稍后再试", data = { }}}
    end

    if pos1 <= 0 or pos2 <= 0 then
        return {c = "user",m = "changepos",data = {errcode = 10002,errmsg = "请求异常,请稍后再试", data = { }}}
    end

    if pos1 > 5 or pos2 > 5 then
        return {c = "user",m = "changepos",data = {errcode = 10003,errmsg = "请求异常,请稍后再试", data = { }}}
    end

    if pos1 == pos2 then
        return {c = "user",m = "changepos",data = {errcode = 10004,errmsg = "不能替换自己", data = { }}}
    end

    local hero1 = heromodel:getherobypos(pos1)
    if not hero1 then
        return {c = "user",m = "changepos",data = {errcode = 10005,errmsg = "武将获取失败, 请稍后再试!", data = { }}}
    end
    local hero2 = heromodel:getherobypos(pos2)
    if not hero2 then
        heromodel:changepos(hero1.heroid, pos2)
    else
        heromodel:changepos(hero1.heroid, pos2)
        heromodel:changepos(hero2.heroid, pos1)
    end
    return {c = "user",m = "changepos",data = {errcode = 0,data = { }}}
end

--分享增加挂机时间
function user.addguajitime(cmd)
    if guajimodel:calsharnum() <= 0 then
        return {c = "user",m = "addguajitime",data = {errcode = 10001,errmsg = "请求异常,请稍后再试", data = { }}}
    end
    guajimodel:addguajitime()
    taskmodel:addtasknum(2, 1)
    return {c = "user",m = "addguajitime",data = {errcode = 0, errmsg = "", data={ guaji = guajimodel:serialize()}}}
end


--领取离线奖励
function user.receiveguajireward(cmd)
    local long = guajimodel:calguajitime() --挂机时长
    if long < 5 then
        return {c = "user",m = "receiveguajireward",data = {errcode = 10001, errmsg = "领取失败,请稍后再试", data={}}}
    end

    --端午节活动
    if duanwumodel._init and duanwumodel._init ~= dateutils.getday() then
        local n = math.ceil(long/3600)
        local zongzinum = 0
        for i=1,n do
            local g = math.random(1, 100)
            if g > 50 then
                zongzinum = 1
            end
        end
    end

    local long = guajimodel:receiveguajireward()
    --TODO:发放奖励
    local coin = guajilogic.getguajicoin(guajimodel:getguajilv(), long)
    local ids = guajimodel:receiveid()
    local result = guajilogic.getguajirewards(ids, long)
    result.coin = coin
    if zongzinum > 0 then
        -- bagmodel:incrBagA("zongzi_lv1", zongzinum)
        result.zongzi_lv1 = zongzinum
    end
    bagmodel:incrBagB(result)
    local rewards = {}
    for k,v in pairs(result) do
       table.insert(rewards, {tp="item", id=k, count=checkint(v)})
    end
    taskmodel:addtasknum(5, 1)
    return {c = "user",m = "receiveguajireward",data = {errcode = 0, data = {rewards = rewards, guaji = guajimodel:serialize()}}}
end


--开箱子
function user.openbox(cmd)
    local lv = cmd.data.lv
    local num = cmd.data.num
    if not lv or not num then
        return {c = "user",m = "openbox",data = {errcode = 10002, errmsg = "请求异常, 请稍后再试!",data = { } }}
    end
    lv = math.floor(lv)
    if lv < 1 or lv > 5 then
        return {c = "user",m = "openbox",data = {errcode = 10003, errmsg = "请求异常, 请稍后再试!",data = { } }}
    end
    if num < 1 or num > 10 then
        return {c = "user",m = "openbox",data = {errcode = 10004, errmsg = "请求异常, 请稍后再试!",data = { } }}
    end
    local n = bagmodel:getboxnum(lv)
    if n < num then
        return {c = "user",m = "openbox",data = {errcode = 10005, errmsg = "数量不足, 请稍后再试!",data = { } }}
    end
    --没有武将 优先抽到武将 前2个宝箱
    if #heromodel:getall() < 2 then
        local heroid = herologic.randomzihero(heromodel:gethaveheros())
        local hero = {}
        hero.id = UID*1000+heroid
        hero.uid = UID
        hero.serverid = usermodel.serverid
        hero.heroid = heroid
        heromodel:add(hero)
        bagmodel:openbox(lv, num)
        return {c = "user",m = "openbox",data = {errcode = 0, errmsg = "",data = { rewards = { {tp="hero", id=heroid, count=1} } } }}
    end
    local rets = boxlogic.openbox(lv, num)
    --TODO:根据结果处理
    local rewards = {}
    local params = {}
    for i,v in ipairs(rets) do
        if v.tp == "hero" then
            local heroid = v.heroid
            local r = heromodel:checkhero(heroid)
            if r then
                params["card_"..heroid] = params["card_"..heroid] or 0
                params["card_"..heroid] = params["card_"..heroid] + v.count
                local reward = {tp="item", id="card_"..heroid, count=v.count}
                table.insert(rewards, reward)
            else
                local hero = {}
                hero.id = UID*1000+heroid
                hero.uid = UID
                hero.serverid = usermodel.serverid
                hero.heroid = heroid
                heromodel:add(hero)
                local reward = {tp="hero", id=heroid, count=1}
                table.insert(rewards, reward)
                achievementmodel:emit("addhero", achievementmodel)
            end
        else
            if v.tp == "coin" then
                local coin = coingetlogic.getcoingetnum(usermodel.max_level)*0.2
                params[v.tp] = params[v.tp] or 0
                params[v.tp] = params[v.tp] + v.count * coin
                local reward = {tp="item", id="coin", count=v.count * coin}
                table.insert(rewards, reward)
            else
                params[v.tp] = params[v.tp] or 0
                params[v.tp] = params[v.tp] + v.count
                local reward = {tp="item", id=v.tp, count=v.count}
                table.insert(rewards, reward)
            end
        end
    end
    bagmodel:decrBagA("box_lv"..lv, num)
    --成就
    usermodel:addopenboxnum(num)
    taskmodel:addtasknum(7, num)
    achievementmodel:emit("openbox", achievementmodel)
    local conf = boxlogic.getconfbylv(lv)
    local score = conf.score * num
    usermodel:incrboxscore(score)
    -- params["box_lv"..lv] = -num
    bagmodel:incrBagB(params)

    if baoxiangmodel._init and usermodel.max_level > 20 then
        baoxiangmodel:incrscore(score)
    end
    -- bagmodel:save2log(params, "抽取宝箱")

    return {c = "user",m = "openbox",data = {errcode = 0, errmsg = "",data = { rewards = rewards, req = cmd.data } }}
end

function user.receivebox()
    if not usermodel:checkcanreceivebox() then
        return {c = "user",m = "receivebox",data = {errcode = 10001, errmsg = "积分不足，不能领取",data = { } }}
    end
    local stage = boxlogic.getstageconfbystage(usermodel.box_stage)
    local name = stage.value
    bagmodel:incrBagA(name, 1)
    usermodel:decrboxscore(stage.limit)
    usermodel:boxstageup()
    bagmodel:save2log({[name]=1}, "领取积分宝箱")
    return {c = "user",m = "receivebox",data = {errcode = 0, errmsg = "",data = { rewards={{tp="item", id=name, count=1}}, box_score=usermodel.box_score, box_stage=usermodel.box_stage } }}
end

--一键领取全部
function user.receiveboxall()
    if not usermodel:checkcanreceivebox() then
        return {c = "user",m = "receiveboxall",data = {errcode = 10001, errmsg = "积分不足，不能领取",data = { } }}
    end
    local score, stage, rewards = boxlogic.getrewards(usermodel.box_score, usermodel.box_stage)
    if #rewards <= 0 then
        return {c = "user",m = "receiveboxall",data = {errcode = 10002, errmsg = "领取失败,请稍后再试",data = { } }}
    end
    local params = {}
    for i,v in ipairs(rewards) do
        params[v.id] = params[v.id] or 0
        params[v.id] = params[v.id] + v.count
    end
    bagmodel:incrBagB(params)
    usermodel:updateboxscore(score)
    usermodel:updateboxstage(stage)
    bagmodel:save2log(params, "一键领取积分宝箱")
    return {c = "user",m = "receiveboxall",data = {errcode = 0, errmsg = "",data = { rewards=rewards, box_score=usermodel.box_score, box_stage=usermodel.box_stage } }}
end


--过关
function user.pass(cmd)
    local level = cmd.data.level
    -- local battles = cmd.data.battles -- 战斗数据
    local box   = cmd.data.box
    if not level then
        return {c = "user",m = "pass",data = {errcode = 10001, errmsg = "请求异常, 请稍后再试!",data = { } }}
    end

    if level ~= usermodel.max_level then
        return {c = "user",m = "pass",data = {errcode = 10002, errmsg = "关卡数据异常已重置!",data = { } }}
    end

    local lv = checkint(box)
    if lv > 0 then
        bagmodel:incrBagA("box_lv"..lv, 1)
    end

    --TODO:验证战斗数据
    local coin = levellogic.getwavecoin(level)
    bagmodel:incrBagA("coin", coin)
    --过关
    local max_level = usermodel.max_level
    local rewards = {}
    if max_level > 10 and max_level % 10 == 0 then
        bagmodel:incrBagA("zhishibi", 1)
        table.insert(rewards, {tp="item", id="zhishibi", count=1})
    end
    usermodel:incrlevel()
    --TODO 开启灯神 需要把数据存到库中
    achievementmodel:emit("rank", achievementmodel)
    return {c = "user",m = "pass",data = {errcode = 0, errmsg = "",data = { max_level = max_level, rewards=table.array(rewards)} }}
end


--购买挂机时长
function user.buyguajitime(cmd)
    local base_guaji_timelong = usermodel.base_guaji_timelong
    local cfg = guajilogic.getguajishichangconf(base_guaji_timelong)
    assert(cfg~=nil)
    local price = cfg.price
    local order_no = skynet.call(".id_service", "lua", "getuuid")

    local log = {
        uid=UID,
        openid=usermodel.openid,
        regionid=usermodel.regionid,
        serverid=usermodel.serverid,
        order_no=order_no,
        description = "购买挂机奖励时长",
        prepay_id="",
        payment=price,
        pay_status=0,
        pay_type="buyguajitime",
        recharge_id=tostring(cfg.id),
        recharge_conf=cfg,
        complete=0,
        completed_at="",
        created_at=dateutils.get_datetime()
    }
    local ok = mongohelper.insert(settings.recharge_mongodb_key.tname, settings.recharge_mongodb_key.cname, log)
    if not ok then
        return {c = "user",m = "buyguajitime",data = {errcode = 10003, errmsg = "购买失败, 请稍后再试", data = { } }}
    end

    return {c = "user",m = "buyguajitime",data = {errcode = 0, errmsg = "",data = { order_no = order_no } }}
end


--挂机等级增加
function user.guajilvup(cmd)
    if bagmodel:getnum("zhishibi") <= 0 then
        return {c = "user",m = "guajilvup",data = {errcode = 10001, errmsg = "资源不足",data = { } }}
    end
    bagmodel:decrBagA("zhishibi", 1)
    bagmodel:save2log({zhishibi=-1}, "挂机等级升级")
    guajimodel:guajilvup()
    return {c = "user",m = "guajilvup",data = {errcode = 0, errmsg = "",data = { guaji = guajimodel:serialize() }}}
end

--领取挂机等级奖励
function user.receiveguajilvreward(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "user",m = "receiveguajilvreward",data = {errcode = 10001, errmsg = "请求异常, 请稍后再试!",data = { } }}
    end
    id = checkint(id)
    if guajimodel:checkreceive(id) then
        return {c = "user",m = "receiveguajilvreward",data = {errcode = 10002, errmsg = "请勿重复领取!",data = { } }}
    end

    local cfg = guajilogic.getguajidengjiconf(id)
    local mylv = guajimodel:getguajilv()
    if cfg.level > mylv then
        return {c = "user",m = "receiveguajilvreward",data = {errcode = 10003, errmsg = "等级不符, 请稍后再试!",data = { } }}
    end

    local rewards = cfg.clear_rewards
    if #rewards > 0 then
        local param = {}
        for i,v in ipairs(rewards) do
            param[v.key] = param[v.key] or 0
            param[v.key] = param[v.key] + v.value
        end
        bagmodel:incrBagB(param)
    end
    guajimodel:receive(id)
    return {c = "user",m = "receiveguajilvreward",data = {errcode = 0, errmsg = "",data = { } }}
end


--刷新黑市
function user.refreshblackmarket(cmd)
    if not blackmarketmodel:chechrefresh() then
        return {c = "user",m = "refreshblackmarket",data = {errcode = 10001, errmsg = "刷新次数超过上限",data = { } }}
    end

    local speed = blackmarketmodel:getrefreshspeed()
    if bagmodel:getnum("gold") < speed then
        return {c = "user",m = "refreshblackmarket",data = {errcode = 10002, errmsg = "金砖不足",data = { } }}
    end

    bagmodel:decrBagA("gold", speed)
    blackmarketmodel:refresh()

    return {c = "user",m = "refreshblackmarket",data = {errcode = 0, errmsg = "",data = { blackmarket = blackmarketmodel:serialize() } }}
end


--购买黑市
function user.buyblackmarket(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "user",m = "buyblackmarket",data = {errcode = 10001, errmsg = "请求异常, 请稍后再试!",data = { } }}
    end

    if not blackmarketmodel._init then
        return {c = "user",m = "buyblackmarket",data = {errcode = 10001, errmsg = "请求异常, 请稍后再试!",data = { } }}
    end
    id = checkint(id)

    if blackmarketmodel:checkbuy(id) == 1 then
        return {c = "user",m = "buyblackmarket",data = {errcode = 10002, errmsg = "请勿重复购买!",data = { } }}
    end

    local gold = blackmarketmodel:getprice(id)
    if bagmodel:getnum("gold") < gold then
        return {c = "user",m = "buyblackmarket",data = {errcode = 10003, errmsg = "金砖不足",data = { } }}
    end

    bagmodel:decrBagA("gold", gold)
    blackmarketmodel:dobuy(id)

    local cfg = blackmarketlogic.getconfbyid(id)
    DEBUG("cfg rewards = ", cjson.encode(cfg))
    local result = cfg.reward
    local param = {}
    param[result.key] = result.value
    local rews = {}
    table.insert(rews, {tp="item", id=result.key, count=result.value})
    DEBUG("cfg param = ", cjson.encode(param))

    if #table.keys(param) > 0 then
        bagmodel:incrBagB(param)
    end
    taskmodel:addtasknum(9, 1)
    achievementmodel:emit("blackmarket", achievementmodel)
    return {c = "user",m = "buyblackmarket",data = {errcode = 0, errmsg = "",data = { blackmarket = blackmarketmodel:serialize(), rewards = rews } }}
end

--获取全服排行榜
function user.loadserverrank(cmd)
    local rank, myrank = skynet.call(".usercenterd", "lua", "getallrank", UID)
    return {c = "user",m = "loadserverrank",data = {errcode = 0, errmsg = "",data = { rank = table.array(rank), myrank = myrank} }}
end

--获取俱乐部排行榜
function user.loadclubrank(cmd)
    local rank, myrank = skynet.call(".clubcenterd", "lua", "getrank", UID, usermodel:getserverid())
    return {c = "user",m = "loadclubrank",data = {errcode = 0, errmsg = "",data = { rank = table.array(rank), myrank = myrank} }}
end

function user.loaduserinfo(cmd)
    local userid = cmd.data.userid
    if not userid then
        return {c = "user",m = "loaduserinfo",data = {errcode = 10001, errmsg = "请求异常, 请稍后再试!",data = { } }}
    end
    userid = checkint(userid)
    local user = skynet.call(".usercenterd", "lua", "getuserbyid", userid)
    if not user then
        return {c = "user",m = "loaduserinfo",data = {errcode = 10002, errmsg = "用户ID错误",data = { } }}
    end

    user.is_friend = friendmodel:isfriend(userid)

    user.is_black = friendmodel:isblack(userid)

    local result = skynet.call(".friendd", "lua", "checkapply", UID, userid)
    if not result then
        user.is_apply = -1
    else
        user.is_apply = result.status
    end

    local club = skynet.call(".clubcenterd", "lua", "loadclubinfo", userid) or {}

    return {c = "user",m = "loaduserinfo",data = {errcode = 0, errmsg = "",data = { user = user, club = club } }}
end

--招募
function user.recruit(cmd)
    local num = cmd.data.num
    if not num then
        return {c = "user",m = "recruit",data = {errcode = 10001, errmsg = "请求异常, 请稍后再试!",data = { } }}
    end
    num = checkint(num)
    local free = false
    if num == 1 then
        if not usermodel:checkrecruit() then
            if bagmodel.zhaomuling < num then
                return {c = "user",m = "recruit",data = {errcode = 10002, errmsg = "资源不足!",data = { } }}
            end
        else
            free = true
        end
    end

    local result = recruitlogic.recruit(math.floor(num))
    local rewards = {}
    local params = {}
    for _, v in ipairs(result) do
        local heroid = math.floor(v.heroid)
        if heromodel:checkhero(heroid) then
            params["card_"..heroid] = params["card_"..heroid] or 0
            params["card_"..heroid] = params["card_"..heroid] + v.count
            table.insert(rewards, {tp="item", id="card_"..heroid, count=v.count})
        else
            local hero = {}
            hero.id = UID*1000+heroid
            hero.uid = UID
            hero.serverid = usermodel.serverid
            hero.heroid = heroid
            heromodel:add(hero)
            achievementmodel:emit("addhero", achievementmodel)
            table.insert(rewards, {tp="hero", id=heroid, count=1})
        end
    end

    if num ~= 1 or not usermodel:checkrecruit() then
        bagmodel:decrBagA("zhaomuling", num)
    else
        usermodel:updaterecruittime()
    end
    if #table.keys(params) > 0 then
        bagmodel:incrBagB(params)
    end
    if zhaomumodel._init and usermodel.max_level > 20 then
        zhaomumodel:incrscore(num)
    end
    bagmodel:save2log(params, "招募咸将")
    --TODO:招募次数
    usermodel:addrecruitnum(num)
    taskmodel:addtasknum(4, num)
    achievementmodel:emit("recruit", achievementmodel)
    if free then
        num = 0
    end
    return {c = "user",m = "recruit",data = {errcode = 0, errmsg = "",data = { rewards = rewards, num=num, recruit_over_timelong = usermodel:caloverrecruittimelong() } }}
end

--开启礼包
function user.openlibao(cmd)
    local tp = cmd.data.tp
    local num = cmd.data.num
    local heroid = cmd.data.heroid
    if not tp or not num then
        return {c = "user",m = "openlibao",data = {errcode = 10001,errmsg = "请求异常,请稍后再试!", data = { }}}
    end

    if num > 99 then
        return {c = "user",m = "openlibao",data = {errcode = 10002,errmsg = "最多一次开99个礼包!", data = { }}}
    end

    if bagmodel:getnum(tp) < num then
        return {c = "user",m = "openlibao",data = {errcode = 10002,errmsg = "数量不足", data = { }}}
    end
    bagmodel:decrBagA(tp, num)
    if tp == "libao_wujiang_cheng2" or tp == "libao_wujiang_hong2" then
        heroid = checkint(heroid)
        local rewards = libaologic.openlibao2(tp, num, heroid)
        local param = {}
        for i,v in ipairs(rewards) do
            param[v.id] = param[v.id] or 0
            param[v.id] = param[v.id] + v.count
        end
        bagmodel:incrBagB(param)
        bagmodel:save2log(param, "开启礼包")
        return {c = "user",m = "openlibao",data = {errcode = 0, errmsg = "",data = { rewards = rewards } }}
    else
        local rewards = libaologic.openlibao(tp, num)
        if tp == "libao_coin" then
            local t = 0
            for i,v in ipairs(rewards) do
                local coin = guajilogic.getguajicoin(guajimodel:getguajilv(), 3600 * v.count)
                t = t + coin
                v.count = coin
            end
            bagmodel:incrBagA("coin", t)
            bagmodel:save2log({coin=t}, "开启金币礼包")
        else
            local param = {}
            for i,v in ipairs(rewards) do
                param[v.id] = param[v.id] or 0
                param[v.id] = param[v.id] + v.count
            end
            bagmodel:incrBagB(param)
            bagmodel:save2log(param, "开启礼包")
        end
        return {c = "user",m = "openlibao",data = {errcode = 0, errmsg = "",data = { rewards = rewards } }}
    end

end


--鱼灵图鉴
function user.loadartifact(cmd)
    return {c = "user",m = "loadartifact",data = {errcode = 0,data = {artifacts=artifactmodel:serialize()}}}
end

--鱼灵图鉴
function user.qibook(cmd)
    return {c = "user",m = "qibook",data = {errcode = 0,data = {books=artifactmodel:serializebook()}}}
end

--收集鱼灵徽星
function user.collectqiemblemstar(cmd)
    local artid = cmd.data.artid
    if not artid then
        return {c = "user",m = "collectqiemblemstar",data = {errcode = 10001,errmsg = "请求异常,请稍后再试!", data = { }}}
    end

    artid = checkint(artid)

    local star = artifactmodel:getartbyartid(artid)
    assert(star > 0 , " 鱼灵没有找到 ")

    local n = artifactmodel:getcollectcount(artid)

    if n >= star then
        return {c = "user",m = "collectqiemblemstar",data = {errcode = 10002,errmsg = "升级条件不满足!", data = { }}}
    end

    local s = artifactmodel:collectemblemstar(artid)
    DEBUG("artifactmodel collectemblemstar s = ", s)
    if s <= 0 then
        return {c = "user",m = "collectqiemblemstar",data = {errcode = 10003,errmsg = "收集失败!", data = { }}}
    end

    local star = booklogic.getqiemblemstarnum(artid, s)
    DEBUG("artifactmodel collectemblemstar incr star = ", star)
    assert(star ~= nil, "获取徽星数量失败")
    usermodel:incremblemstar(star)
    return {c = "user",m = "collectqiemblemstar",data = {errcode = 0,data = {}}}
end

-- 佩戴器
function user.wearqi(cmd)
    local id = cmd.data.id
    local heroid = cmd.data.heroid
    local wearid = cmd.data.wearid --佩戴的英雄id
    if not id or not heroid then
        return {c = "user",m = "wearqi",data = {errcode = 10001,errmsg = "请求异常,请稍后再试!", data = { }}}
    end
    id = checkint(id)
    heroid = checkint(heroid)
    wearid = checkint(wearid)
    local art = artifactmodel:getartbyheroid(heroid)
    if art ~= nil then
        return {c = "user",m = "wearqi",data = {errcode = 10002,errmsg = "请先卸下该武将的器!", data = { }}}
    end
    if wearid ~= 0 then
        local art = artifactmodel:getartbyheroid(wearid)
        if art.id ~= id then
            return {c = "user",m = "wearqi",data = {errcode = 10003,errmsg = "器获取失败!", data = { }}}
        end
        artifactmodel:takeoffqi(wearid)
    end

    artifactmodel:wear(id, heroid)
    return {c = "user",m = "wearqi",data = {errcode = 0,errmsg = "", data = { }}}
end


-- 取下器
function user.takeoffqi(cmd)
    local heroid = cmd.data.heroid
    if not heroid then
        return {c = "user",m = "takeoffqi",data = {errcode = 10001,errmsg = "请求异常,请稍后再试!", data = { }}}
    end
    heroid = checkint(heroid)
    local art = artifactmodel:getartbyheroid(heroid)
    if art == nil then
        return {c = "user",m = "takeoffqi",data = {errcode = 10002,errmsg = "该武将未佩戴器!", data = { }}}
    end
    artifactmodel:takeoffqi(heroid)
    return {c = "user",m = "takeoffqi",data = {errcode = 0, errmsg = "", data = { }}}
end

--百服消息
function user.sendmsg(cmd)
    local content = cmd.data.content
    if not content then
        return {c = "user",m = "sendmsg",data = {errcode = 10001, errmsg = "请求异常, 请稍后再试!", data = { }}}
    end
    if content == "" then
        return {c = "user",m = "sendmsg",data = {errcode = 10002, errmsg = "消息不能为空!", data = { }}}
    end
    local is_valid = skynet.call(".word_crab", "lua", "is_valid", content)
    if not is_valid then
        return {c = "user",m = "sendmsg",data = {errcode = 10003, errmsg = "存在违规词!", data = { }}}
    end
    local id = skynet.call(".id_service", "lua", "genid", "baifumsg")
    assert(id~=nil, "id 获取失败")
    local msg = {
        id=id,
        server=usermodel:getBaiFuServer(),
        sender=usermodel:get_look_info(),
        content=content,
        created_at=dateutils.get_datetime()
    }
    skynet.call(".msgcenterd", "lua", "sendbaifumsg", usermodel:getBaiFuServer(), msg)
    skynet.send(".msgd", "lua", "sendbaifumsg", usermodel:getBaiFuServer(), msg)
    return {c = "user",m = "sendmsg", data = {errcode = 0, errmsg = "", data = {}}}
end

--购买专属折扣
function user.receivevip(cmd)
    local id = cmd.data.id
    if not id then
        return {c = "user",m = "receivevip",data = {errcode = 10001,errmsg = "请求异常,请稍后再试!", data = { }}}
    end

    local cfg = viplogic.getconf(id)
    assert(cfg ~= nil, " 配置不存在！ ")
    local gold = cfg.gold1
    if gold > bagmodel.gold then
        return {c = "user",m = "receivevip",data = {errcode = 10002,errmsg = "金砖不足!", data = { }}}
    end
    bagmodel:decrBagA("gold", gold)
    local rews = cfg.vip_rewards
    local param = {}
    for i,v in ipairs(rews) do
        param[v.key] = param[v.key] or 0
        param[v.key] = param[v.key] + v.value
    end
    bagmodel:incrBagB(param)

    vipmodel:receive(id)
    return {c = "user",m = "receivevip",data = {errcode = 0,errmsg = "", data = { }}}
end

function user.buyitem(cmd)
    local name = cmd.data.name
    local num = cmd.data.num
    if not name or not num then
        return {c = "user",m = "buyitem",data = {errcode = 10001, errmsg = "请求异常, 请稍后再试!",data = { } }}
    end

    num = checkint(num)

    if num < 0 then
        return {c = "user",m = "buyitem",data = {errcode = 10002, errmsg = "请求异常, 请稍后再试!",data = { } }}
    end

    local mygold = bagmodel:getnum("gold")
    local gold = goldlogic.getgold(name)

    if mygold < gold then
        return {c = "user",m = "buyitem",data = {errcode = 10001, errmsg = "金砖数量不足",data = { } }}
    end

    bagmodel:incrBagA(name, num)
    bagmodel:decrBagA("gold", num * gold)
    return {c = "user",m = "buyitem",data = {errcode = 0, errmsg = "",data = { } }}
end

--使用兑换码
function user.usecode(cmd)
    local code = cmd.data.code
    if not code then
        return {c = "user",m = "usecode",data = {errcode = 10001, errmsg = "请求异常, 请稍后再试!",data = { } }}
    end

    local info = skynet.call(".coded", "lua", "loadbycode", code)

    if info == nil then
        return {c = "user",m = "usecode",data = {errcode = 10002, errmsg = "兑换码错误!",data = { } }}
    end

    if checkint(info.status) == 2 then
        return {c = "user",m = "usecode",data = {errcode = 10002, errmsg = "无效的兑换码!",data = { } }}
    end

    if checkint(info.total) > 0 and checkint(info.total) <= checkint(info.num) then
        return {c = "user",m = "usecode",data = {errcode = 10002, errmsg = "已达兑换总数!",data = { } }}
    end

    if checkint(info.vip) > usermodel:getviplv() then
        return {c = "user",m = "usecode",data = {errcode = 10003, errmsg = "vip等级不足!",data = { } }}
    end

    if checkint(info.expire_type) == 2 then
        local pattern = "(%d+)-(%d+)-(%d+) (%d+):(%d+):(%d+)"
        local s = dateutils.get_timestamp_by_datetime(info.start_expire .. " 00:00:00", pattern)
        local e = dateutils.get_timestamp_by_datetime(info.end_expire .. " 23:59:59", pattern)
        if os.time() < s then
            return {c = "user",m = "usecode",data = {errcode = 10003, errmsg = "兑换码未开始!",data = { } }}
        end
        if os.time() > e then
            return {c = "user",m = "usecode",data = {errcode = 10004, errmsg = "兑换码已结束!",data = { } }}
        end
    end

    local c = skynet.call(".coded", "lua", "checkreceive", UID, code)
    if c then
        return {c = "user",m = "usecode",data = {errcode = 10005, errmsg = "请勿重复领取!",data = { } }}
    end

    local ok = skynet.call(".coded", "lua", "receive", UID, code)
    if not ok then
        return {c = "user",m = "usecode",data = {errcode = 10006, errmsg = "兑换失败!",data = { } }}
    end

    local rewards = {}
    local items = info.items
    local param = {}
    for i,v in ipairs(items) do
        param[v.name] = param[v.name] or 0
        param[v.name] = param[v.name] + checkint(v.num)
        table.insert(rewards, {tp="item", id=v.name, count=v.num})
    end
    bagmodel:incrBagB(param)

    local log = {
        uid=UID,
        code=code,
        items=items,
        created_at=dateutils.get_datetime()
    }

    local ok = mqhelper.exec("insert", UID, settings.code_exchange_mongodb_key.tname, settings.code_exchange_mongodb_key.cname, log)

    return {c = "user",m = "usecode",data = {errcode = 0, errmsg = "",data = { rewards = rewards} }}
end

function user.loadserver(cmd)

    local myusers = skynet.call(".usercenterd", "lua", "getmyusers", usermodel.unionid)

    local server_list = mongohelper.find(settings.game_server_mongodb_key.tname, settings.game_server_mongodb_key.cname, nil, nil, {_id=-1})
    local server_items = mongohelper.find(settings.server_item_mongodb_key.tname, settings.server_item_mongodb_key.cname, nil, nil, {_id=-1})

    local servers = {}
    local function findstatus(serverid, server_items)
        for i,v in ipairs(server_items) do
            if v.server_id == serverid then
                return checkint(v.status)
            end
        end
        return 2
    end

    for i,v in ipairs(myusers) do
        table.insert(servers, {server_id=0, _id=checkint(v.serverid), status=findstatus(v.serverid, server_items), user=v})
    end

    local function finduserbyserverid(serverid, myusers)
        for i,v in ipairs(myusers) do
            if v.serverid == serverid then
                return v
            end
        end
        return nil
    end
    local function getitems(_id, server_items)
        local items = {}
        for i,v in ipairs(server_items) do
            if v.server_id == _id then
                local u = finduserbyserverid(v._id, myusers)
                v.user = u
                table.insert(items, v)
            end
        end
        table.sort( items, function(a, b)
            return a._id > b._id
        end)
        return table.array(items)
    end
    for i,v in ipairs(server_list) do
        v.items = getitems(v._id, server_items)
    end

    table.sort( server_list, function(a, b)
        return a._id > b._id
    end)

    table.insert(server_list, 1, {_id=0, server_name="最近登录", items=table.array(servers)})
    return {c = "user",m = "loadserver",data = {errcode = 0, errmsg = "",data = { list = { server_list = server_list} } }}
end

function user.chooseserver(cmd)
    local serverid = cmd.data.serverid
    if not serverid then
        return {c = "user",m = "chooseserver",data = {errcode = 10001, errmsg = "请求异常, 请稍后再试!",data = { } }}
    end
    serverid = checkint(serverid)
    if serverid == usermodel.serverid then
        return {c = "user",m = "chooseserver",data = {errcode = 10002, errmsg = "您已在当前服务器!",data = { } }}
    end

    local server = mongohelper.findOne(settings.server_item_mongodb_key.tname, settings.server_item_mongodb_key.cname, {_id=serverid})

    if server == nil then
        return {c = "user",m = "chooseserver",data = {errcode = 10003, errmsg = "服务器不存在!",data = { } }}
    end

    local ok = skynet.call(".redisd", "lua", "chooseserver", usermodel.unionid, serverid)
    if not ok then
        return {c = "user",m = "chooseserver",data = {errcode = 10003, errmsg = "选择服务器失败!",data = { } }}
    end
    return {c = "user",m = "chooseserver",data = {errcode = 0, errmsg = "",data = { } }}
end

function user.updateuser(cmd)
    local nickname = cmd.data.nickname
    local avatar = cmd.data.avatar
    if not nickname or not avatar then
        return {c = "user",m = "updateuser",data = {errcode = 10001, errmsg = "请求异常, 请稍后再试!",data = { } }}
    end

    if usermodel.is_update ~= 1 then
        usermodel:savenickname(nickname)
    end

    usermodel:saveavatar(avatar)

    return {c = "user",m = "updateuser",data = {errcode = 0, errmsg = "",data = { nickname = usermodel.nickname, avatar = usermodel.avatar } }}
end

--获取修改次数
function user.loadupdatenum(cmd)
    local num = skynet.call(".redisd", "lua", "getupdatenicknamenum", UID)
    return {c = "user",m = "loadupdatenum",data = {errcode = 0, errmsg = "",data = { num=num } }}
end

function user.updatenickname(cmd)
    local nickname = cmd.data.nickname
    if not nickname or nickname == "" then
        return {c = "user",m = "updatenickname",data = {errcode = 10001, errmsg = "昵称输入错误",data = { } }}
    end

    local ok = skynet.call(".word_crab", "lua", "is_valid", nickname)
    if not ok then
        return { c = "user", m = "updatenickname", data = { errcode = 10001, errmsg = "昵称存在违规字", data = {}} }
    end
    local num = skynet.call(".redisd", "lua", "getupdatenicknamenum", UID)
    num = checkint(num)
    if num > 0 then
        if bagmodel.gold < 200 then
            return {c = "user",m = "updatenickname",data = {errcode = 10002, errmsg = "金砖不足",data = { } }}
        end
        bagmodel:decrBagA("gold", 200)
    end
    usermodel:savenickname(nickname)
    local ok = skynet.call(".redisd", "lua", "incrupdatenicknamenum", UID)
    -- DEBUG("ok = ", ok)
    return {c = "user",m = "updatenickname",data = {errcode = 0, errmsg = "",data = { nickname = usermodel.nickname } }}
end

function user.addbag(cmd)
    local name = cmd.data.name
    local num = cmd.data.num
    if not name or not num then
        return {c = "user",m = "addbag",data = {errcode = 10001, errmsg = "请求异常, 请稍后再试!",data = { } }}
    end
    bagmodel:incrBagA(name, tonumber(num))
    bagmodel:save2log({[name]=num}, "测试增加")
    return {c = "user",m = "addbag",data = {errcode = 0, errmsg = "",data = { bag = { } } }}
end

return user
