local skynet        = require "skynet"
local netpack       = require "websocketnetpack"
local msgutils      = require "msgutils"
local cjson         = require "cjson"
local usermodel     = require "usermodel"
local bagmodel      = require "bagmodel"
local heromodel     = require "heromodel"
local settings      = require "settings"
local bson          = require "bson"
local mqhelper      = require "mqhelper"
local mongohelper   = require "mongohelper"
local dateutils     = require "dateutils"
local towerlogic    = require "towerlogic"

--咸将塔

local function caltowerlevel(n)
    return string.format("第%s层", tostring(math.floor(n/10)+1).."-"..tostring(math.floor((n-1)%10+1)))
end

local tower = {}


function tower.loadtower(cmd)
    local laststage = usermodel:callasttowerstage()
    local ok, laststatus = pcall(skynet.call, ".towerd", "lua", "gettowerstatus", UID, laststage)
    if not ok then
        laststatus = 0
    end
    return {c = "tower",m = "loadtower", data = {errcode = 0, data = { laststage=laststage, laststatus=laststatus }}}
end

--获取排行榜
function tower.loadrank(cmd)
    local ok, list = pcall(skynet.call, ".towerd", "lua", "loadrank", UID, usermodel:getServer())
    local players = {}
    local found = false
    local users = {}
    if ok then
        for k,v in pairs(list) do
            table.insert(players, {uid=checkint(k), level=checkint(v)})
            table.insert(users, checkint(k))
            if checkint(k) == UID then
                found = true
            end
        end
    end
    local rank = 0

    if not found then
        local ok, r =  pcall(skynet.call, ".towerd", "lua", "loadmyrank", UID, usermodel:getServer())
        if ok then
            rank = r
        end
    end

    table.sort( players, function(a, b)
        if a.level == b.level then
            return checkint(a.uid) > checkint(b.uid)
        end
        return a.level > b.level
    end)

    local ok,  res = pcall(skynet.call, ".usercenterd", "lua", "getuserinfolist", users)
    if ok then
        for i,v in ipairs(players) do
            v.nickname = res[v.uid].nickname
            v.avatar = res[v.uid].avatar
            v.zhanli = res[v.uid].zhanli
            v.level = caltowerlevel(v.level)
            if checkint(v.uid) == UID then
                rank = i
            end
        end
    end

    return {c = "tower",m = "loadrank", data = {errcode = 0, data = { players = table.array(players) , myrank = rank}}}
end

function tower.start(cmd)
    local laststage = usermodel:callasttowerstage()
    local laststatus = skynet.call(".towerd", "lua", "gettowerstatus", UID, laststage)
    if laststage > 0 and laststatus == 0 then
        return {c = "tower",m = "start", data = {errcode = 10001, errmsg = "请先领取上一个奖励", data = { }}}
    end
    local n = bagmodel:getxiaoyugan()
    if n <= 0 then
        return {c = "tower",m = "start", data = {errcode = 10002, errmsg = "数量不足", data = { }}}
    end
    -- DEBUG("tower start xiaoyugan = ", bagmodel:getxiaoyugan())
    if bagmodel:getxiaoyugan() >= 10 then
        usermodel:usexiaoyugan()
    end

    bagmodel:decrBagA("xiaoyugan", 1)
    return {c = "tower",m = "start", data = {errcode = 0,data = { }}}
end

--挑战
function tower.battle(cmd)
    local level = cmd.data.level
    local tp = cmd.data.tp
    if not level or not tp then
        return {c = "tower",m = "battle", data = {errcode = 10001, errmsg = "请求异常", data = { }}}
    end
    level = checkint(level)
    local cur_level = usermodel.tower_level
    if cur_level ~= level then
        return {c = "tower",m = "battle", data = {errcode = 10002, errmsg = "请求数据异常", data = { }}}
    end
    local laststage = usermodel:callasttowerstage()
    -- DEBUG("battle laststage = ", laststage)
    local laststatus = skynet.call(".towerd", "lua", "gettowerstatus", UID, laststage)
    if laststage > 0 and laststatus == 0 then
        return {c = "tower",m = "battle", data = {errcode = 10001, errmsg = "请先领取上一个奖励", data = { }}}
    end
    if tp == "success" then
        local ok = skynet.call(".towerd", "lua", "success", UID, usermodel:getServer())
        -- DEBUG("success = ", ok)
        --TODO:发送奖励
        local rewards = towerlogic.getrewards(level)
        for i,v in ipairs(rewards) do
            bagmodel:incrBagA(v.key, v.value)
        end
        usermodel:towerlevelup()
        --TODO: 领取每日免费礼包mongo日志
        local log = {
            uid=UID,
            serverid=usermodel.serverid,
            level=level,
            type=0,
            rewards=rewards,
            created_at=dateutils.get_datetime()
        }
        mqhelper.exec("insert", UID, settings.tower_log_mongodb_key.tname, settings.tower_log_mongodb_key.cname, log)
    end
    return {c = "tower",m = "battle", data = {errcode = 0,data = { }}}
end


--第10层 开启宝箱
function tower.openbox(cmd)
    local cur_level = usermodel.tower_level
    if math.floor(cur_level/10) == 0 then
        return {c = "tower",m = "openbox", data = {errcode = 10002, errmsg = "请求数据异常", data = { }}}
    end
    local rewards = towerlogic.getboxrewards(usermodel:callasttowerstage())
    for i,v in ipairs(rewards) do
        bagmodel:incrBagA(v.key, v.value)
    end
    local ok = skynet.call(".towerd", "lua", "settowerstatus", UID, usermodel:callasttowerstage())
    --TODO: 领取每日免费礼包mongo日志
    local log = {
        uid=UID,
        serverid=usermodel.serverid,
        level=cur_level,
        type=1,
        rewards=rewards,
        created_at=dateutils.get_datetime()
    }
    mqhelper.exec("insert", UID, settings.tower_log_mongodb_key.tname, settings.tower_log_mongodb_key.cname, log)
    return {c = "tower",m = "openbox", data = {errcode = 0,data = { }}}
end

return tower