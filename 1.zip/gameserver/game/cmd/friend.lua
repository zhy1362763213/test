local skynet        = require "skynet"
local netpack       = require "websocketnetpack"
local msgutils      = require "msgutils"
local cjson         = require "cjson"
local usermodel     = require "usermodel"
local bagmodel      = require "bagmodel"
local heromodel     = require "heromodel"
local settings      = require "settings"
local dateutils     = require "dateutils"
local usermodel     = require "usermodel"
local heromodel     = require "heromodel"
local friendmodel   = require "friendmodel"
local taskmodel     = require "taskmodel"
local coingetlogic  = require "coingetlogic"
local friend = {}


function friend.loadfriend(cmd)
     --获取我的好友
    local ok, result = pcall(skynet.call, ".friendd", "lua", "loadfriends", UID)
    local friends = {}
    local uids = {}
    if ok then
        for i,v in ipairs(result) do
            table.insert(uids, v.friendid)
        end
    end

    if #uids > 0 then
        local ok, ret = pcall(skynet.call, ".usercenterd", "lua", "getuserinfolist", uids)
        if ok then
            for k,v in pairs(result) do
                local u = ret[checkint(v.friendid)]
                u.status = v.status
                table.insert(friends, u)
            end
        end
    end
    local ok, gives, receices = pcall(skynet.call, ".friendd", "lua", "loadfriendcoin", UID)
    if not ok then
        gives = {}
        receices = {}
    end
    friendmodel:init(friends, gives, receices)
    --推荐好友
    local ok, recomfriends = pcall(skynet.call, ".usercenterd", "lua", "loadrecomfriends", UID, uids)
    -- DEBUG("loadrecomfriends ok = ", ok)
    -- DEBUG("loadrecomfriends recomfriends = ", cjson.encode(recomfriends))
    if not ok then
        recomfriends = {}
    end

    local ok, applys = pcall(skynet.call, ".friendd", "lua", "loadapply", UID)
    if not ok then
        applys = {}
    end

    local function getstatus(uid, applys)
        for i,v in ipairs(applys) do
            if v.friendid == uid then
                return v.status
            end
        end
    end

    for i,v in ipairs(recomfriends) do
        local status = getstatus(v.uid, applys)
        if status then
            v.status = 1
        else
            v.status = 0
        end
    end

    --好友申请
    local ok, applys = pcall(skynet.call, ".friendd", "lua", "loadfriendapply", UID)
    if not ok then
        applys = {}
    end
    local applyfriends = {}
    if #applys > 0 then
        local ok, ret = pcall(skynet.call, ".usercenterd", "lua", "getuserinfolist", applys)
        if ok then
            for k,v in pairs(applys) do
                table.insert(applyfriends, ret[checkint(v)])
            end
        end

    end
    local refreshtime = skynet.call(".friendd", "lua", "getrefreshtime", UID) or 0
    refreshtime = checkint(refreshtime) + 3600

    return {c = "friend",m = "loadfriend", data = {errcode = 0, errmsg = "", data = {friends=friendmodel:serialize(), recomfriends=table.array(recomfriends), applyfriends=table.array(applyfriends), refreshtime=refreshtime}}}
end


--刷新好友
function friend.refreshfriend(cmd)

    local refreshtime = skynet.call(".friendd", "lua", "getrefreshtime", UID) or 0

    -- DEBUG("refreshtime 73 = ", refreshtime)

    refreshtime = checkint(refreshtime)

    -- DEBUG("refreshtime 77 = ", refreshtime)

    if os.time() - refreshtime < 3600 then
        if bagmodel:getnum("gold") < 20 then
            return {c = "friend",m = "refreshfriend", data = {errcode = 10001, errmsg = "金砖数量不足", data = { }}}
        end
        bagmodel:decrBagA("gold", 20)
    end

    local result = skynet.call(".friendd", "lua", "loadfriends", UID)
    local players = {}

    for i,v in ipairs(result) do
        table.insert(players, v.friendid)
    end

    local applys = skynet.call(".friendd", "lua", "loadapply", UID)

    --推荐好友
    local recomfriends = skynet.call(".usercenterd", "lua", "loadrecomfriends", UID, players)

    local function getstatus(uid, applys)
        for i,v in ipairs(applys) do
            if v.uid == uid then
                return v.status
            end
        end
    end

    for i,v in ipairs(recomfriends) do
        local status = getstatus(v.uid, applys)
        if status then
            v.status = 1
        else
            v.status = 0
        end
    end

    if os.time() - refreshtime > 3600 then
        skynet.call(".friendd", "lua", "updaterefreshtime", UID)
        refreshtime = os.time()
    end
    refreshtime = refreshtime + 3600
    return {c = "friend",m = "refreshfriend", data = {errcode = 0, errmsg = "", data = {recomfriends=table.array(recomfriends), refreshtime=refreshtime}}}
end

--申请好友
function friend.apply(cmd)
    local friendid = cmd.data.friendid --好友ID
    if not friendid then
        return {c = "friend",m = "apply", data = {errcode = 10001, errmsg = "请求异常,请稍后再试", data = {}}}
    end
    friendid = checkint(friendid)

    if friendid == UID then
        return {c = "friend",m = "apply", data = {errcode = 10002, errmsg = "禁止自己自己为好友", data = {}}}
    end

    local apply = skynet.call(".friendd", "lua", "checkapply", friendid, UID)

    if apply ~= nil then
        return {c = "friend",m = "apply", data = {errcode = 10002, errmsg = "请前往同意该玩家的好友申请", data = {}}}
    end

    local apply = skynet.call(".friendd", "lua", "checkapply", UID, friendid)
    if apply ~= nil then
        return {c = "friend",m = "apply", data = {errcode = 10003, errmsg = "请勿重复申请", data = {}}}
    end

    if friendmodel:isfriend(friendid) then
        return {c = "friend",m = "apply", data = {errcode = 10003, errmsg = "该用户已是你的好友", data = {}}}
    end
    local ok = skynet.call(".friendd", "lua", "apply", UID, friendid)
    skynet.send(".msgd", "lua", "applyfriend", friendid, usermodel:get_look_info())
    return {c = "friend",m = "apply", data = {errcode = 0, errmsg = "", data = {ok=ok}}}
end


function friend.agree(cmd)
    local friendid = cmd.data.friendid --好友ID
    local status = cmd.data.status
    if not friendid or not status then
        return {c = "friend",m = "agree", data = {errcode = 10001, errmsg = "请求异常,请稍后再试", data = {}}}
    end
    friendid = checkint(friendid)
    status = checkint(status)
    if status == 1 then
        if friendmodel:isfriend(friendid) then
            return {c = "friend",m = "apply", data = {errcode = 10002, errmsg = "该用户已是你的好友", data = {}}}
        end
        local user = skynet.call(".usercenterd", "lua", "getuserinfo", friendid)
        friendmodel:addfriend(user)
    end
    local ok = skynet.call(".friendd", "lua", "agree", UID, friendid, status)
    skynet.send(".msgd", "lua", "applyagree", friendid, usermodel:get_look_info())
    return {c = "friend",m = "agree", data = {errcode = 0, errmsg = "", data = {ok=ok}}}
end

function friend.opall(cmd)
    local status = cmd.data.status
    if not status then
        return {c = "friend",m = "apply", data = {errcode = 10001, errmsg = "请求异常,请稍后再试", data = {}}}
    end
    status = checkint(status)

    if status == 1 then
        local applys = skynet.call(".friendd", "lua", "loadfriendapply", UID)

        local ret = skynet.call(".usercenterd", "lua", "getuserinfolist", applys)

        for k,v in pairs(applys) do
            if not friendmodel:isfriend(checkint(v)) then
                friendmodel:addfriend(ret[checkint(v)])
            end
        end
    end

    local ok = skynet.call(".friendd", "lua", "opagree", UID, status)
    -- DEBUG("opall ok = ", ok)
    return {c = "friend",m = "opall", data = {errcode = 0, errmsg = "", data = {ok=ok}}}
end

--赠送金币
function friend.givecoin(cmd)
    local friendid = cmd.data.friendid --好友ID
    if not friendid then
        return {c = "friend",m = "givecoin", data = {errcode = 10000, errmsg = "请求异常,请稍后再试", data = {}}}
    end
    friendid = checkint(friendid)
    if not friendmodel:isfriend(friendid) then
        return {c = "friend",m = "givecoin", data = {errcode = 10001, errmsg = "该用户不是你的好友", data = {}}}
    end
    if friendmodel:checkgive(friendid) ~= nil then
        return {c = "friend",m = "givecoin", data = {errcode = 10002, errmsg = "今日已赠送过金币", data = {}}}
    end
    local coin = coingetlogic.getcoingetnum(usermodel.max_level) * 0.2
    -- DEBUG("givecoin coin = ", coin)
    if coin == 0 then
        coin = 1
    end
    friendmodel:givecoin(friendid, coin)
    taskmodel:addtasknum(3, 1)
    skynet.send(".msgd", "lua", "givecoin", friendid, {uid=UID, coin=coin})
    return {c = "friend",m = "givecoin", data = {errcode = 0, errmsg = "", data = {}}}
end

--领取金币
function friend.receivecoin(cmd)
    local friendid = cmd.data.friendid --好友ID
    if not friendid then
        return {c = "friend",m = "receivecoin", data = {errcode = 10000, errmsg = "请求异常,请稍后再试", data = {}}}
    end
    friendid = checkint(friendid)
    if not friendmodel:isfriend(friendid) then
        return {c = "friend",m = "receivecoin", data = {errcode = 10001, errmsg = "该用户不是你的好友", data = {}}}
    end
    if not friendmodel:checkreceive(friendid) then
        return {c = "friend",m = "receivecoin", data = {errcode = 10002, errmsg = "领取金币失败", data = {}}}
    end
    local coin = friendmodel:receivecoin(friendid)
    bagmodel:incrBagA("coin", coin)
    return {c = "friend",m = "receivecoin", data = {errcode = 0, errmsg = "", data = {coin=coin}}}
end


--一键领取赠送金币
function friend.giveandreceive(cmd)
    if not friendmodel:checkgiveandreceive() then
        return {c = "friend",m = "giveandreceive", data = {errcode = 10000, errmsg = "暂时无法领取或赠送金币", data = {}}}
    end
    local coin = coingetlogic.getcoingetnum(usermodel.max_level) * 0.2
    local gives, receives = friendmodel:giveandreceive()
    DEBUG("giveandreceive gives = ", cjson.encode(gives))
    DEBUG("giveandreceive receives = ", cjson.encode(receives))
    for _, gid in ipairs(gives) do
        friendmodel:givecoin(gid, coin)
        taskmodel:addtasknum(3, 1)
        skynet.send(".msgd", "lua", "givecoin", gid, usermodel:get_look_info())
    end
    local t = 0
    local coins = {}
    for _, fid in ipairs(receives) do
        local coin = friendmodel:receivecoin(fid)
        DEBUG("giveandreceive receivecoin coin = ", coin)
        t = t + coin
        table.insert(coins, coin)
    end
    bagmodel:incrBagA("coin", t)
    return {c = "friend",m = "giveandreceive", data = {errcode = 0, errmsg = "", data = {coins=coins, give_num = #gives}}}
end


--拉黑好友
function friend.black(cmd)
    local friendid = cmd.data.friendid --好友ID
    if not friendid then
        return {c = "friend",m = "black", data = {errcode = 10000, errmsg = "请求异常,请稍后再试", data = {}}}
    end
    friendid = checkint(friendid)
    if not friendmodel:isfriend(friendid) then
        return {c = "friend",m = "black", data = {errcode = 10001, errmsg = "该用户不是你的好友", data = {}}}
    end
    friendmodel:black(friendid)
    return {c = "friend",m = "black", data = {errcode = 0, errmsg = "", data = {}}}
end

function friend.delblack(cmd)
    local friendid = cmd.data.friendid --好友ID
    if not friendid then
        return {c = "friend",m = "delblack", data = {errcode = 10000, errmsg = "请求异常,请稍后再试", data = {}}}
    end
    friendid = checkint(friendid)
    if not friendmodel:isfriend(friendid) then
        return {c = "friend",m = "delblack", data = {errcode = 10001, errmsg = "该用户不是你的好友", data = {}}}
    end
    friendmodel:delblack(friendid)
    return {c = "friend",m = "delblack", data = {errcode = 0, errmsg = "", data = {}}}
end

function friend.delete(cmd)
    local friendid = cmd.data.friendid --好友ID
    if not friendid then
        return {c = "friend",m = "delete", data = {errcode = 10000, errmsg = "请求异常,请稍后再试", data = {}}}
    end
    friendid = checkint(friendid)
    if not friendmodel:isfriend(friendid) then
        return {c = "friend",m = "delete", data = {errcode = 10001, errmsg = "该用户不是你的好友", data = {}}}
    end
    friendmodel:delete(friendid)
    return {c = "friend",m = "delete", data = {errcode = 0, errmsg = "", data = {}}}
end

function friend.sendmsg(cmd)
    local friendid = cmd.data.friendid
    friendid = checkint(friendid)
    if not friendmodel:isfriend(friendid) then
        return {c = "friend",m = "apply", data = {errcode = 10000, errmsg = "该用户不是你的好友", data = {}}}
    end
    local content = cmd.data.content
    if not content then
        return {c = "friend",m = "sendmsg",data = {errcode = 10001, errmsg = "请求异常, 请稍后再试!", data = { }}}
    end
    if content == "" then
        return {c = "friend",m = "sendmsg",data = {errcode = 10002, errmsg = "消息不能为空!", data = { }}}
    end
    local is_valid = skynet.call(".word_crab", "lua", "is_valid", content)
    if not is_valid then
        return {c = "user",m = "sendmsg",data = {errcode = 10003, errmsg = "存在违规词!", data = { }}}
    end
    local id = skynet.call(".id_service", "lua", "genid", "mail")
    assert(id~=nil, "id 获取失败")
    local msg = {
        id=id,
        tp="daily",
        temp="N",
        receiver=friendid,
        sender=usermodel:get_look_info(),
        params={},
        status=0,
        title=0,
        content=content,
        rewards={},
        created_at=dateutils.get_datetime()
    }
    skynet.send(".maild", "lua", "sendmail", friendid, msg)
    return {c = "friend",m = "sendmsg", data = {errcode = 0, errmsg = "", data = {}}}
end

return friend