local skynet        = require "skynet"
local netpack       = require "websocketnetpack"
local msgutils      = require "msgutils"
local cjson         = require "cjson"
local usermodel     = require "usermodel"
local bagmodel      = require "bagmodel"
local heromodel     = require "heromodel"
local settings      = require "settings"
local dateutils     = require "dateutils"
local equipmentlogic     = require "equipmentlogic"
local usermodel     = require "usermodel"
local heromodel     = require "heromodel"
local bagmodel     = require "bagmodel"
--装备控制器


local eqp = {}

--升级
function eqp.lvup(cmd)
    local heroid = cmd.data.heroid
    local tp = cmd.data.tp
    local lv = cmd.data.lv
    if not heroid or not tp or not lv then
        return {c = "eqp",m = "lvup", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end
    local eqps = heromodel:getequipment(heroid)
    assert(eqps ~= nil)
    local eqp = eqps[tp]
    assert(eqp ~= nil)
    local cur_lv = eqp:getlv()
    if cur_lv >= 4000 then
        return {c = "user",m = "lvup",data = {errcode = 10002, errmsg = "已升级到最高等级"}}
    end
    local new_lv = cur_lv + lv
    if new_lv > usermodel.lv then
        return {c = "eqp",m = "lvup", data = {errcode = 10002, errmsg = "装备等级不能大于主公等级"}}
    end
    local spend = equipmentlogic.lvupspend(cur_lv, new_lv)
    if bagmodel.jingtie < spend then
        return {c = "eqp",m = "lvup", data = {errcode = 10003, errmsg = "资源不足"}}
    end

    bagmodel:decrBagA("jingtie", spend)
    eqp:lvup(lv)
    -- DEBUG("发送给 client ")
    return {c = "eqp",m = "lvup", data = {errcode = 0, errmsg = "", data = {}}}
end


--一键升级
function eqp.lvupall(cmd)
    local heroid = cmd.data.heroid
    if not heroid then
        return {c = "eqp",m = "lvupall", data = {errcode = 10001, errmsg = "请求数据异常, 请稍后再试"}}
    end
    local jingtie = bagmodel.jingtie

    if jingtie <= 0 then
        return {c = "eqp",m = "lvupall", data = {errcode = 10002, errmsg = "资源不足"}}
    end

    local eqp = heromodel:getequipment(heroid)
    assert(eqp ~= nil)
    local lordlv = usermodel.lv
    if eqp.weapon.lv >= lordlv and eqp.cloth.lv >= lordlv and eqp.head.lv >= lordlv and eqp.horse.lv >= lordlv then
        return {c = "eqp",m = "lvupall", data = {errcode = 10003, errmsg = "没有可批量升级的装备"}}
    end

    local jingtie = bagmodel.jingtie
    local count, ret = equipmentlogic.calalllvup(jingtie, lordlv, eqp.weapon.lv, eqp.cloth.lv, eqp.head.lv, eqp.horse.lv)
    DEBUG("count = ", count, " jingtie = ", jingtie)
    bagmodel:decrBagA("jingtie", count)
    for k,v in pairs(ret) do
        eqp[k]:setlv(v)
    end

    return {c = "eqp",m = "lvupall", data = {errcode = 0, errmsg = "", data = {ret=ret}}}
end

--重生
function eqp.reborn(cmd)
    local heroid = cmd.data.heroid
    if not heroid then
        return {c = "eqp",m = "reborn",data = {errcode = 10001,errmsg = "请求异常, 请稍后再试!", data = { }}}
    end
    local hero = heromodel:gethero(heroid)
    if not hero then
        return {c = "eqp",m = "reborn",data = {errcode = 10002,errmsg = "武将获取失败, 请稍后再试!", data = { }}}
    end
    if hero.pos <= 0 then
        return {c = "eqp",m = "reborn",data = {errcode = 10003,errmsg = "武将不在阵上", data = { }}}
    end
    local jingtie = heromodel:calequipmentconsume(heroid)
    bagmodel:incrBagA("jingtie", jingtie)
    heromodel:equipmentreborn(heroid)
    return {c = "eqp",m = "reborn",data = {errcode = 0,data = { jingtie=jingtie }}}
end



return eqp