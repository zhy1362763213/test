local dailydealconf = require "dailydealconf"

local M = {}

function M.getdailydealconf()
    return dailydealconf
end

function M.getconf(id)
    return dailydealconf[tostring(id)]
end

function M.getdailydealreward(ids)

    local rewards = {}
    for _, id in ipairs(ids) do
        local rews = M.getconf(id).rewards
        for _, v in ipairs(rews) do
            table.insert(rewards, {key=v.key, value=v.value})
        end
    end
    -- local cardrewarddaily = M.getconf(id).card_reward_daily
    -- if #cardrewarddaily <= 0 then
    --     local rews = M.getconf(id).rewards
    --     for _, v in ipairs(rews) do
    --         table.insert(rewards, {key=item.key, value=v.value})
    --     end
    -- else
    --     for i,v in ipairs(cardrewarddaily) do
    --         local rews = M.getconf(v).rewards
    --         for _, v in ipairs(rews) do
    --             table.insert(rewards, {key=item.key, value=v.value})
    --         end
    --     end
    -- end
    return rewards
end

return M