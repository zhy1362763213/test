local vipconf = require "vipconf"

local M = {}

function M.getconf(lv)
    return vipconf[tostring(math.floor(lv))]
end


function M.getcoingetnum(lv)
    local cfg = M.getconf(lv)
    if not cfg then
        return 0
    end
    for i,v in ipairs(cfg.vip_benefit) do
        if v.key == "coin_get" then
            return v.value
        end
    end
    return 0
end

function M.getmarketrefreshnum(lv)
    local cfg = M.getconf(lv)
    if not cfg then
        return 0
    end
    for i,v in ipairs(cfg.vip_benefit) do
        if v.key == "market_refresh" then
            return v.value
        end
    end
    return 0
end


function M.getviplv(n)
    local t = {}
    for k,v in pairs(vipconf) do
        table.insert(t, {lv=v.key_id, num=v.price})
    end
    table.sort(t, function(a,b) return a.lv > b.lv end)
    for i,v in ipairs(t) do
        if n > v.num then
            return v.lv
        end
    end
    return 0
end

return M