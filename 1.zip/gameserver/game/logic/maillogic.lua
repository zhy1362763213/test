local dateutils = require "dateutils"
local M = {}

function M.getsysmailtemp()
end

return M