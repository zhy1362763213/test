local blackmarketconf        = require "blackmarketconf"
local blackmarketrefreshconf = require "blackmarketrefreshconf"
local M = {}


function M.getconf()
    return blackmarketconf
end

function M.getconfbyid(id)
    return blackmarketconf[tostring(id)]
end

function M.randomdiscount()
    local t = {}
    for k,v in pairs(blackmarketconf) do
        local pools = {}
        local discount = v.discount
        for _, v1 in ipairs(discount) do
            for i=1, v1.value do
                table.insert(pools, v1.key)
            end
        end
        for i=1,7 do
            pools = table.shuffle(pools)
        end
        local r = math.random(1, #pools)
        local rew = pools[r]
        t[k] = rew
    end
    return t
end


function M.getrefreshspeed(num)
    return blackmarketrefreshconf[tostring(checkint(num))].gold
end

return M