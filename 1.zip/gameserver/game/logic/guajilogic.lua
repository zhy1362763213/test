local guajishichangconf = require "guajishichangconf"
local guajidengjiconf   = require "guajidengjiconf"
local guajijinbiconf    = require "guajijinbiconf"
local guajiwupinconf    = require "guajiwupinconf"
local M = {}

function M.getguajishichangconf(t)
    for k,v in pairs(guajishichangconf) do
        if v.time == t then
            return v
        end
    end
end

function M.getguajidengjiconf(id)
    return guajidengjiconf[tostring(id)]
end

--计算挂机金币
function M.getguajicoin(id, long)
    local n = math.floor(long/5)
    return guajijinbiconf[tostring(id)].coin * n
end


function M.getrewardpools(rewards)
    local pools = {}
    for _,v in ipairs(rewards) do
        for i=1, v.gl * 100 do
            table.insert(pools, {key=v.key, value=v.value})
        end
    end
    for i=1,7 do
        pools = table.shuffle(pools)
    end
    return pools
end

--计算挂机奖励
function M.getguajirewards(ids, long)
    local rews = {}
    for _, id in ipairs(ids) do
        local cfg = M.getguajidengjiconf(checkint(id))
        for _, v in ipairs(cfg.clear_items) do
            rews[v.key] = true
        end
    end
    local id
    for k,v in pairs(guajiwupinconf) do
        if v.time_min >= long and v.time_max <= long then
            id = k
        end
    end
    local result = {}
    local t = 0 --秒
    for i=1, checkint(id) do
        local cfg = guajiwupinconf[tostring(i)]
        local l = math.ceil(cfg.time_max - cfg.time_min)
        local pools = M.getrewardpools(cfg.rewards)
        for j = 1, l do
            t = t + 5
            if t >= long then
                break
            end
            local r = math.random(1, 100)
            if pools[r] then
                local rew = pools[r]
                local k = rew.key
                if rews[k] and not result[k] or result[k] < rew.value then
                    result[k] = result[k] or 0
                    result[k] = result[k] + 1
                end
            end
        end
        if t >= long then
            break
        end
    end
    return result
end



return M