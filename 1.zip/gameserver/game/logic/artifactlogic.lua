local qiconf = require "qiconf"
local diaoyuconf = require "diaoyuconf"
local M = {}

function M.getconf(id)
    return qiconf[tostring(math.floor(id))]
end


function M.getdiaoyuconf(id)
    return diaoyuconf[tostring(math.floor(id))]
end

function M.getattrabs(k, id)
    local attrs = M.getconf(id).attrs
    for _,v in ipairs(attrs) do
        if v.type == k then
            return v.value
        end
    end
    return 0
end

function M.getattrext(k, id)
    local attrs = M.getconf(id).attrs
    for _,v in ipairs(attrs) do
        if v.type == k then
            return v.value
        end
    end
    return 0
end


function M.getlimitattrext(k, heroid, id)
    local attrs = M.getconf(id).limit_attrs
    local limit_heroid = M.getconf(id).limit_hero
    for _,v in ipairs(attrs) do
        if heroid == limit_heroid and v.type == k then
            return v.value
        end
    end
    return 0
end

--获取奖品奖池
local function getrewardpools(cfg)
    local pools = {}
    for _,v in ipairs(cfg) do
        for i=1, v.value * 100 do
            table.insert(pools, {tp=v.type, id=v.key, count=1})
        end
    end
    for i=1,7 do
        pools = table.shuffle(pools)
    end
    return pools
end

local function fishing1(num, curnum)
    local conf = M.getdiaoyuconf(1)
    local lastnum = num
    local rets ={}
    for i=1,num do
        lastnum = lastnum + 1
        if (lastnum-1)%10+1 == 10 then
            local pools = getrewardpools(conf.reward)
            local n = math.random(1, 100)
            local reward = pools[n]
            table.insert(rets, reward)
        else
            local pools = getrewardpools(conf.normalreward)
            local n = math.random(1, 100)
            local reward = pools[n]
            table.insert(rets, reward)
        end
    end
    return rets
end

local function fishing2(num, curnum)
    local conf = M.getdiaoyuconf(2)
    local lastnum = num
    local rets ={}
    for i=1,num do
        lastnum = lastnum + 1
        if (lastnum-1)%10+1 == 10 == 0 then
            local pools = getrewardpools(conf.reward)
            local n = math.random(1, 100)
            local reward = pools[n]
            table.insert(rets, reward)
        else
            local pools = getrewardpools(conf.normalreward)
            local n = math.random(1, 100)
            local reward = pools[n]
            table.insert(rets, reward)
        end
    end
    return rets
end

local handler = {
    ["lv1"] = fishing1,
    ["lv2"] = fishing2,
}

function M.fishing(lv, num, curnum)
    local f = handler["lv"..lv]
    return f(num, curnum)
end


return M