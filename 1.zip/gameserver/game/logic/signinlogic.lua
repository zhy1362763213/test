local qiandaoconf = require "qiandaoconf"
local qiriconf = require "qiriconf"


local M = {}

function M.getsigninconf(id)
    return qiandaoconf[tostring(checkint(id))]
end

function M.getsignin7conf(id)
    return qiriconf[tostring(checkint(id))]
end

return M