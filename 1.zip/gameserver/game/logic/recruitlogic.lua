local heroconf = require "heroconf"
require "functions"

--[[招募逻辑]]
local config = {
    hong=1,
    cheng=37,
    zi=62,
}


local function getallhero()
    local hong = {}
    local cheng = {}
    local zi = {}
    for heroid, v in pairs(heroconf) do
        heroid = math.floor(heroid)
        if v.color == 3 then
            table.insert(hong, heroid)
        end
        if v.color == 2 then
            if v.sex == 2 then
                if heroid == 313 or heroid == 210 then
                    table.insert(cheng, heroid)
                end
            else
                table.insert(cheng, heroid)
            end
        end
        if v.color == 1 and v.sex == 1 then
            table.insert(zi, heroid)
        end
    end
    for i=1,10 do
        hong = table.shuffle(hong)
    end
    for i=1,10 do
        cheng = table.shuffle(cheng)
    end
    for i=1,10 do
        zi = table.shuffle(zi)
    end
    return hong, cheng, zi
end


local function gethonghero()
    local hong = {}
    for heroid, v in pairs(heroconf) do
        heroid = math.floor(heroid)
        if v.color == 3 then
            table.insert(hong, heroid)
        end

    end
    for i=1,10 do
        hong = table.shuffle(hong)
    end
    return hong
end

local function getchenghero()
    local cheng = {}
    for heroid, v in pairs(heroconf) do
        heroid = math.floor(heroid)
        if v.color == 2 then
            if v.sex == 2 then
                if heroid == 313 or heroid == 210 then
                    table.insert(cheng, heroid)
                end
            else
                table.insert(cheng, heroid)
            end
        end
    end
    for i=1,10 do
        cheng = table.shuffle(cheng)
    end
    return cheng
end

local function getzihero()
    local zi = {}
    for heroid, v in pairs(heroconf) do
        heroid = math.floor(heroid)
        if v.color == 1 and v.sex == 1 then
            table.insert(zi, heroid)
        end
    end
    for i=1,10 do
        zi = table.shuffle(zi)
    end
    return zi
end

local func = {
    ["gethonghero"] = gethonghero,
    ["getchenghero"] = getchenghero,
    ["getzihero"] = getzihero,
}


local function getpools()
    local pools = {}
    for k,v in pairs(config) do
        for i=1,v do
            table.insert(pools, k)
        end
    end
    for i=1,10 do
        pools = table.shuffle(pools)
    end
    return pools
end

--招募1次
local function recruit1()
    -- math.randomseed(tostring(os.time()):reverse():sub(1, 6))
    local rewards = {}
    local pools = getpools()
    local n = math.random(1, 100)
    local color = pools[n]
    local count = 1
    if color == "zi" then
        count = 1
    elseif color == "cheng" then
        count = 4
    elseif color == "hong" then
        count = 8
    end
    local f = func["get"..color.."hero"]
    local heros = f()
    local n = math.random(1, #heros)
    local heroid = heros[n]
    table.insert(rewards, {heroid=heroid, count=count})
    return rewards
end

--招募10次
local function recruit10()
    -- math.randomseed(tostring(os.time()):reverse():sub(1, 6))
    local rewards = {}
    local h1, h2, h3 = getallhero()
    local n = math.random(1, #h1) --获取红将
    local heroid = h1[n]
    table.insert(rewards, {heroid=heroid, count=8})
    local pools = getpools()
    for i=1,9 do
        local n = math.random(1, 100)
        local color = pools[n]
        if color == "hong" then
            local n = math.random(1, #h1)
            local heroid = h1[n]
            table.insert(rewards, {heroid=heroid, count=8})
        elseif color == "cheng" then
            local n = math.random(1, #h2)
            local heroid = h2[n]
            table.insert(rewards, {heroid=heroid, count=3})
        elseif color == "zi" then
            local n = math.random(1, #h3)
            local heroid = h3[n]
            table.insert(rewards, {heroid=heroid, count=3})
        else
            assert(false, "not found")
        end
    end
    return rewards
end

local handler = {
    ["recruit1"] = recruit1,
    ["recruit10"] = recruit10,
}

local M = {}

function M.recruit(num)
    local f = handler["recruit"..num]
    assert(f ~= nil, "not found function")
    return f()
end

return M
