local daybuyconf = require "daybuyconf"
local itemidconf = require "itemidconf"

local M = {}

function M.getdaybuyconf(id)
    return daybuyconf[tostring(id)]
end

function M.getitemidconf(id)
    return itemidconf[tostring(id)]
end

function M.getdaybuyreward(id)
    local rewards = {}
    local params = M.getdaybuyconf(id).params
    for _, v in ipairs(params) do
        local items = M.getitemidconf(tostring(v.itemid))
        for _,item in ipairs(items) do
            if item.type == v.type then
                table.insert(rewards, {key=item.name, value=v.value})
            end
        end
    end
    return rewards
end

return M