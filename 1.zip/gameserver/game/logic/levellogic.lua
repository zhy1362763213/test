local battleconf = require "battleconf"

local M = {}

function M.getconf(level)
    return battleconf[tostring(math.floor(level))]
end

function M.getwavecoin(level)
    local cfg = M.getconf(level)
    return cfg.coin_wave*#cfg.monsters
end

return M