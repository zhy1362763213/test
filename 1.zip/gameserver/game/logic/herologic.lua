local skynet      = require "skynet"
local heroconf      = require "heroconf"
local heroattrconf    = require "heroattrconf"
local herolvspendconf    = require "herolvspendconf"
local heroorder     = require "heroorder"
local herostarext   = require "herostarext"
local herostarspend = require "herostarspend"
local herohaloconf  = require "herohaloconf"
local skill         = require "skill"
require "functions"
local M = {}

function M.getheroattrconf(heroid)
    for k,v in pairs(heroattrconf) do
        if heroid == v.hero_id then
            return v
        end
    end
    assert(false, "不应该走到这~~~~")
end

function M.getherolvspendconf(lv)
    return herolvspendconf[tostring(math.floor(lv))]
end

function M.getheroorderconf(stage)
    return heroorder[tostring(math.floor(stage))] or {}
end

function M.getherostarconf(star)
    return herostarext[tostring(math.floor(star))] or {}
end

function M.getheroskillconf(skillid)
    return skill[tostring(math.floor(skillid))]
end


function M.getherostarspendconf(star)
    return herostarext[tostring(math.floor(star))]
end

function M.getconf(heroid)
    local conf = heroconf[tostring(math.floor(heroid))]
    assert(conf~=nil)
    return conf
end

function M.randomzihero(t)
    t = t or {}
    local all = M.getallzijiang(t)
    local l = #all
    math.randomseed(tostring(os.time()):reverse():sub(1, 6))
    local a = math.random(1, l)
    return all[a]
end

function M.getallzijiang(t)
    local t1 = {}
    for heroid,v in pairs(heroconf) do
        heroid = math.floor(heroid)
        if v.color == 1 and not t[heroid] then
            if v.sex == 2 then
                table.insert(t1, heroid)
            else
                for i=1, 10 do
                    table.insert(t1, heroid)
                end
            end

        end
    end
    for i=1,10 do
        t1 = table.shuffle(t1)
    end
    return t1
end

function M.callvupspend(s, e)
    local spend = 0
    for i=s, e do
        spend = spend + M.getherolvspendconf(i).lv_spend
    end
    return spend
end

function M.getbornattr(heroid, k)
    return M.getconf(heroid)[k]
end

function M.getbornatk(heroid)
    return M.getconf(heroid).atk
end

function M.getborndef(heroid)
    return M.getconf(heroid).def
end

function M.getbornhp(heroid)
    return M.getconf(heroid).hp
end

function M.getbornspeed(heroid)
    return M.getconf(heroid).spd
end

function M.getlvupext(k, heroid)
    return M.getheroattrconf(heroid)[k] or 0
end

function M.getstageupattrext(k, stage)
    return M.getheroorderconf(stage)[k] or 0
end

function M.getstarupattrext(k, star)
    -- local ext = 0
    -- for i=1,star do
    --     ext = ext + M.getherostarconf(star)[k] or 0
    -- end
    -- return ext
    return M.getherostarconf(star)[k] or 0
end

function M.getskillext(k, heroid, stage, myskill)
    local n = 0
    local cfg = M.getconf(heroid)
    local skillk = "skill"
    if myskill.awake_active == 1 then
         skillk = "skillawake"
    end
    local skillid = cfg[skillk]
    if skillid then
        local cnf = M.getheroskillconf(skillid)
        if cnf and cnf.open_stage <= stage then
            local attrs = cnf.attrs
            if attrs then
                for i,v in ipairs(attrs) do
                    if v.type == k then
                        n = n + v.value
                    end
                end
            end
        end
    end
    for i=1,3 do
        local skillk = "passives"
        if myskill["awake_passive"..i] == 1 then
            local skillk = "passivesawake"
        end
        local skillid = cfg[skillk][i]
        if skillid then
            local cnf = M.getheroskillconf(skillid)
            if cnf and cnf.open_stage <= stage then
                local attrs = cnf.attrs
                if attrs then
                    for i,v in ipairs(attrs) do
                        if v.type == k then
                            n = n + v.value
                        end
                    end
                end
            end
        end
    end
    return n
end

--计算当前等级使用的金币总数
function M.calcurlvusecoin(lv)
    local n = 0
    for i=2, lv do
        n = n + M.getherolvspendconf(i).lv_spend
    end
    return n
end

--计算当前等级使用的进阶石总数
function M.calcurlvusejinjieshi(stage)
    local n = 0
    for i=1, stage do
        n = n + M.getheroorderconf(stage).order_spend
    end
    return n
end

--获取当前武将品阶
function M.getcolorbyheroid(heroid)
    local cfg = M.getconf(heroid)
    return cfg.color
end

--计算使用的卡片数量
function M.getusecardnum(star)
    return M.getherostarspendconf(star).cost_clip_num
end


function M.gethaloattrs(club, num)
    for k,v in pairs(herohaloconf) do
        if v.club == club and v.limit == num then
            return v.attrs
        end
    end
end

return M