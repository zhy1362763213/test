local towerconf = require "towerconf"
local towerreward = require "towerreward"
local itemidconf = require "itemidconf"

local M = {}

function M.getitemidconf(id)
    return itemidconf[tostring(id)]
end

function M.getrewards(id)
    local rewards = {}
    local params = towerconf[tostring(id)].bossrewards
    for _, v in ipairs(params) do
        table.insert(rewards, {key=v.key, value=v.value})
    end
    return rewards
end


function M.getboxrewards(id)
    local rewards = {}
    local params = towerreward[tostring(id)].towerrewards
    for _, v in ipairs(params) do
        table.insert(rewards, {key=v.key, value=v.value})
    end
    return rewards
end


return M