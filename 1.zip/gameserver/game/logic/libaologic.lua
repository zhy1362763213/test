local skynet       = require 'skynet'
local cjson        = require 'cjson'
local libaoconf    = require 'libaoconf'

require "functions"

-- local config = {
--     libao_coin={
--         [1]={
--             id=1,
--             type="coin",
--             min=4,
--             max=4,
--             value=1
--         },
--     },
--     libao_gold = {
--         [1]={
--             id=1,
--             type="gold",
--             min=128,
--             max=600,
--             value=0.92
--         },
--         [2]={
--             id=2,
--             type="gold",
--             min=601,
--             max=1288,
--             value=0.08
--         }
--     },
--     libao_jingtie = {
--         [1]={
--             id=1,
--             type="jingtie",
--             min=188,
--             max=998,
--             value=0.92
--         },
--         [2]={
--             id=2,
--             type="jingtie",
--             min=999,
--             max=1988,
--             value=0.08
--         }
--     },
--     libao_jinjieshi = {
--         [1]={
--             id=1,
--             type="jinjieshi",
--             min=88,
--             max=400,
--             value=0.92
--         },
--         [2]={
--             id=2,
--             type="jinjieshi",
--             min=401,
--             max=888,
--             value=0.08
--         }
--     },
--     libao_mengyanjingshi = {
--         [1]={
--             id=1,
--             type="mengyanjingshi",
--             min=38,
--             max=200,
--             value=0.92
--         },
--         [2]={
--             id=2,
--             type="mengyanjingshi",
--             min=201,
--             max=400,
--             value=0.08
--         }
--     },
--     libao_baiyu = {
--         [1]={
--             id=1,
--             type="baiyu",
--             min=38,
--             max=200,
--             value=0.92
--         },
--         [2]={
--             id=2,
--             type="baiyu",
--             min=201,
--             max=400,
--             value=0.08
--         }
--     },
--     libao_banshou = {
--         [1]={
--             id=1,
--             type="banshou",
--             min=68,
--             max=328,
--             value=0.92
--         },
--         [2]={
--             id=2,
--             type="banshou",
--             min=329,
--             max=668,
--             value=0.08
--         }
--     },
--     libao_jubaoding_lv1 = {
--         [1]={
--             id=1,
--             type="libao_gold",
--             min=1,
--             max=5,
--             value=0.1,
--         },
--         [2]={
--             id=2,
--             type="libao_coin",
--             min=3,
--             max=10,
--             value=0.3,
--         },
--         [3]={
--             id=3,
--             type="libao_jingtie",
--             min=3,
--             max=10,
--             value=0.3,
--         },
--         [4]={
--             id=4,
--             type="libao_jinjieshi",
--             min=3,
--             max=10,
--             value=0.3,
--         }
--     },
--     libao_jubaoding_lv2 = {
--         [1]={
--             id=1,
--             type="libao_baiyu",
--             min=1,
--             max=5,
--             value=0.1,
--         },
--         [2]={
--             id=2,
--             type="pifubi",
--             min=3,
--             max=10,
--             value=0.1,
--         },
--         [3]={
--             id=3,
--             type="libao_wujiang_hong2",
--             min=3,
--             max=10,
--             value=0.1,
--         },
--         [4]={
--             id=4,
--             type="libao_banshou",
--             min=3,
--             max=10,
--             value=0.2,
--         },
--         [5]={
--             id=5,
--             type="libao_mengyanjingshi",
--             min=5,
--             max=20,
--             value=0.5,
--         }
--     }
-- }

local function getpools(rewards)
    local pools = {}
    for k,v in ipairs(rewards) do
        for i=1, v.gl * 100 do
            table.insert(pools, v)
        end
    end
    for i=1, 7 do
        pools = table.shuffle(pools)
    end
    return pools
end

local M = {}

function M.getconf(tp)
    return libaoconf[tp]
end

function M.openlibao(tp, num)
    local cfg = M.getconf(tp)
    assert(cfg ~= nil, "配置获取失败")
    local pools = getpools(cfg.rewards)
    local rewards = {}
    for i=1, num do
        local n = math.random(1, 100)
        local item = pools[n]
        local count = math.random(item.min, item.max)
        local name = item.key
        table.insert(rewards, {tp="item", id=name, count=count})
    end
    return rewards
end


local function checkin(heroid, rewards)
    for i,v in ipairs(rewards) do
        if v.key == "card_"..heroid then
            return true
        end
    end
    return false
end

--万能礼包开启
function M.openlibao2(tp, num, heroid)
    -- local cfg = config[tp]
    local cfg = M.getconf(tp)
    assert(cfg ~= nil, "配置获取失败")
    local c = checkin(heroid, cfg.rewards)
    assert(c, "heioid错误")
    local rewards = {}
    table.insert(rewards, {tp="item", id="card_"..heroid, count=num})
    return rewards
end


return M
