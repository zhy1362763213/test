local achievementconf = require "achievementconf"
local achievementtasklist = require "achievementtasklist"
local M = {}

function M.getconf()
    return achievementconf
end


function M.gettaskconfbyid(id)
    return achievementtasklist[tostring(id)]
end

function M.gettask(achievement_id, taskid)
    achievement_id = checkint(achievement_id)
    taskid = checkint(taskid)
    for k,v in pairs(achievementtasklist) do
        if checkint(k) == taskid and v.achievement_id == achievement_id then
            return v
        end
    end
end

return M