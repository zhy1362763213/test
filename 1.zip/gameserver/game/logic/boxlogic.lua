local skynet       = require 'skynet'
local cjson        = require 'cjson'
local heroconf     = require 'heroconf'
local boxconf      = require 'boxconf'
local boxstageconf = require 'boxstageconf'

require "functions"

local seed = tostring(os.time()):reverse():sub(1, 7)
DEBUG("seed = ", seed)

math.randomseed(seed)

local function getallhero()
    local hong = {}
    local cheng = {}
    local zi = {}
    for heroid, v in pairs(heroconf) do
        heroid = math.floor(heroid)
        if v.color == 3 then
            table.insert(hong, heroid)
        end
        if v.color == 2 then
            if v.sex == 2 then
                table.insert(cheng, heroid)
            else
                for i=1,10 do
                    table.insert(cheng, heroid)
                end
            end
        end
        if v.color == 1 then
            if v.sex == 2 then
                table.insert(zi, heroid)
            else
                for i=1,10 do
                    table.insert(zi, heroid)
                end
            end
        end
    end
    for i=1,10 do
        hong = table.shuffle(hong)
    end
    for i=1,10 do
        cheng = table.shuffle(cheng)
    end
    for i=1,10 do
        zi = table.shuffle(zi)
    end
    return hong, cheng, zi
end


local function gethonghero()
    local hong = {}
    for heroid, v in pairs(heroconf) do
        heroid = math.floor(heroid)
        if v.color == 3 then
            table.insert(hong, heroid)
        end
    end
    for i=1,10 do
        hong = table.shuffle(hong)
    end
    return hong
end

local function getchenghero()
    local cheng = {}
    for heroid, v in pairs(heroconf) do
        heroid = math.floor(heroid)
        if v.color == 2 then
            if v.sex == 2 then
                table.insert(cheng, heroid)
            else
                for i=1,10 do
                    table.insert(cheng, heroid)
                end
            end
        end
    end
    for i=1,10 do
        cheng = table.shuffle(cheng)
    end
    return cheng
end

local function getzihero()
    local zi = {}
    for heroid, v in pairs(heroconf) do
        heroid = math.floor(heroid)
        if v.color == 1 then
            if v.sex == 2 then
                table.insert(zi, heroid)
            else
                for i=1,10 do
                    table.insert(zi, heroid)
                end
            end
        end
    end
    for i=1,10 do
        zi = table.shuffle(zi)
    end
    return zi
end


local function getpools(cfg)
    local pools = {}
    for k,v in pairs(cfg) do
        for i=1, v.gl * 100 do
            table.insert(pools, {name=v.name, val=v.val})
        end
    end
    for i=1,7 do
        pools = table.shuffle(pools)
    end
    return pools
end


local function getrewardpools(cfg)
    local pools = {}
    for _, v in ipairs(cfg) do
        local gl = v.gl
        for i=1, gl * 100 do
            table.insert(pools, v.v)
        end
    end
    for i=1,7 do
        pools = table.shuffle(pools)
    end
    return pools
end


local function open_lv1(num)
    local rets = {}
    local rewards = boxconf["1"].rewards
    for i=1, num do --抽几个箱子
        for j=1, #rewards do -- 一个箱子几个礼包
            local cfg = rewards[j]
            local pools = getpools(cfg)
            local n = math.random(1, #pools)
            local reward = pools[n]
            if reward.name == "coin" then
                local c_pools = getrewardpools(reward.val)
                local count = math.random(1, #c_pools)
                table.insert(rets, {tp="coin", count=count})
            elseif reward.name == "zi" then
                --获得紫将
                local heros = getzihero()
                local t = math.random(1, #heros)
                local heroid = heros[t]
                table.insert(rets, {tp="hero", heroid=heroid, count=1})
            else
                assert(false, "not found")
            end
        end
    end
    return rets
end

local function open_lv2(num)
    local rewards = boxconf["2"].rewards
    local rets = {}
    for i=1, num do --抽几个箱子
        for j=1, #rewards do -- 一个箱子几个礼包
            local cfg = rewards[j]
            local pools = getpools(cfg)
            local n = math.random(1, #pools)
            local reward = pools[n]
            if reward.name == "jingtie" then
                local c_pools = getrewardpools(reward.val)
                local count = math.random(1, #c_pools)
                table.insert(rets, {tp="jingtie", count=count})
            elseif reward.name == "zi" then
                local heros = getzihero()
                local t = math.random(1, #heros)
                local heroid = heros[t]
                table.insert(rets, {tp="hero", heroid=heroid, count=1})
            elseif reward.name == "cheng" then
                local heros = getchenghero()
                local t = math.random(1, #heros)
                local heroid = heros[t]
                table.insert(rets, {tp="hero", heroid=heroid, count=4})
            else
                assert(false, "not found")
            end
        end
    end
    return rets
end


local function open_lv3(num)
    local rewards = boxconf["3"].rewards
    local rets = {}
    for i=1, num do --抽几个箱子
        for j=1, #rewards do -- 一个箱子几个礼包
            local cfg = rewards[j]
            local pools = getpools(cfg)
            local n = math.random(1, #pools)
            local reward = pools[n]
            if reward.name == "jinjieshi" then
                local c_pools = getrewardpools(reward.val)
                local count = math.random(1, #c_pools)
                table.insert(rets, {tp="jinjieshi", count=count})
            elseif reward.name == "zi" then
                local heros = getzihero()
                local t = math.random(1, #heros)
                local heroid = heros[t]
                table.insert(rets, {tp="hero", heroid=heroid, count=1})
            elseif reward.name == "cheng" then
                local heros = getchenghero()
                local t = math.random(1, #heros)
                local heroid = heros[t]
                table.insert(rets, {tp="hero", heroid=heroid, count=4})
            elseif reward.name == "hong" then
                local heros = gethonghero()
                local t = math.random(1, #heros)
                local heroid = heros[t]
                table.insert(rets, {tp="hero", heroid=heroid, count=8})
            else
                assert(false, "not found")
            end
        end
    end
    return rets
end


local function open_lv4(num)
    local rewards = boxconf["4"].rewards
    local rets = {}
    for i=1, num do --抽几个箱子
        for j=1, #rewards do -- 一个箱子几个礼包
            local cfg = rewards[j]
            local pools = getpools(cfg)
            local n = math.random(1, #pools)
            local reward = pools[n]
            if reward.name == "jinjieshi" then
                local c_pools = getrewardpools(reward.val)
                local count = math.random(1, #c_pools)
                table.insert(rets, {tp="jinjieshi", count=count})
            elseif reward.name == "zi" then
                local heros = getzihero()
                local t = math.random(1, #heros)
                local heroid = heros[t]
                table.insert(rets, {tp="hero", heroid=heroid, count=1})
            elseif reward.name == "cheng" then
                local heros = getchenghero()
                local t = math.random(1, #heros)
                local heroid = heros[t]
                table.insert(rets, {tp="hero", heroid=heroid, count=4})
            elseif reward.name == "hong" then
                local heros = gethonghero()
                local t = math.random(1, #heros)
                local heroid = heros[t]
                table.insert(rets, {tp="hero", heroid=heroid, count=8})
            else
                assert(false, "not found")
            end
        end
    end
    return rets
end

local function open_lv5(num)
    local rewards = boxconf["5"].rewards
    local rets = {}
    for i=1, num do --抽几个箱子
        for j=1, #rewards do -- 一个箱子几个礼包
            local cfg = rewards[j]
            local pools = getpools(cfg)
            local n = math.random(1, #pools)
            local reward = pools[n]
            if reward.name == "gold" then
                local c_pools = getrewardpools(reward.val)
                local count = math.random(1, #c_pools)
                table.insert(rets, {tp="gold", count=count})
            elseif reward.name == "zi" then
                local heros = getzihero()
                local t = math.random(1, #heros)
                local heroid = heros[t]
                table.insert(rets, {tp="hero", heroid=heroid, count=1})
            elseif reward.name == "cheng" then
                local heros = getchenghero()
                local t = math.random(1, #heros)
                local heroid = heros[t]
                table.insert(rets, {tp="hero", heroid=heroid, count=4})
            elseif reward.name == "hong" then
                local heros = gethonghero()
                local t = math.random(1, #heros)
                local heroid = heros[t]
                table.insert(rets, {tp="hero", heroid=heroid, count=8})
            else
                assert(false, "not found")
            end
        end
    end
    return rets
end

local handler = {
    ["lv1"] = open_lv1,
    ["lv2"] = open_lv2,
    ["lv3"] = open_lv3,
    ["lv4"] = open_lv4,
    ["lv5"] = open_lv5,
}

local M = {}

function M.openbox(lv, num)
    local f = handler["lv"..lv]
    return f(num)
end

function M.getconfbylv(lv)
    return boxconf[tostring(lv)]
end

function M.getstageconf()
    return boxstageconf
end

function M.getstageconfbystage(stage)
    return boxstageconf[tostring(checkint(stage))]
end

function M.getrewards(score, stage)
    local rewards = {}
    local f = true
    while true do
        for k,v in pairs(boxstageconf) do
            if stage == v.id then
                if score >= v.limit then
                    score = score - v.limit
                    if v.id == 9 then
                        stage = 1
                    else
                        stage = stage + 1
                    end
                    table.insert(rewards, {tp="item", id=v.value, count=1})
                else
                    f = false
                    break
                end
            end
        end
        if not f then
            break
        end
    end
    return score, stage, rewards
end

return M
