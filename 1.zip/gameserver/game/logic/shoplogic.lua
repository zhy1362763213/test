local goldshopconf = require "goldshopconf"

local M = {}

function M.getconf(id)
    return goldshopconf[tostring(checkint(id))]
end


return M