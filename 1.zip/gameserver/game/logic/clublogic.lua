local clubresearchconf = require "clubresearchconf"
local researchconf = require "researchconf"
local clublevelconf = require "clublevelconf"


--[[
    work :1战士 2肉盾 3辅助 4法师 5刺客 6射手
    researchtype: 0基础科技  1高级科技
    researchorder: 1生命 2攻击力 3暴击 4格挡 5技能伤害 6速度 7体质 8心智
]]


--[[
    1生命 2攻击力 3暴击 4格挡 5技能伤害 6速度 7体质 8心智
    arrt1:生命
    arrt2:攻击力
    arrt3:
    arrt4:
    arrt5:
    arrt6:
    arrt7:
    arrt8:
    arrt9:
    arrt10:
    arrt11:
    arrt12:
    arrt13:
    arrt14:
    arrt15:
]]
local M = {}

function M.getconfbylv(lv)
    for _, v in pairs(clublevelconf) do
        if v.level == lv  then
            return v
        end
    end
end


local TYPEDEF = {
    hpext  = 1,
    atkext = 2,
    speedext = 6,
}

function M.getresearchtypeconf(work, researchtype)
    local t = {}
    for _,v in pairs(researchconf) do
        if v.work == work and v.researchtype == researchtype then
            table.insert(t, v)
        end
    end
    return t
end

function M.getclubresearchconf(researchid, lv)
    for _,v in pairs(clubresearchconf) do
        if v.id == researchid and v.researchlv == lv then
            return v
        end
    end
    assert(false, "not found")
end


function M.getclubresearchattrnum(work, researchtype, k, lv)
    local t = M.getresearchtypeconf(work, researchtype)
    local n = 0
    for i,v in ipairs(t) do
        local cfg = M.getclubresearchconf(v.id, lv[v.researchorder])
        if cfg.attrdesc1 == "attr"..TYPEDEF[k] then
            n = n + cfg.attrnum1
        end

        if cfg.attrdesc2 == "attr"..TYPEDEF[k] then
            n = n + cfg.attrnum2
        end
    end
    return n
end

return M