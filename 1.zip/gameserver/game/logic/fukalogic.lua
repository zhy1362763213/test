local cardconf = require "cardconf"

local M = {}

function M.getconf()
    return cardconf
end

function M.getconfbyid(id)
    return cardconf[tostring(math.floor(id))]
end

return M