local yanguanconf = require "yanguanconf"

local M = {}

function M.gettime(lv, n)
    local cfg = yanguanconf[tostring(lv)]
    local ts = cfg.time
    n = math.min(10, n)
    return ts[n]
end

local function getpools(rewards)
    local pools = {}
    for i,v in ipairs(rewards) do
        for i=1,v.gl do
            table.insert(pools, {key=v.key, value=v.value})
        end
    end
    for i=1,10 do
        pools = table.shuffle(pools)
    end

    return pools
end

function M.getrewards(lv)
    local cfg = yanguanconf[tostring(lv)]
    local n = cfg.number
    local rewards = cfg.reward
    local pools = getpools(rewards)
    local ret = {}
    for i=1, n do
        local r = math.random(1, #pools)
        local rew = pools[r]
        local a = math.random(1, #rew.value)
        local val = rew.value[a]
        table.insert(ret, {tp="item", id=rew.key, val=val})
    end
    return ret
end

return M