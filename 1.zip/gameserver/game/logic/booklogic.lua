local bookconf      = require "bookconf"
local qibookconf    = require "qibookconf"
local bookstageconf = require "bookstageconf"

local M = {}

--获取徽星数量
function M.getemblemstarnum(heroid, n)
    local cfg = bookconf[tostring(math.floor(heroid))]
    return cfg.tujian[n]
end

function M.getqiemblemstarnum(id, n)
    local cfg = qibookconf[tostring(math.floor(id))]
    return cfg.tujian[n]
end


function M.getcurbookstage(id)
    return bookstageconf[tostring(math.floor(id))]
end

function M.getbookstagenum(id)
    local nid = id + 1
    local a = bookstageconf[tostring(math.floor(id))]
    local b = bookstageconf[tostring(math.floor(nid))]
    assert(b~=nil, "无下一阶段")
    return b.stage - a.stage
end

return M