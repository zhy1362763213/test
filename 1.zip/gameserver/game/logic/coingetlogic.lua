local coingetconf = require "coingetconf"
local battleconf  = require "battleconf"
local M = {}


function M.getconf(lv)
    for k,v in pairs(coingetconf) do
        if v.viplv == lv then
            return v
        end
    end
end

--获取点金数值
function M.getcoingetnum(level)
    return battleconf[tostring(math.floor(level))].coin_dianjin
    -- if level <= 20 then
    --     return 0
    -- end
    -- if level <= 800 then
    --     return math.ceil(level/16.93) * 1000
    -- end
    -- if level >= 801 and level <= 4000 then
    --     return math.ceil((level - 800)/6.535) * 1000 + 47000
    -- end
    -- if level >= 4001 then
    --     return 538000
    -- end
end

return M