local bossloopconf      = require "bossloopconf"
local bossinfoconf      = require "bossinfoconf"
local bossrewardsconf   = require "bossrewardsconf"
local dateutils         = require "dateutils"

local M = {}

function M.getcurboss()
    local cur_week = dateutils.get_week()
    for k,v in pairs(bossloopconf) do
        if v.week == cur_week then
            return v.boss_id
        end
    end
end

function M.getbossrewards(h1, h2)
    local boss_id = M.getcurboss()
    local rewards = {}
    for k,v in pairs(bossrewardsconf) do
        if v.boss_id == boss_id and v.damage > h1 and v.damage <= h2 then
            local rews = v.rewards
            for i,v in ipairs(rews) do
                table.insert(rewards,  v)
            end
        end
    end
    return rewards
end


function M.getmaxdamage()
    local boss_id = M.getcurboss()
    local damage = 0
    for k,v in pairs(bossrewardsconf) do
        if v.boss_id == boss_id and v.damage > damage then
            damage = v.damage
        end
    end
    return damage
end

return M