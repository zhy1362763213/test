local lordlvspendconf    = require "lordlvspendconf"
local lordorderconf = require "lordorderconf"
local lordconf      = require "lordconf"
local lordlvconf    = require "lordlvconf"
local lordextconf   = require "lordextconf"
local utils         = require "utils"

local M = {}

function M.getconf(lv)
    return lordconf[tostring(lv)]
end

function M.getlvspendconf(lv)
    return lordlvspendconf[tostring(math.floor(lv))]
end

function M.getlordorderconf(stage)
    return lordorderconf[tostring(math.floor(stage))]
end


function M.callvupspend(s, e)
    local spend = 0
    for i=s, e do
        spend = spend + M.getlvspendconf(i).lv_spend
    end
    return spend
end

--判断是否需要进阶
function M.neetstageup(lv, n)
    for k,v in pairs(lordorderconf) do
        if lv < v.lord_lv and lv+n > v.lord_lv then
            return true
        end
    end
    return false
end

function M.getclk(lv)
    return utils.round(lordconf.clk + (lv * lordextconf.clk))
end

--计算攻击 (主公攻击=基础攻击+升级成长)
function M.getatk(lv)
    return utils.round(lordconf.atk + (lv * lordextconf.atk))
end

function M.gethp(lv)
    return utils.round(lordconf.hp + (lv * lordextconf.hp))
end

function M.getdef(lv)
    return utils.round(lordconf.def + (lv * lordextconf.def))
end


function M.getlordorderext(k, stage)
    local ext = M.getlordorderconf(stage)[k]
    assert(ext~=nil)
    return ext
end

return M