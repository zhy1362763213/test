local goldbuyconf = require "goldbuyconf"

local M = {}

function M.getgold(name)
    for i,v in pairs(goldbuyconf) do
        if v.item_name == name then
            return v.gold
        end
    end
    assert(false, "不存在的配置")
end

return M