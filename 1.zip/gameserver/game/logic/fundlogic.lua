local fundconf = require "fundconf"
local fundtaskconf = require "fundtaskconf"
local itemidconf   = require "itemidconf"

local M = {}

function M.getconf(id)
    return fundconf[tostring(math.floor(id))]
end

function M.gettaskconf(id)
    return fundtaskconf[tostring(math.floor(id))]
end

function M.getitemidconf(id)
    return itemidconf[tostring(math.floor(id))]
end

function M.getfundreward(id)
    local rewards = {}
    local rews = M.gettaskconf(id).rewards
    for _, v in ipairs(rews) do
        table.insert(rewards, v)
    end
    return rewards
end

return M