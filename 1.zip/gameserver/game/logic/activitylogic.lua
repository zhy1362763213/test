local weekheishiconf = require "weekheishiconf"
local weekbaoxiangconf = require "weekbaoxiangconf"
local weekbaoxiangshangchengconf = require "weekbaoxiangshangchengconf"
local weekzhaomuconf = require "weekzhaomuconf"
local weekzhaomushangchengconf = require "weekzhaomushangchengconf"
local duanwuleichongconf = require "duanwuleichongconf"
local duanwuxiangouconf = require "duanwuxiangouconf"
local duanwuduihuanconf = require "duanwuduihuanconf"


local M = {}

function M.getheishiconfbyid(id)
    return weekheishiconf[tostring(id)]
end

function M.getbaoxiangconfbyid(id)
    return weekbaoxiangconf[tostring(id)]
end

function M.getbaoxiangroundconf()
    local t = {}
    for k,v in pairs(weekbaoxiangconf) do
        if not t[v.value] or t[v.value] < v.points then
            t[v.value] = v.points
        end
    end
    return t
end

function M.getzhaomuroundconf()
    local t = {}
    for k,v in pairs(weekzhaomuconf) do
        if not t[v.value] or t[v.value] < v.points then
            t[v.value] = v.points
        end
    end
    return t
end

function M.getbaoxiangconfbyround(round)
    local t = {}
    for k,v in pairs(weekbaoxiangconf) do
        if v.value == round then
            table.insert(t, v)
        end
    end
    return t
end

function M.getzhaomuconfbyround(round)
    local t = {}
    for k,v in pairs(weekzhaomuconf) do
        if v.value == round then
            table.insert(t, v)
        end
    end
    return t
end

function M.getbaoxiangconf()
    return weekbaoxiangconf
end


function M.getbaoxiangshangchengconf()
    return weekbaoxiangshangchengconf
end

function M.getbaoxiangshangchengconfbyid(id)
    return weekbaoxiangshangchengconf[tostring(id)]
end


function M.getzhaomuconfbyid(id)
    return weekzhaomuconf[tostring(id)]
end

function M.getzhaomushangchengconf()
    return weekzhaomushangchengconf
end


function M.getzhaomushangchengconfbyid(id)
    return weekzhaomushangchengconf[tostring(id)]
end

function M.getduanwuxiangouconf()
    return duanwuxiangouconf
end

function M.getduanwuxiangouconfbyid(id)
    return duanwuxiangouconf[tostring(id)]
end

function M.getduanwuleichongconfbyid(id)
    return duanwuleichongconf[tostring(id)]
end

function M.getduanwuduihuanconfbyid(id)
    return duanwuduihuanconf[tostring(id)]
end

return M