local equipmentconf      = require "equipmentconf"
local equipmentlvconf    = require "equipmentlvconf"
local equipmentcolorconf = require "equipmentcolorconf"

local M = {}

local function getmaxitem(arr)
    local e = nil
    local m = nil
    for k, v in pairs(arr) do
        if m==nil then
            e = k
            m = v
        end
        if m < v then
            e = k
            m = v
        end
    end
    return e, m
end

local function tablesort(arr)
    local t = {}
    for k,v in pairs(arr) do
        table.insert(t, {k=k, lv=v})
    end
    table.sort( t, function(a,b) return (tonumber(a.lv) < tonumber(b.lv)) end )
    return t
end

local KYES = {weapon=1, cloth=2, head=3, horse=4}

function M.getlvconf(lv)
    return equipmentlvconf[tostring(math.floor(lv))]
end

function M.getid(color, type)
    for k,v in pairs(equipmentconf) do
        if v.color == color and v.type == type then
            return math.floor(k)
        end
    end
    assert(false, "not found id")
end


function M.lvupspend(lv1, lv2)
    local spend = 0
    for k,v in pairs(equipmentlvconf) do
        if v.key_id > lv1 and v.key_id <= lv2 then
            spend = spend + v.lv_spend
        end
    end
    return spend
end

function M.getlvupspendnum(lv)
    return M.getlvconf(lv).lv_spend
end


--计算一键升级
function M.calalllvup(count, lordlv, weaponlv, clothlv, headlv, horselv)
    local t = {weapon=weaponlv, cloth=clothlv, head=headlv, horse=horselv}
    local n = 0
    local mt = tablesort(t)

    for i, v in ipairs(mt) do
        for j=1, 3 do
            local max = mt[j + 1]
            for k, v in pairs(KYES) do
                if t[k] < max.lv then
                    for l = t[k] + 1,  max.lv do
                        local newlv = t[k]+1
                        local s = M.getlvupspendnum(newlv)
                        local c1 = n + s
                        if c1 > count then
                            return n, t
                        end
                        n = c1
                        t[k] = newlv
                    end
                end
            end
        end
    end
    local max_lv = mt[4].lv
    if lordlv > max_lv and n < count then
        for i= max_lv + 1, lordlv do
            for k,v in pairs(KYES) do
                local newlv = t[k]+1
                if newlv <= lordlv then
                    local s = M.getlvupspendnum(newlv)
                    local c1 = n + s
                    if c1 > count then
                        return n, t
                    end
                    n = c1
                    t[k] = newlv
                end
            end
        end
    end
    return n, t
end

function M.getatk(tp, lv)
    local attr = M.getlvconf(lv).atk_attr
    return attr[KYES[tp]]
end


function M.getdef(tp, lv)
    local attr = M.getlvconf(lv).def_attr
    return attr[KYES[tp]]
end

function M.gethp(tp, lv)
    local attr = M.getlvconf(lv).hp_attr
    return attr[KYES[tp]]
end

function M.getcolorconf(lv)
    for k,v in pairs(equipmentcolorconf) do
        if lv >= v.min and lv <= v.max then
            return v
        end
    end
end

function M.getcolor(lv)
    for k,v in pairs(equipmentcolorconf) do
        if lv >= v.min and lv <= v.max then
            return math.floor(k)
        end
    end
end

function M.getsetattr(color, setnum)
    local conf = equipmentcolorconf[tostring(color)]
    local attrs = conf.attrs
    if not attrs then
        return {}
    end
    return attrs[tostring(setnum)]
end


function M.calcurlvusejingtie(lv)
    local n = 0
    for i=1, lv - 1 do
        n = n + M.getlvupspendnum(i)
    end
    return n
end

return M