local xiangouconf = require "xiangouconf"

local M = {}

function M.getconf()
    return xiangouconf
end

function M.getconfbyid(id)
    return xiangouconf[tostring(id)]
end

return M