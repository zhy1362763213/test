local skynet     = require "skynet"
local cjson      = require "cjson"
local datacenter = require "skynet.datacenter"
local cluster    = require "skynet.cluster"
local settings   = require "settings"


skynet.start(function()

    skynet.error("Gameserver start server")
    local node_name  = skynet.getenv("node_name")
    INFO("-----GameServer-----", node_name, " will begin")
    local cfg = settings.nodes[tostring(node_name)]
    skynet.newservice("debug_console", cfg.console_port)

    skynet.uniqueservice("usercenterd", cfg.node_name)
    skynet.uniqueservice("clubcenterd", cfg.node_name)
    skynet.uniqueservice("msgcenterd", cfg.node_name)

    skynet.uniqueservice("word_crab", settings.word_crab_file)
    skynet.uniqueservice("dbproxy", cfg.node_name)
    skynet.uniqueservice("consumer", cfg.node_name)
    skynet.uniqueservice("producer", cfg.node_name)
    skynet.uniqueservice("id_service", cfg.node_name)
    skynet.uniqueservice("taskd", cfg.node_name)
    skynet.uniqueservice("orderd", cfg.node_name)
    skynet.uniqueservice("ordermqd", cfg.node_name)
    skynet.uniqueservice("coingetd", cfg.node_name)
    skynet.uniqueservice("signind", cfg.node_name)
    skynet.uniqueservice("daybuyd", cfg.node_name) --积天好礼
    skynet.uniqueservice("fundd", cfg.node_name) --基金
    skynet.uniqueservice("fukad", cfg.node_name) --福卡
    skynet.uniqueservice("dailydeald", cfg.node_name)
    skynet.uniqueservice("limitshopd", cfg.node_name)
    skynet.uniqueservice("friendd", cfg.node_name)
    skynet.uniqueservice("achievementd", cfg.node_name)
    skynet.uniqueservice("arenad", cfg.node_name)
    skynet.uniqueservice("blackmarketd", cfg.node_name)
    skynet.uniqueservice("guajid", cfg.node_name)
    skynet.uniqueservice("maild", cfg.node_name)
    skynet.uniqueservice("huobad", cfg.node_name)
    skynet.uniqueservice("coded", cfg.node_name)
    skynet.uniqueservice("vipd", cfg.node_name)
    skynet.uniqueservice("activityd", cfg.node_name)
    skynet.uniqueservice("redisd", cfg.node_name)
    skynet.uniqueservice("msgd", cfg.node_name)
    skynet.uniqueservice("bossd", cfg.node_name)
    skynet.uniqueservice("towerd", cfg.node_name)
    skynet.uniqueservice("invited", cfg.node_name)

    local watchdog = skynet.newservice("watchdog", settings.appname)

    skynet.call(watchdog, "lua", "start", {
        port = cfg.gate_port_ws,
        maxclient = cfg.max_client,
        nodelay = true,
    })
    cluster.open(node_name)
    skynet.exit()
end)
