-- This file will execute before every lua service start
-- See config

print("PRELOAD", ...)
PROJ_ROOT="../loginserver"

require "logger_api"
require "inspect_api"
require "functions"

math.randomseed(tostring(os.time()):reverse():sub(1, 6))

collectgarbage()