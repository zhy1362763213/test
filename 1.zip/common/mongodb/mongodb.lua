local skynet = require "skynet"
local mongo = require "skynet.db.mongo"
local bson = require "bson"


local mongodb = {}
mongodb.__index = mongodb

function mongodb:start(conf)
    local host = conf.host
    local port = conf.port
    local db_name = conf.db_name
    local db_client = mongo.client({host = host, port = port})
    local db = db_client[db_name]

    local o = {db = db}
    setmetatable(o, mongodb)
    return o
end

function mongodb:findOne(cname, selector, field_selector)
    return self.db[cname]:findOne(selector, field_selector)
end

function mongodb:find(cname, selector, field_selector, sort, skip, limit)
    local cursor = self.db[cname]:find(selector, field_selector)
    if sort then
        cursor:sort(sort)
    end
    if skip then
        cursor:skip(skip)
    end
    if limit then
        cursor:limit(limit)
    end
    local result = {}
    while cursor:hasNext() do
        local ret = cursor:next()
        if type(ret._id) ~= "number" then
            ret._id = nil
        end
        table.insert(result, ret)
    end
    return result
end

function mongodb:aggregate(cname, operation)
    return self.db[cname]:aggregate(operation)
end

local function db_help(db, cmd, cname, ...)
    local c = db[cname]
    c[cmd](c, ...)
    local r = db:runCommand('getLastError')
    local ok = r and r.ok == 1 and r.err == bson.null
    if not ok then
        ERROR("db_help failed: ", r.err, cname, ...)
    end
    return ok, r.err
end

function mongodb:update(cname, selector, update, upsert)
    local db = self.db
    local collection = db[cname]

    collection:update(selector, update, upsert)
    local r = db:runCommand("getLastError")
    if r.err ~= bson.null then
        ERROR("mongodb update error-> ", cname, " selector ", selector, " err:", r.err)
        return false, r.err
    end

    if r.n <= 0 then
        ERROR("mongodb update-> ", cname, " selector ", selector, " failed")
    end

    return true, r.err
end

function mongodb:updateMany(cname, selector, update, upsert)
    local db = self.db
    local collection = db[cname]

    collection:update(selector, update, upsert, true)
    local r = db:runCommand("getLastError")
    if r.err ~= bson.null then
        ERROR("mongodb updateMany error-> ", cname, " selector ", selector, " err:", r.err)
        return false, r.err
    end

    if r.n <= 0 then
        ERROR("mongodb updateMany-> ", cname, " selector ", selector, " failed")
    end

    return true, r.err
end

function mongodb:insert(cname, data)
    return db_help(self.db, "safe_insert", cname, data)
end

function mongodb:batch_insert(cname, data)
    return db_help(self.db, "batch_insert", cname, data)
end

function mongodb:delete(cname, selector)
    return db_help(self.db, "delete", cname, selector)
end

function mongodb:incr(key)
    local cname = "tb_key"
    local ret = self:findOne(cname, {key=key})
    local id = 0
    if ret then
        id = ret.uuid
    end
    id = id + 1
    ret = self:update(cname, {key=key}, {key=key, uuid=id}, true)
    assert(ret)
    assert(id)
    return id
end



return mongodb