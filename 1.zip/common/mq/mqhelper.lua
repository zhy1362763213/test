local skynet = require "skynet"
local settings = require "settings"
local mongohelper = require "mongohelper"
local M = {}

function M.exec(cmd, uid, ...)
    if settings.save_policy == "sync" then
        local ok = mongohelper.exec(cmd, ...)
        -- DEBUG("exec ok------>", ok)
        return ok
    else
        return skynet.call(".producer", "lua", "lpush", cmd, uid, ...)
    end
end

return M
