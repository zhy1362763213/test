local skynet = require "skynet"
require "skynet.manager"
local setting_template = require "settings"

local skynet_node_name = ...

local CMD = {}
local pool = {}

local maxconn
local function getconn(uid)
    local db
    if not uid or maxconn == 1 then
        db = pool[1]
    else
        db = pool[(uid - 1) % maxconn + 1]
    end
    assert(db)
    return db
end

local function call_redis_slave(addr, cmd, ...)
    return skynet.call(addr, "lua", cmd, ...)
end


local function start()
    local settings = setting_template.db_cnf[skynet_node_name]
    INFO("redismq producer 启动", skynet_node_name, inspect(settings))
    maxconn = tonumber(settings.redismq_maxinst) or 1
    for i = 1, maxconn do
        local producer_slave = skynet.newservice("producer_slave", i)
        skynet.call(producer_slave, "lua", "start", settings.redismq_cnf)
        table.insert(pool, producer_slave)
    end
end


function CMD.lpush(cmd, uid, table_name, cname, datas, conds)
    local db = getconn(uid)
    local retsult = call_redis_slave(db, "lpush", cmd, table_name, cname, datas, conds)
    return retsult
end

skynet.start(function()
    start()

    skynet.dispatch("lua", function(_, _, cmd, ...)
        local f = assert(CMD[cmd], cmd .. "not found")
        skynet.retpack(f(...))
    end)

    skynet.register("." .. SERVICE_NAME)
end)