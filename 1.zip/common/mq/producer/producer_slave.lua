local skynet = require "skynet"
require "skynet.manager"
local redis = require "skynet.db.redis"
local settings = require "settings"
local cjson    = require "cjson"
local index = ...


local key = settings.mq_key..index
local CMD = {}
local db = nil

local inc = 0
local workerId = math.floor(index)

local function genid()
    inc = inc + 1
    local d = os.date("*t")
    local s = string.format("%04d%02d%02d%02d%02d%02d%03d%08d",d.year,d.month,d.day,d.hour,d.min,d.sec,workerId,inc)
    return s
end

function CMD.start(cnf)
    local ok, d = pcall(redis.connect, cnf)
    if ok then
        db = d
    else
        ERROR("---redis connect error---", inspect(cnf) )
        error("---redis connect error---")
    end
    skynet.fork(function()
        while true do
            db:ping()
            skynet.sleep(1000)
        end
    end)
end

function CMD.lpush(cmd, table_name, cname, data, conds)
    local param={
        cmd=cmd,
        table_name=table_name,
        cname=cname,
        tp='mq',
        uuid=genid(),
        data=data,
        conds=conds,
    }
    local retsult = db:lpush(key,  cjson.encode(param))
    return retsult
end

skynet.start(function()
    skynet.dispatch("lua", function(_, _, cmd, ...)
        local f = assert(CMD[cmd], cmd .. "not found")
        skynet.retpack(f(...))
    end)
end)