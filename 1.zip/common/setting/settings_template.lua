local settings = {}

settings.debug = true

settings.appname = "leshusanguo" --app name

settings.word_crab_file = '../common/word_crab/words.txt'

settings.protocol_type = "json" --msgpack or json

settings.save_policy = "async" --sync or async

settings.mini_conf = {
    appid  = "",
    secret = "",
}

settings.h5_conf = {
    appid  = "",
    secret = "",
}

settings.mch_conf = {
    mch_id  = "",
    key     = "",
}

settings.wx_notify_url = ""

-- 登陆认证服
settings.login_conf = {
    node_name                   = "loginserver",
    console_port                = 10800,
    login_port_http             = 8002,   --(暴露) 登陆认证端口
    login_port_tcp              = 8001,   --(暴露) 登录认证端口
    login_slave_count           = 8,      --登陆认证代理个数
    api_server_ca               = "hDJ^54D@!&DH*Sdh18(Sahjig123",
    max_client                  = 6000
}


-- 游戏服务配置
settings.nodes = {

        gameserver1 = {
            -- 网络配置
            server_no           = 1,  --服务器编号
            node_name           = "gameserver1",  --
            console_port        = 10801,    --
            host                = "0.0.0.0",-- 需要手动修改
            gate_port_tcp       = 8888,    --(暴露 网关端口 TCP)
            gate_port_ws        = 8889,    --(暴露 网关端口 WS)
            gate_port_http      = 11001,
            max_client          = 6000,
            nodelay             = true,
            api_slave_count     = 10,
        },

        gameserver2 = {
            -- 网络配置
            server_no           = 2,  --服务器编号
            node_name           = "gameserver2",  --
            console_port        = 10801,    --
            host                = "0.0.0.0",-- 需要手动修改
            gate_port_tcp       = 8888,    --(暴露 网关端口 TCP)
            gate_port_ws        = 8889,    --(暴露 网关端口 WS)
            gate_port_http      = 11001,
            max_client          = 6000,
            nodelay             = true,
            api_slave_count     = 10,
        },
    }

if settings.debug then
    --db 配置
    settings.db_cnf = {
        loginserver = {
            dbproxy = {"mongodb", "redisdb"},
            redisdb_maxinst = 10,
            redisdb_cnf = {
                host = "192.168.3.15",
                port = 6379,
                db = 0,
            },
            mongodb_maxinst = 8,
            mongodb_cnf = {
                host = "192.168.3.15",
                port = "27017",
            },
            mysqldb_maxinst = 8,
            mysqldb_cnf = {
                ip = '192.168.3.15',
                port = 3306,
                user = "root",
                password = "123456",
                db = "sanguo"
            },
        },

        gameserver1 = {
            dbproxy = {"mongodb", "redisdb"},
            redisdb_maxinst = 10,
            redisdb_cnf = {
                host = "192.168.3.15",
                port = 6379,
                db = 0,
            },
            redismq_maxinst = 10,
            redismq_cnf = {
                host = "192.168.3.15",
                port = 6379,
                db = 0,
            },
            mongodb_maxinst = 8,
            mongodb_cnf = {
                host = "192.168.3.15",
                port = "27017",
            },
            mysqldb_maxinst = 8,
            mysqldb_cnf = {
                ip = "192.168.3.15",
                port = 3306,
                user = "root",
                password = "123456",
                db = "sanguo"
            },
        },
    }
else
    --db 配置
    settings.db_cnf = {
        loginserver = {
            dbproxy = {"mongodb", "redisdb"},
            redisdb_maxinst = 10,
            redisdb_cnf = {
                host = "your_local_ip",
                port = 63791,
                db = 0,
            },
            mongodb_maxinst = 10,
            mongodb_cnf = {
                host = "your_local_ip",
                port = 32787,
            },
            mysqldb_maxinst = 10,
            mysqldb_cnf = {
                ip = 'your_local_ip',
                port = 33061,
                user = "root",
                password = "admin123456",
                db = "leshusanguo"
            },
        },

        gameserver1 = {
            dbproxy = {"mongodb", "redisdb"},
            redisdb_maxinst = 10,
            redisdb_cnf = {
                host = "your_local_ip",
                port = 63791,
                db = 0,
            },
            redismq_maxinst = 10,
            redismq_cnf = {
                host = "your_local_ip",
                port = 63801,
                db = 0,
            },
            mongodb_maxinst = 10,
            mongodb_cnf = {
                host = "your_local_ip",
                port = 32787,
            },
            mysqldb_maxinst = 10,
            mysqldb_cnf = {
                ip = "your_local_ip",
                port = 33061,
                user = "root",
                password = "admin123456!",
                db = "sanguo"
            },
        },
    }
end


return settings
