local M = {}

local mysqldbx = require "dbproxy.mysqldbx"


function M.loaduser(id)
    local sql = string.format("select * from `sg_user` where id = %d", id)
    return mysqldbx.query(sql)
end

return M
