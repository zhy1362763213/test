local skynet = require "skynet"
require "skynet.manager"
local mysql = require "skynet.db.mysql"
local sql_template = require "sql_template"

local CMD = {}
local db


function CMD.start(conf)
    local function on_connect(db)
        db:query("set charset utf8mb4");
    end

    db = mysql.connect{
        host=conf.ip,
        port=conf.port,
        database=conf.db,
        user=conf.user,
        password=conf.password,
        charset="utf8mb4",
        max_packet_size = 1024 * 1024,
        on_connect = on_connect
    }
    if not db then
        error("mysql connect fail")
    end
    skynet.fork(function()
        while true do
            db:ping()
            skynet.sleep(300)
        end
    end)
end

function CMD.query(sql)
    return db:query(sql)
end

skynet.start(function()
    skynet.dispatch("lua", function(_, _, cmd, ...)
        local f = assert(CMD[cmd], cmd .. "not found")
        skynet.retpack(f(...))
    end)
end)