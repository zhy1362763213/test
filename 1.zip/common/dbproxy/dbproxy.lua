local skynet = require "skynet"
require "skynet.manager"
local settings = require "settings"

local skynet_node_name = ...

local CMD = {}


local function start()
    local conf = settings.db_cnf[skynet_node_name]
    for _, proxy in ipairs(conf.dbproxy) do
        skynet.uniqueservice(proxy .. "pool", skynet_node_name)
    end
end

skynet.start(function()
    start()
    skynet.dispatch("lua", function(_, _, cmd, ...)
        local f = assert(CMD[cmd], cmd .. "not found")
        skynet.retpack(f(...))
    end)
    skynet.register('.' .. SERVICE_NAME)
end)