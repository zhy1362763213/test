local cjson     = require "cjson"
local settings  = require("settings")
local http      = require("http.httpc")
local sign      = require "sign"

local header = {
    ["content-type"] = "application/json"
}

local DEBUG = settings.debug

local M = {}


function M.getBalance(params)
    local host = "https://api.weixin.qq.com"
    local url = "/cgi-bin/midas/getBalance?access_token="..access_token
    if DEBUG then
        url = "/cgi-bin/midas/sandbox/getBalance?access_token="..access_token
    end
   local args = {
        openid      = params.openid,-- 用户唯一标识
        appid       = params.appid,            -- 小游戏appID
        offer_id    = params.offer_id,   -- 米大师分配offer_id
        zone_id     = params.zone_id or "1",                           -- 游戏服务器大区
        pf          = params.pf or "android",                     -- 平台
        ts          = os.time(),                        -- 时间
        amt         = params.payment,                           -- 游戏币
        bill_no     = params.order_no,                        -- 订单号
    }
    args.sig = sign.hash_hmac_256(args, settings.mini_conf.secret); -- 计算签名
    local statuscode, resp_str = http.request("POST", host, url, {}, header, cjson.encode(args))
    if statuscode ~= 200 then
        ERROR("weixin midas getBalance statuscode failed = ", statuscode)
        error("weixin midas getBalance statuscode failed")
    end

    local ok, resp = pcall(cjson.decode, resp_str)
    if not ok then
        ERROR("weixin midas getBalance response = ", resp_str)
        error("weixin midas getBalance response error")
    end
    return resp
end


function M.pay(params)

    local host = "https://api.weixin.qq.com"
    local url = "/cgi-bin/midas/pay?access_token="..access_token
    if DEBUG then
        url = "/cgi-bin/midas/sandbox/pay?access_token="..access_token
    end
    local args = {
        openid      = params.openid,-- 用户唯一标识
        appid       = params.appid,            -- 小游戏appID
        offer_id    = params.offer_id,   -- 米大师分配offer_id
        zone_id     = params.zone_id or "1",                           -- 游戏服务器大区
        pf          = params.pf or "android",                     -- 平台
        ts          = os.time(),                        -- 时间
        amt         = params.payment,                           -- 游戏币
        bill_no     = params.order_no,                        -- 订单号
    }
    args.sig = sign.hash_hmac_256(args, params.secret); -- 计算签名
    local statuscode, resp_str = http.request("POST", host, url, {}, header, cjson.encode(args))
    if statuscode ~= 200 then
        ERROR("weixin midas pay statuscode failed = ", statuscode)
        error("weixin midas pay statuscode failed")
    end

    local ok, resp = pcall(cjson.decode, resp_str)
    if not ok then
        ERROR("weixin midas pay response = ", resp_str)
        error("weixin midas pay response error")
    end
    return resp
end

return M
