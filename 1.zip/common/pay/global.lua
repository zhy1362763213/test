local cjson     = require "cjson"
local settings  = require("settings")
local http      = require("http.httpc")

local host = "https://api.weixin.qq.com"

local cache = {
    tokens = {},
    tickets = {},
}

local function requestAccessToken(appid, secret)

    local url = "/cgi-bin/token?grant_type=client_credential&appid="..appid.."&secret="..secret
    local statuscode, resp_str = http.get(host, url, {})
    if statuscode ~= 200 then
        error("requestAccessToken statuscode failed")
    end
    local ok, resp = pcall(cjson.decode, resp_str)
    if ok then
        if not resp.errcode then
            cache.tokens[appid] = {
                token   = resp.access_token,
                exires  = skynet.time() + resp.expires_in,
            }
        else
            error(resp_str)
        end
    else
        error(resp_str)
    end
end

function _M.getAccessToken(appid, secret)
    assert(appid and secret)
    local token = cache.tokens[appid]
    DEBUG("token = ", DUMP(token))

    if not token or skynet.time() > token.exires then
        requestAccessToken(appid, secret)
        return cache.tokens[appid].token
    end
    return token.token
end

return _M