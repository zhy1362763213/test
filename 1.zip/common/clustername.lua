dataserver     =   "0.0.0.0:2529"

loginserver     =   "0.0.0.0:2530"

gameserver1     =   "0.0.0.0:2531"
