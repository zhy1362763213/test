local M = {}

M.loaduser_sql = "select * from `sg_user` where id = %d"

return M