local M = require"settings_template"

M.mongodb_tb = {
    game = "game",
}

M.server_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "server_config",
}

M.user_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "user",
}

M.artifact_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "artifact",
}

M.user_login_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "user_login",
}

M.account_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "account",
}

M.bag_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "bag",
}

M.bag_log_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "bag_log",
}

M.hero_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "hero",
}

M.sign_log_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "sign_log",
}

M.recharge_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "recharge_order",
}

M.fund_log_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "fund_log",
}


M.daily_log_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "daily_log",
}

M.friend_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "friend",
}

M.club_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "club",
}

M.club_member_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "club_member",
}

M.mail_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "mail",
}

M.saltpot_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "user_saltpot",
}

M.friend_apply_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "friend_apply",
}

M.recruitmsg_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "recruitmsg_log",
}

M.clubmsg_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "clubmsg_log",
}

M.arenamsg_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "arenamsg_log",
}

M.baifumsg_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "baifumsg_log",
}

M.arena_log_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "arena_log",
}

M.game_code_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "game_code",
}

M.game_server_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "game_server",
}

M.server_item_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "server_item",
}

M.activity_config_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "activity_config",
}

M.tower_log_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "tower_log",
}

M.agent_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "agent",
}

M.code_exchange_mongodb_key = {
    tname = M.mongodb_tb.game,
    cname = "code_exchange_log",
}

M.mq_key = M.appname.."_queue_"

M.mq_key_backup = M.appname.."_queuebackup_"

M.mail_queue_key = M.appname..":mailreward:queue"

M.mail_queue_key_backup = M.appname..":mailreward:queuebackup"

-- 暴露给客户端的连接信息 (外网IP)
if M.debug then
    M.nodes['gameserver1'].host = "192.168.3.15"
else
    M.nodes['gameserver1'].host = "you_ip"
end

return M

