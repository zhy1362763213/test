local keysutils={}

function keysutils.user_login_key(appname, uid)
    return string.format("%s:user:login:%s", tostring(appname), tostring(uid))
end

function keysutils.user_guaji_info_key(appname, uid)
    return string.format("%s:user:guaji:info:%s", tostring(appname), tostring(uid))
end

function keysutils.user_guaji_reward_key(appname, uid)
    return string.format("%s:user:guaji:reward:%s", tostring(appname), tostring(uid))
end

function keysutils.user_achievement_key(appname, uid)
    return string.format("%s:user:achievement:list:%s", tostring(appname), tostring(uid))
end

function keysutils.user_achievement_complete_key(appname, uid)
    return string.format("%s:user:achievement:complete:list:%s", tostring(appname), tostring(uid))
end

function keysutils.user_signin7_key(appname, uid)
    return string.format("%s:user:signin7:%s", tostring(appname), tostring(uid))
end

function keysutils.user_signin_key(appname, uid)
    return string.format("%s:user:signin:%s", tostring(appname), tostring(uid))
end

function keysutils.user_task_num_key(appname, uid, day)
    return string.format("%s:task:complete:num:%s:%s", tostring(appname), tostring(uid), tostring(day))
end

function keysutils.user_task_list_key(appname, uid, day)
    return string.format("%s:task:list:%s:%s", tostring(appname), tostring(uid), tostring(day))
end

function keysutils.user_day_taskscore_key(appname, uid, day)
    return string.format("%s:task:dayscore:%s:%s", tostring(appname), tostring(uid), tostring(day))
end

function keysutils.user_week_taskscore_key(appname, uid, week)
    return string.format("%s:task:weekscore:%s:%s", tostring(appname), tostring(uid), tostring(week))
end

function keysutils.user_daily_task_key(appname, uid, day)
    return string.format("%s:task:dailytask:%s:%s", tostring(appname), tostring(uid), tostring(day))
end

function keysutils.user_weekly_task_key(appname, uid, week)
    return string.format("%s:task:weeklytask:%s:%s", tostring(appname), tostring(uid), tostring(week))
end

function keysutils.boss_rank_key(appname, server, day)
    return string.format("%s:everyday:boss:%s:%s", tostring(appname), tostring(server), tostring(day))
end

function keysutils.user_coinget_key(appname, uid, day)
    return string.format("%s:user:coinget:%s:%s", tostring(appname), tostring(uid),  tostring(day))
end

function keysutils.user_daybuycount_key(appname, uid)
    return string.format("%s:user:daybuycount:%s", tostring(appname), tostring(uid))
end

function keysutils.user_fund_key(appname, uid)
    return string.format("%s:user:fund:%s", tostring(appname), tostring(uid))
end

function keysutils.user_buydailydeal_key(appname, uid)
    return string.format("%s:user:buydailydeal:%s", tostring(appname), tostring(uid))
end

function keysutils.user_receivedailydeal_key(appname, uid)
    return string.format("%s:user:receivedailydeal:%s", tostring(appname), tostring(uid))
end

function keysutils.user_buyfuka_key(appname, uid)
    return string.format("%s:user:buyfuka:%s", tostring(appname), tostring(uid))
end

function keysutils.user_receivefuka_key(appname, uid, day)
    return string.format("%s:user:receivefuka:%s:%s", tostring(appname), tostring(uid), tostring(day))
end

function keysutils.user_daybuy_key(appname, uid)
    return string.format("%s:user:daybuy:%s", tostring(appname), tostring(uid))
end

function keysutils.user_receivedaybuy_key(appname, uid)
    return string.format("%s:user:receivedaybuy:%s", tostring(appname), tostring(uid))
end

function keysutils.user_limitshop_key(appname, uid)
    return string.format("%s:user:limitshop:%s", tostring(appname), tostring(uid))
end

function keysutils.club_signin_key(appname, clubid, day)
    return string.format("%s:club:signin:%s:%s", tostring(appname), tostring(clubid), tostring(day))
end

function keysutils.club_sendmailnum_key(appname, clubid, day)
    return string.format("%s:club:sendmailnum:%s:%s", tostring(appname), tostring(clubid), tostring(day))
end

function keysutils.club_research_key(appname, uid)
    return string.format("%s:club:research:%s", tostring(appname), tostring(uid))
end

function keysutils.club_bossharmrank_key(appname, clubid, bossid)
    return string.format("%s:club:bossharm:rank:%s:%s", tostring(appname), tostring(clubid), tostring(bossid))
end

function keysutils.club_bossharm_key(appname, clubid, bossid)
    return string.format("%s:club:bossharm:%s:%s", tostring(appname), tostring(clubid), tostring(bossid))
end

--咸将塔相关
function keysutils.tower_rank_key(appname, server)
    return string.format("%s:tower:rank:%s", tostring(appname), tostring(server))
end

function keysutils.user_towerstatus_key(appname, uid)
    return string.format("%s:user:towerstatus:%s", tostring(appname), tostring(uid))
end

function keysutils.arena_season_key(appname)
    return string.format("%s:arena:season")
end

function keysutils.arena_usergroup_key(appname, uid, week)
    return string.format("%s:arena:user:group:id:%s:%s", tostring(appname), tostring(uid), tostring(week))
end

function keysutils.arena_groupid_key(appname, server, level, week)
    return string.format("%s:arena:group:id:%s:%s:%s", tostring(appname), tostring(server), tostring(level), tostring(week))
end

function keysutils.arena_group_key(appname, server, level, week, groupid)
    return string.format("%s:arena:group:list:%s:%s:%s:%s", tostring(appname), tostring(server), tostring(level), tostring(week), tostring(groupid))
end

function keysutils.arena_groupbase_key(appname, server, level, week)
    return string.format("%s:arena:group:list:%s:%s:%s", tostring(appname), tostring(server), tostring(level), tostring(week))
end

function keysutils.arena_battlenum_key(appname, uid, day)
    return string.format("%s:arena:battlenum:%s:%s", tostring(appname),  tostring(uid), tostring(day))
end

function keysutils.arena_refreshnum_key(appname, uid)
    return string.format("%s:arena:refreshnum:%s", tostring(appname),  tostring(uid))
end

function keysutils.arena_match_backup_key(appname, uid)
    return string.format("%s:arena:match:backup:%s", tostring(appname),  tostring(uid))
end

function keysutils.arena_deflineup_key(appname, uid)
    return string.format("%s:arena:deflineup:%s", tostring(appname),  tostring(uid))
end

function keysutils.arena_pass_key(appname, no, uid)
    return string.format("%s:arena:pass:%s:%s", tostring(appname), tostring(no), tostring(uid))
end

function keysutils.friend_refreshnum_key(appname, uid, day)
    return string.format("%s:friend:refreshnum:%s:%s", tostring(appname), tostring(uid), tostring(day))
end

function keysutils.friend_refreshtime_key(appname, uid)
    return string.format("%s:friend:refreshtime:%s", tostring(appname), tostring(uid))
end

function keysutils.friend_give_coin(appname, uid, day)
    return string.format("%s:friend:give:coin:%s", tostring(appname), tostring(uid), tostring(day))
end

function keysutils.friend_receive_coin(appname, uid, day)
    return string.format("%s:friend:receive:coin:%s", tostring(appname), tostring(uid), tostring(day))
end

function keysutils.user_blackmarket_discount_key(appname, uid, day)
    return string.format("%s:blackmarket:discount:%s:%s", tostring(appname), tostring(uid), tostring(day))
end

function keysutils.user_blackmarket_refresh_num_key(appname, uid, day)
    return string.format("%s:blackmarket:refresh:num:%s:%s", tostring(appname), tostring(uid), tostring(day))
end

function keysutils.user_blackmarket_buy_key(appname, uid, day, num)
    return string.format("%s:blackmarket:buy:list:%s:%s:%s", tostring(appname), tostring(uid), tostring(day), tostring(num))
end

--抢占盐罐key
function keysutils.user_robsaltpot_num_key(appname, uid, day)
    return string.format("%s:robsaltpot:num:%s:%s", tostring(appname), tostring(uid), tostring(day))
end

function keysutils.user_robsaltpot_list_key(appname, uid)
    return string.format("%s:robsaltpot:list:%s", tostring(appname), tostring(uid))
end

function keysutils.user_vip_benefit_key(appname, uid)
    return string.format("%s:vip:benefit:%s", tostring(appname), tostring(uid))
end

function keysutils.user_newuser_mail_key(appname, uid, day)
    return string.format("%s:mail:newuser:%s:%s", tostring(appname), tostring(uid), tostring(day))
end

function keysutils.user_mail_daywelfare_key(appname, uid, day)
    return string.format("%s:mail:daywelfare:%s:%s", tostring(appname), tostring(uid), tostring(day))
end

function keysutils.user_huoba_model_key(appname, uid)
    return string.format("%s:huoba:model:%s", tostring(appname), tostring(uid))
end

function keysutils.user_huoba_share_key(appname, uid, day)
    return string.format("%s:huoba:sharenum:%s:%s", tostring(appname), tostring(uid), tostring(day))
end

function keysutils.user_huoba_adv_key(appname, uid, day)
    return string.format("%s:huoba:advnum:%s:%s", tostring(appname), tostring(uid), tostring(day))
end

function keysutils.user_game_code_key(appname, uid)
    return string.format("%s:game:code:%s", tostring(appname), tostring(uid))
end

function keysutils.user_choose_server_key(appname, uid)
    return string.format("%s:choose:server:%s", tostring(appname), tostring(uid))
end

function keysutils.user_week_buy_heishi_key(appname, uid, week)
    return string.format("%s:week:buy:heishi:%s:%s", tostring(appname), tostring(uid), tostring(week))
end

function keysutils.user_week_buy_baoxiang_key(appname, uid, week)
    return string.format("%s:week:buy:baoxiang:%s:%s", tostring(appname), tostring(uid), tostring(week))
end

function keysutils.user_week_receivebuy_baoxiang_key(appname, uid, week)
    return string.format("%s:week:receivebuy:baoxiang:%s:%s", tostring(appname), tostring(uid), tostring(week))
end

function keysutils.user_week_receive_baoxiang_key(appname, uid, week)
    return string.format("%s:week:receive:baoxiang:%s:%s", tostring(appname), tostring(uid), tostring(week))
end

function keysutils.user_week_baoxiang_score_key(appname, uid, week)
    return string.format("%s:week:baoxiang:score:%s:%s", tostring(appname), tostring(uid), tostring(week))
end

function keysutils.user_week_buy_zhaomu_key(appname, uid, week)
    return string.format("%s:week:buy:zhaomu:%s:%s", tostring(appname), tostring(uid), tostring(week))
end

function keysutils.user_week_zhaomu_score_key(appname, uid, week)
    return string.format("%s:week:zhaomu:score:%s:%s", tostring(appname), tostring(uid), tostring(week))
end

function keysutils.user_week_receivebuy_zhaomu_key(appname, uid, week)
    return string.format("%s:week:receivebuy:zhaomu:%s:%s", tostring(appname), tostring(uid), tostring(week))
end

function keysutils.user_week_receive_zhaomu_key(appname, uid, week)
    return string.format("%s:week:receive:zhaomu:%s:%s", tostring(appname), tostring(uid), tostring(week))
end

function keysutils.user_invite_num_key(appname, uid)
    return string.format("%s:invite:num:%s", tostring(appname), tostring(uid))
end

function keysutils.user_invite_key(appname, uid)
    return string.format("%s:invite:receive:%s", tostring(appname), tostring(uid))
end

function keysutils.user_update_nickname_num_key(appname, uid)
    return string.format("%s:update:nickname:num:%s", tostring(appname), tostring(uid))
end


function keysutils.user_buy_duanwu_key(appname, uid, year)
    return string.format("%s:duanwu:buy:%s:%s", tostring(appname), tostring(uid), tostring(year))
end

function keysutils.user_duanwu_score_key(appname, uid, year)
    return string.format("%s:duanwu:score:%s:%s", tostring(appname), tostring(uid), tostring(year))
end

function keysutils.user_receivebuy_duanwu_key(appname, uid, year)
    return string.format("%s:receivebuy:duanwu:%s:%s", tostring(appname), tostring(uid), tostring(year))
end

function keysutils.user_receive_duanwu_key(appname, uid, year)
    return string.format("%s:receive:duanwu:%s:%s", tostring(appname), tostring(uid), tostring(year))
end

function keysutils.user_duihuan_duanwu_key(appname, uid, year)
    return string.format("%s:duihuan:duanwu:%s:%s", tostring(appname), tostring(uid), tostring(year))
end

return keysutils






















