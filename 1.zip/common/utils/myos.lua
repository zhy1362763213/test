local _M={}

function _M.strToHex(str)
    return (str:gsub(".", function(char) return string.format("%02x", char:byte()) end))
end

function _M.hexToStr(hex)
    return (hex:gsub("%x%x", function(digits) return string.char(tonumber(digits, 16)) end))
end

function _M.getOS()
    return "LIN"
end

function _M.getSerialNum()
    local os = _M.getOS()
    if os == "LIN" then
        local f = io.popen(" dmidecode -t 4 | grep ID |sort -u |awk -F': ' '{print $2}' ")
        local s = f:read("*all")
        f:close()
        return string.lower(string.gsub(s, "%s+", ""))
    else
        error "该系统还未实现"
    end
end

return _M