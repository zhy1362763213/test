local utils={}

function utils.redis_pack(...)
    local t = {}
    local s = ...
    for i=1,#s,2 do
        local k = s[i]
        local v = s[i+1]
        t[k] = v
    end

    return t
end


function utils.redis_unpack(t)
    local data = {}
    for k, v in pairs(t) do
        table.insert(data, k)
        table.insert(data, v)
    end
    return table.unpack(data)
end


function utils.round(num)
    if num >= 0 then
        return math.floor(num + 0.5)
    else
        return math.ceil(num - 0.5)
    end
end


function utils.getserver(serverid)
    serverid = checkint(serverid)
    return math.ceil(serverid/20)
end

local ser_cfg = {
    [1]=20,
    [2]=20,
    [3]=100,
    [4]=100,
    [5]=100,
    [6]=500,
}
--计算竞技场组
function utils.getarenserver(serverid, level)
     return math.ceil(serverid/ser_cfg[math.floor(level)])
end


function utils.getbaifuserver(serverid)
     return math.ceil(serverid/100)
end

return utils
