
local config = {}

local DEFAULT={
    errmsg={
    },
}

local dbconfig={}
function config.get(...)
    local d = dbconfig
    for _,v in ipairs({...}) do
        local k = v
        d=d[k]
        if not d then
            break
        end
    end
    if d then
        return d
    end

    local d = DEFAULT
    for _,v in ipairs({...}) do
        local k = v
        d=d[k]
        if not d then
            break
        end
    end
    if d then
        return d
    end
    assert(false,'不能走到这里')
end

return config

