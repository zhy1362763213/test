local cjson   = require "cjson"
local msgpack = require "msgpack"
local settings = require "settings"
local M = {}

function M.encode(text)
    if settings.protocol_type == "json" then
        local ok, result = pcall(cjson.encode, text)
        if ok then
            return ok, result
        end
        print(string.format("json.encode failed: text[%s] traceback[%s]", tostring(text), debug.traceback()))
    else
        local ok, result = pcall(msgpack.encode, text)
        if ok then
            return ok, result
        end
        print(string.format("msgpack.encode failed: text[%s] traceback[%s]", tostring(text), debug.traceback()))
    end
    return false, nil
end


function M.decode(text)
    if settings.protocol_type == "json" then
        local ok, result = pcall(cjson.decode, text)
        if ok then
            return ok, result
        end
        print(string.format("json.decode failed: text[%s] traceback[%s]", tostring(text), debug.traceback()))
    else
        local ok, result = pcall(msgpack.decode, text)
        if ok then
            return ok, result
        end
        print(string.format("msgpack.decode failed: text[%s] traceback[%s]", tostring(text), debug.traceback()))
    end
    return false, nil
end

return M