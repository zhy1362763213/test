-- 微信支付
local sign      = require "sign"
local cjson     = require "cjson"
local lua2xml   = require "lua2xml"
local xml2lua   = require "xml2lua"
local http      = require("http.httpc")

local M = {}

local header = {
    ["content-type"] = "application/json"
}

function M.js_create_order(param)
    local order_no      = assert(param.order_no)
    local openid        = assert(param.openid)
    local appid         = assert(param.appid)
    local mchid         = assert(param.mchid)
    local description   = assert(param.description)
    local payment       = assert(param.payment)
    local url           = assert(param.url)

    local args = {
        appid            = appid,
        mchid            = mchid,
        description      = description,
        out_trade_no     = order_no,
        amount           = {
            total        = payment*100//1 >> 0,
            currency     = "CNY"
        },
        payer            = {
            openid       = openid
        },
        spbill_create_ip = '127.0.0.1',
        notify_url       = url,
    }
    local statuscode, resp_str = http.request("POST", "https://api.mch.weixin.qq.com", "/v3/pay/transactions/jsapi", {}, header, cjson.encode(args))

    local ok, data = pcall(cjson.decode, resp_str)

    if not ok then
        ERROR("weixin jsapi pay response = ", resp_str)
        error("weixin jsapi pay response error")
    end

    if statuscode ~= 200 then
        return statuscode, data.message, nil
    end

    return statuscode,  "成功", data.prepay_id
end

local WX_OK = {
    return_code = "SUCCESS",
    return_msg  = "OK",
}

local WX_FAIL = {
    return_code = "FAIL",
    return_msg  = "FAIL",
}

function M.notify(order, key, param)
    if order.item_state == def.PayState.SUCCESS then
        return WX_OK
    end
    local args = {}
    for k, v in pairs(param) do
        if k ~= "sign" then
            args[k] = v
        end
    end

    local sign1 = sign.md5_args(args, key)
    local sign2 = param.sign
    if sign1 ~= sign2 then
        return WX_FAIL
    end

    if param.result_code ~= "SUCCESS" or param.return_code ~= "SUCCESS" then
    else
        order.pay_time = os.time()
        order.tid = param.transaction_id
    end
    return WX_OK
end
return M
