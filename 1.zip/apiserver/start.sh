#!/bin/sh
rm logs/*.log
# killall -9 skynet
nginx -p `pwd` -c conf/nginx.conf -s stop
nginx -p `pwd` -c conf/nginx.conf 
# nginx -p `pwd` -c conf/nginx.conf -s reload
