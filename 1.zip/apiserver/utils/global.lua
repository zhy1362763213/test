local cjson = require "cjson"
local _M={}


local appname
local appversion
local mysqlconf
local redisconf
local queue_redisconf
local mongoconf


function _M.get_appname()
    if not appname then
        appname = APPNAME
    end
    return appname
end

function _M.get_appversion()
    if not appversion then
        appversion = APPVERSION
    end
    return appversion
end

function _M.get_mysql_conf()
    if not mysqlconf then
        mysqlconf = MYSQL_CONFIG
    end
    return mysqlconf
end

function _M.get_redis_conf()
    if not redisconf then
        redisconf = {}
        redisconf.host = REDIS_CONFIG.ip
        redisconf.port = REDIS_CONFIG.port
    end
    return redisconf
end

function _M.get_redis_queue_conf()
    if not queue_redisconf then
        queue_redisconf = {}
        queue_redisconf.host = QUEUE_CONFIG.ip
        queue_redisconf.port = QUEUE_CONFIG.port
    end
    return queue_redisconf
end

function _M.get_mongo_conf()
    if not mongoconf then
        mongoconf = {}
        mongoconf.ip   = MONGO_CONFIG.ip
        mongoconf.port = MONGO_CONFIG.port
    end
    return mongoconf
end


return _M
