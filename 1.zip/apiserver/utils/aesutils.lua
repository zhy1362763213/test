local resty_aes = require "resty.aes"
local str = require "resty.string"

local _M = {}


function _M.encrypt(text, key)
    local cript, err = resty_aes:new(key,nil, resty_aes.cipher(256,"gcm"), {iv=key})
    assert(cript, err)
    local encrypted = cript:encrypt(text)
    ngx.log(ngx.INFO, "encrypted = ", ngx.encode_base64(encrypted))
    return encrypted
end

function _M.decrypt(encrypted, key, iv)
    local cript, err = resty_aes:new(key, nil, resty_aes.cipher(256,"gcm"), aes.hash.sha256, 1, 12)
    assert(cript, err)
    return cript:decrypt(encrypted)
end

return _M