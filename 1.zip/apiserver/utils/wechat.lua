local http = require "http"
local cjson = require "cjson"
local resty_sha1 = require "resty.sha1"
local resty_str  = require "resty.string"
local resty_aes  = require "resty.aes"
local _M = {}


function _M.getAccessToken()
    local url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wx23e905123117fd0e&secret=d6b02b2c529c1a8ee0d2a3fb2e3dd9a6"
    local r = http.get(url)
    print("getAccessToken r = ", r)
    local ok, resp = pcall(cjson.decode, r)
    if ok then
        if not resp.errcode then
            return resp.access_token
        end
        return false
    end
end

function _M.js_create_order(param)
    local order_no      = assert(param.order_no)
    local openid        = assert(param.openid)
    local appid         = assert(param.appid)
    local mchid         = assert(param.mchid)
    local description   = assert(param.description)
    local payment       = assert(param.payment)
    local url           = assert(param.url)
    local Authorization = assert(param.authorization)
    local args = {
        appid            = appid,
        mchid            = mchid,
        description      = description,
        out_trade_no     = order_no,
        amount           = {
            total        = math.floor(tonumber(payment)*100),
            currency     = "CNY"
        },
        payer            = {
            openid       = openid
        },
        notify_url       = "url",
    }

    print("jsapi args = ", cjson.encode(args))
    local headers = {
            ["Content-Type"] = "application/json",
            ["Authorization"] = Authorization
        }
    local resp = http.post("https://api.mch.weixin.qq.com/v3/pay/transactions/jsapi", cjson.encode(args))
    print("jsapi resp = ", resp)
    local ok, data = pcall(cjson.decode, resp)

    if not ok then
        return false
    end

    return data
end

local WX_OK = {
    return_code = "SUCCESS",
    return_msg  = "OK",
}

local WX_FAIL = {
    return_code = "FAIL",
    return_msg  = "FAIL",
}

function _M.notify(order, key, param)
    if order.item_state == def.PayState.SUCCESS then
        return WX_OK
    end
    local args = {}
    for k, v in pairs(param) do
        if k ~= "sign" then
            args[k] = v
        end
    end

    local sign1 = sign.md5_args(args, key)
    local sign2 = param.sign
    if sign1 ~= sign2 then
        return WX_FAIL
    end

    if param.result_code ~= "SUCCESS" or param.return_code ~= "SUCCESS" then
    else
        order.pay_time = os.time()
        order.tid = param.transaction_id
    end
    return WX_OK
end


return _M