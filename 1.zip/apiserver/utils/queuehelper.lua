local cjson     = require "cjson"
local global    = require "global"
local redis     = require "redis"
local genid     = require "genid"

local _M={}

function _M.putqueue(roomid, data)
    local r = redis:new(global.get_redis_queue_conf())
    local queuename= string.format("%s:mailreward:queue", global.get_appname());
    local cmd={
            uuid=genid.genuuid(),
            roomid=roomid,
            data=data,
        }
    return r:lpush(queuename, cjson.encode(cmd))
end

return _M