
local config = {}
local cjson = require "cjson"

local DEFAULT={
    errmsg={
        e10001='系统错误',
    },

}

return config
