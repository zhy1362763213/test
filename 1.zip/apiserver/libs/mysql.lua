local mysql = require "resty.mysql"
local cjson = require "cjson"
local string = require "string"
local _M = {}


local function on_connect(db)
    db:query("set charset utf8mb4");
end


local function close(self)
    local sock = self.sock
    if not sock then
        return nil, "not initialized"
    end
    if self.subscribed then
        return nil, "subscribed state"
    end
    return sock:setkeepalive(10000, 100)
end



function _M.new(self,cnf)
    local db, err = mysql:new()
    if not db then
        ngx.log(ngx.INFO,"db is err")
        return nil
    else
        ngx.log(ngx.INFO,"db is ok")
    end
    db:set_timeout(1000) -- 1 sec

    local ok, err, errno, sqlstate = db:connect{
    host = cnf.ip,
    port = cnf.port,
    database = cnf.db,
    user = cnf.user,
    password = cnf.password,
    charset = "utf8mb4",
    max_packet_size = 1024 * 1024,
    on_connect = on_connect
    }

    if not ok then
        ngx.log(ngx.INFO,"db connect err = ", err)
        return nil
    end
    db.close = close
    return db
end


return _M