local mongo = require "resty.mongol"
local cjson = require "cjson"

local _M = {}

function _M.new(self, cnf)
    local conn = mongo:new()
    conn:set_timeout(10000)
    local ok, err = conn:connect(cnf.ip, cnf.port)
    if not ok then
        ngx.log(ngx.INFO,"mongo connect err = ", err)
        return nil, err
    end
    return conn, nil
end


return _M