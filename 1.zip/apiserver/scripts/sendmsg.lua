local global   = require "global"
local mysql    = require "mysql"
local cjson    = require "cjson"
local wechat   = require "wechat"
local http     = require "http"

local arg   =   ngx.req.get_uri_args()
ngx.header['Content-Type'] = 'application/json; charset=utf-8'
local openid = arg.openid

local token = wechat.getAccessToken()

local url = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token="..token

local resp = {}
resp.access_token = token
resp.touser = openid
resp.msgtype = "miniprogrampage"
resp.miniprogrampage =  {
    title="我要充值",
    pagepath="",
    thumb_media_id="",
}
local r = http.post(url, cjson.encode(resp))
print("send r = ", r)
ngx.say(cjson.encode(resp))


