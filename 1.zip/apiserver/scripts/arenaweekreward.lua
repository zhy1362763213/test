local global   = require "global"
local mysql    = require "mysql"
local cjson    = require "cjson"
local mongo    = require "resty.mongol"
local redis    = require "redis"
local utils    = require "utils"
local queuehelper    = require "queuehelper"

ngx.header['Content-Type'] = 'application/json; charset=utf-8'

local serverid = 1000
local ser_cfg = {
    [1]=20,
    [2]=20,
    [3]=100,
    [4]=100,
    [5]=100,
    [6]=500,
}
--计算竞技场组
local function getarenserver(serverid, level)
     return math.ceil(serverid/ser_cfg[math.floor(level)])
end

local function getlock(week)
    return string.format("%s:arena:dayreward:%s", tostring(global.get_appname()), tostring(week))
end

local function arena_group_key(server, level, week, groupid)
    return string.format("%s:arena:group:list:%s:%s:%s:%s", tostring(global.get_appname()), tostring(server), tostring(level), tostring(week), tostring(groupid))
end

local function arena_groupid_key(server, level, week)
    return string.format("%s:arena:group:id:%s:%s:%s", tostring(global.get_appname()), tostring(server), tostring(level), tostring(week))
end

local function callastweekno()
    local   t        =  os.time() - 7* 86400
    local   year     =  os.date("%Y", t)
    local   month    =  os.date("%m", t)
    local   day      =  os.date("%d", t)
    return  os.date("%W", os.date(os.time{year=year, month=month, day=day}))
end

local rediscli = redis:new(global.get_redis_conf())

local last_week = callastweekno()

local k = getlock(last_week)
local lock = rediscli:get(k)
print("lock = ", lock)
-- if lock ~= nil then
--     ngx.say(cjson.encode({errcode=10000, errmsg="请勿重复发奖", data={}}))
-- end

for level=1, #ser_cfg do
    local maxserver = getarenserver(serverid, level)
    for server=1, maxserver do
        local k1 = arena_groupid_key(server, level, last_week)
        local gid = rediscli:get(k1) or 0
        gid = math.floor(gid)
        if gid > 0 then
            for groupid=1, gid do
                local k2 = arena_group_key(server, level, last_week, groupid)
                local res = rediscli:zrevrange(k2, 0, -1, "WITHSCORES")
                local rank = utils.redis_pack(res)
                local i = 1
                for userid, score in pairs(rank) do
                    --TODO 对列
                    local data = {type="arena_week", receiver={uid=userid, rank=i}}
                    queuehelper.putqueue(ngx.time()*1000, data)
                    i = i + 1
                end
            end
        end
    end
end

rediscli:ser(k, os.time())

ngx.say(cjson.encode({errcode=0, errmsg="竞技场周奖励发送成功", data={}}))