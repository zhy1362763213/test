local cjson     = require "cjson"
local redis     = require "redis"
local global    = require "global"
local keysutils = require "keysutils"
local genid     = require "genid"
local jwt       = require "resty.jwt"
local resty_md5 = require "resty.md5"
local str       = require "resty.string"
local http      = require "http"
local wechat    = require "wechat"
local mongo     = require "mongo"
local resty_sha256 = require "resty.sha256"
local resty_hmac   = require "resty.hmac"

require "functions"

local pattern = "(%d+)-(%d+)-(%d+) (%d+):(%d+):(%d+)"

local function get_timestamp_by_datetime(datetime, pattern)
    local year, month, day, hour, min, sec = datetime:match(pattern)
    return os.time({day=day,month=month,year=year,hour=hour,min=min,sec=sec})
end

local arg=ngx.req.get_uri_args()
ngx.header['Content-Type'] = 'application/json; charset=utf-8'

local order_no = arg.order_no
local openid = arg.openid
if not order_no or not openid then
    ngx.say(cjson.encode({errcode=14001,errmsg="参数错误[35]"}))
    return
end

local mgo = mongo:new(global.get_mongo_conf())
local db  = mgo:new_db_handle("leshusanguo")
local col = db:get_col("recharge_order")
local order = col:find_one({order_no=order_no})

if not order then
    mgo:set_keepalive(10000, 100)
    return ngx.say(cjson.encode({errcode=10002, errmsg="订单号错误", data={}}))
end

if order.pay_status and order.pay_status == 1 then
    mgo:set_keepalive(10000, 100)
    return ngx.say(cjson.encode({errcode=10003, errmsg="订单已支付", data={}}))
end

if get_timestamp_by_datetime(order.created_at, pattern) + 10*60 < os.time() then
    mgo:set_keepalive(10000, 100)
    return ngx.say(cjson.encode({errcode=10004, errmsg="订单超时", data={}}))
end

if not order.payment or order.payment == "" or checkint(order.payment) == 0 then
    mgo:set_keepalive(10000, 100)
    return ngx.say(cjson.encode({errcode=10005, errmsg="订单金额错误", data={}}))
end

local payment = order.payment * 100

if not order.description or order.description == "" then
    mgo:set_keepalive(10000, 100)
    return ngx.say(cjson.encode({errcode=10006, errmsg="订单描述错误", data={}}))
end

local description = order.description

local params = {
    order_no=order_no,
    openid=openid,
    description=description,
    payment=payment,
}

--测试阶段先支付0.01
-- params.payment = 0.01*100

local resp_str = http.post("http://127.0.0.1:5000/game/h5pay", cjson.encode(params))
print("resp_str = ", resp_str)
local ok, resp = pcall(cjson.decode, resp_str)
if not ok then
    mgo:set_keepalive(10000, 100)
    return ngx.say(cjson.encode({errcode=10003, errmsg="支付错误", data={}}))
end
if resp.code ~= 200 then
    mgo:set_keepalive(10000, 100)
    return ngx.say(cjson.encode({errcode=10004, errmsg="支付失败", data={}}))
end
mgo:set_keepalive(10000, 100)
ngx.say(cjson.encode({errcode=0,errmsg="",data={data=resp.data}}))

