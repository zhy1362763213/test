local cjson     = require "cjson"
local redis     = require "redis"
local global    = require "global"
local keysutils = require "keysutils"
local genid     = require "genid"
local jwt       = require "resty.jwt"
local resty_md5 = require "resty.md5"
local str       = require "resty.string"
local http      = require "http"
local wechat    = require "wechat"
local mongo     = require "mongo"
local resty_sha1 = require "resty.sha1"
require "functions"

local args = ngx.req.get_uri_args()
ngx.header['Content-Type'] = 'application/json; charset=utf-8'
ngx.log(ngx.INFO,"args=======================>",cjson.encode(args))


local mgo = mongo:new(global.get_mongo_conf())
local db  = mgo:new_db_handle("leshusanguo")
local col = db:get_col("user")
local r, err = col:update({uid={["$gt"]=1}}, {["$set"]={max_level=1, lv=1, stage=0, login_day=0, online_status=0, last_login_time="", last_logout_time="",blackmarket_num=0, box_score=0,box_stage=0, coinget_num=0, emblemstar=0, emblemstarid=0, fishing_num_lv1=0, fishing_num_lv2=0, fishing_score=0, is_update=0, last_recruit_time=0, last_use_nengliang_time=0, last_use_xyg_time=0, openbox_num=0, owner=0, recruit_num=0, tower_level=1}}, nil, 1)

print("err = ", err)
local col = db:get_col("bag")

local items = {
    coin="金币", --金币
    gold="金砖", --金砖
    box_lv1="宝箱1",
    box_lv2="宝箱2",
    box_lv3="宝箱3",
    box_lv4="宝箱4",
    box_lv5="宝箱5",
    jingtie="精铁",
    mengyanjingshi="梦魇晶石",
    jinjieshi="进阶石",
    zhaomuling="招募令",
    xianshenmenpiao="咸神门票",
    nengliang="能量",
    huoba_lv1="一级火把",
    huoba_lv2="二级火把",
    huoba_lv3="三级火把",
    zhenzhu="珍珠",
    juntuanbi="军团币",
    pifubi="皮肤币",
    saodangmotan="扫荡魔毯",
    baiyu="白玉",
    caiyu="彩玉",
    banshou="扳手",
    chunsun="春笋",
    xiaoyugan="小鱼干",
    shendeng="神灯",
    yugan_lv1="普通鱼竿",
    yugan_lv2="黄金鱼竿",
    zhishibi="知识币",
    zhuweibi="助威币",
    libao_coin="金币礼包",
    libao_gold="金砖礼包",
    libao_jinjieshi="进阶石礼包",
    libao_jingtie="精铁礼包",
    libao_mengyanjingshi="梦魇精石礼包",
    libao_wujiang_zi1="随机紫色武将礼包",
    libao_wujiang_cheng1="随机橙色武将礼包",
    libao_wujiang_cheng2="万能橙色武将礼包",
    libao_wujiang_hong1="随机红色武将礼包",
    libao_wujiang_hong2="万能红色武将礼包",
    libao_jubaoding_lv1="聚宝鼎",
    libao_jubaoding_lv2="豪华聚宝鼎",
    libao_baiyu="白玉福袋",
    libao_banshou="扳手福袋",
    zongzi_lv1="普通粽子",
    zongzi_lv2="银粽子",
    zongzi_lv3="金粽子",
    card_101="司马懿碎片",
    card_102="郭嘉碎片",
    card_103="关羽碎片",
    card_104="诸葛亮碎片",
    card_105="周瑜碎片",
    card_106="太史慈碎片",
    card_107="吕布碎片",
    card_108="华佗碎片",
    card_109="甄姬碎片",
    card_110="黄月英碎片",
    card_111="孙策碎片",
    card_112="贾诩碎片",
    card_113="曹仁碎片",
    card_114="姜维碎片",
    card_115="孙坚碎片",
    card_116="公孙瓒碎片",
    card_202="荀彧碎片",
    card_203="典韦碎片",
    card_207="鲁肃碎片",
    card_208="陆逊碎片",
    card_209="甘宁碎片",
    card_210="貂蝉碎片",
    card_211="董卓碎片",
    card_212="张角碎片",
    card_215="许褚碎片",
    card_220="马岱碎片",
    card_223="蔡文姬碎片",
    card_227="颜良碎片",
    card_228="文丑碎片",
    card_301="周泰碎片",
    card_302="许攸碎片",
    card_303="于禁碎片",
    card_304="张星彩碎片",
    card_305="关银屏碎片",
    card_306="关平碎片",
    card_307="程普碎片",
    card_308="张昭碎片",
    card_312="邢道荣碎片",
    card_313="祝融夫人碎片",
    card_314="孟获碎片",
}

local sets = {}

for k,v in pairs(items) do
    if k == "xiaoyugan" or k == "coin" then
        sets[k] = 10
    else
        sets[k] = 0
    end
end

local r, err = col:update({uid={["$gt"]=1}},{["$set"]=sets}, nil, 1)
print("err = ", err)

mgo:set_keepalive(10000, 100)
ngx.say(cjson.encode({code="SUCCESS", message="成功"}))