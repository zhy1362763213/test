local cjson     = require "cjson"
local redis     = require "redis"
local global    = require "global"
local keysutils = require "keysutils"
local genid     = require "genid"
local jwt       = require "resty.jwt"
local resty_md5 = require "resty.md5"
local str       = require "resty.string"
local http      = require "http"
local wechat    = require "wechat"
local mongo     = require "mongo"
local resty_sha1 = require "resty.sha1"
require "functions"

local args = ngx.req.get_uri_args()
ngx.header['Content-Type'] = 'application/json; charset=utf-8'

local body = ngx.req.get_body_data()

local url = "https://api.weixin.qq.com/wxa/generate_urllink?access_token="..args.access_token

local resp = http.post(url, body)
ngx.say(resp)