local cjson     = require "cjson"
local redis     = require "redis"
local global    = require "global"
local keysutils = require "keysutils"
local genid     = require "genid"
local jwt       = require "resty.jwt"
local resty_md5 = require "resty.md5"
local str       = require "resty.string"
local http      = require "http"


local arg=ngx.req.get_uri_args()
ngx.header['Content-Type'] = 'application/json; charset=utf-8'

local code = arg.code
if not code then
    ngx.say(cjson.encode({errcode=14001,errmsg="参数错误[35]"}))
    return
end

local appid  = "wx23e905123117fd0e"
local secret = "d6b02b2c529c1a8ee0d2a3fb2e3dd9a6"
local url = string.format("https://api.weixin.qq.com/sns/oauth2/access_token?appid=%s&secret=%s&code=%s&grant_type=authorization_code",appid, secret, code)
local resp_str = http.get(url)
ngx.log(ngx.INFO,"resp_str=======================>", resp_str)
if not resp_str then
    ngx.say(cjson.encode({errcode=14004, errmsg="微信授权失败[61]"}))
    return
end
local ok, resp = pcall(cjson.decode, resp_str)

if not ok then
    ngx.say(cjson.encode({errcode=14004, errmsg="微信授权失败[62]"}))
    return
end

local openid = resp.openid
local access_token = resp.access_token
-- if not openid or not access_token then
--     ngx.say(cjson.encode({errcode=14004, errmsg="微信授权失败[69]"}))
--     return
-- end

-- local url = string.format("https://api.weixin.qq.com/sns/userinfo?access_token=%s&openid=%s&lang=zh_CN",access_token, openid)

-- local resp_str = http.get(url)

-- if not resp_str then
--     ngx.say(cjson.encode({errcode=14005, errmsg="获取用户信息失败"}))
--     return
-- end
-- local ok, user = pcall(cjson.decode, resp_str)

-- if not ok then
--     ngx.say(cjson.encode({errcode=14006, errmsg="解析用户信息失败"}))
--     return
-- end

ngx.say(cjson.encode({errcode=0,errmsg="",data={openid=openid}}))

