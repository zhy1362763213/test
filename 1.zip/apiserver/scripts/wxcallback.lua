local cjson     = require "cjson"
local redis     = require "redis"
local global    = require "global"
local keysutils = require "keysutils"
local genid     = require "genid"
local jwt       = require "resty.jwt"
local resty_md5 = require "resty.md5"
local str       = require "resty.string"
local http      = require "http"
local wechat    = require "wechat"
local mongo     = require "mongo"
local resty_sha1 = require "resty.sha1"
require "functions"

local args = ngx.req.get_uri_args()
ngx.header['Content-Type'] = 'application/json; charset=utf-8'
ngx.log(ngx.INFO,"args=======================>",cjson.encode(args))

local body = ngx.req.get_body_data()
ngx.log(ngx.INFO,"body=======================>",body)

local headers = ngx.req.get_headers()
ngx.log(ngx.INFO,"headers=======================>",cjson.encode(headers))

local resp_str = http.post("http://127.0.0.1:5000/game/wxcallback", body, headers)
ngx.log(ngx.INFO, "wxcallback resp_str=======================>", resp_str)
local ok, resp = pcall(cjson.decode, resp_str)
if not ok then
    ngx.say(cjson.encode({code="FAILED", message="失败"}))
    return ngx.exit(500)
end

if resp.code ~= "SUCCESS" then
    ngx.say(cjson.encode({code="FAILED", message="失败"}))
    return ngx.exit(500)
end

local myorder = resp.data

local order_no = myorder.out_trade_no

local total = myorder.amount.total

local mgo = mongo:new(global.get_mongo_conf())
local db  = mgo:new_db_handle("leshusanguo")
local col = db:get_col("recharge_order")
local order = col:find_one({order_no=order_no})

if not order then
    mgo:set_keepalive(10000, 100)
    ngx.say(cjson.encode({code="FAILED", message="订单查询失败"}))
    return ngx.exit(500)
end

if order.pay_status and order.pay_status == 1 then
    mgo:set_keepalive(10000, 100)
    ngx.say(cjson.encode({code="FAILED", message="该订单已支付"}))
    return ngx.exit(500)
end


if not order.payment or order.payment == "" or checkint(order.payment) == 0 then
    mgo:set_keepalive(10000, 100)
    ngx.say(cjson.encode({code="FAILED", message="支付金额错误"}))
    return ngx.exit(500)
end

local payment = order.payment * 100

if payment ~= total then
    mgo:set_keepalive(10000, 100)
    ngx.say(cjson.encode({code="FAILED", message="支付金额错误"}))
    return ngx.exit(500)
end

local col = db:get_col("user")
local user = col:find_one({uid=order.uid})
if user.parent_id and user.parent_id ~= "" then
    local r = redis:new(global.get_redis_conf())
    local k = string.format("%s:agent:bili", tostring(global.get_appname()))
    local bili = r:get(k) or 0
    local money = tonumber(bili) * order.payment
    local col = db:get_col("agent")
    col:update({_id=user.parent_id},{["$inc"]={money=money}})

    local log={
        order_no=order_no,
        uid=order.uid,
        agent_id=user.parent_id,
        money=money,
        description=order.description,
        payment=order.payment,
        created_at=os.date("%Y-%m-%d %H:%M:%S")
    }
    local col = db:get_col("order_rebate_log")
    local r, err = col:insert({log}, nil, true)
end

local q = redis:new(global.get_redis_queue_conf())
local queuename= "leshusanguo:pay:queue"
local cmd={
    uuid=genid.genuuid(),
    order_no=order_no,
    uid=order.uid,
}
q:lpush(queuename, cjson.encode(cmd))

local col = db:get_col("recharge_order")
col:update({order_no=order_no},{["$set"]={pay_status=1, pay_at=os.date("%Y-%m-%d %H:%M:%S")}})

mgo:set_keepalive(10000, 100)
ngx.say(cjson.encode({code="SUCCESS", message="成功"}))