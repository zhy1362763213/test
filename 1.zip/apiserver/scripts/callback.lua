local global   = require "global"
local mysql    = require "mysql"
local cjson    = require "cjson"
local genid    = require "genid"
local redis    = require "redis"
local mongo    = require "mongo"


ngx.header['Content-Type'] = 'application/json; charset=utf-8'
local arg   =   ngx.req.get_uri_args()

local body = ngx.req.get_body_data()
ngx.log(ngx.INFO,"body=======================>",body)
local ok, req_data = pcall(cjson.decode,body)
if not ok then
    return ngx.say(cjson.encode({errcode=10000, errmsg="系统繁忙", data={}}))
end

local order_no = req_data.order_no
if not order_no then
    return ngx.say(cjson.encode({errcode=10001, errmsg="参数错误", data={}}))
end

local mgo = mongo:new(global.get_mongo_conf())
local db  = mgo:new_db_handle("leshusanguo")
local col = db:get_col("recharge_order")
local order = col:find_one({order_no=order_no})

if not order then
    return ngx.say(cjson.encode({errcode=10002, errmsg="订单号错误", data={}}))
end

if order.pay_status == 1 then
    return ngx.say(cjson.encode({errcode=10003, errmsg="支付成功", data={}}))
end

print("order = ",order.uid)
print("order_no = ",order.order_no)
print("description= ",order.description)

local col = db:get_col("user")
local user = col:find_one({uid=order.uid})
if user.parent_id and user.parent_id ~= "" then
    local r = redis:new(global.get_redis_conf())
    local k = string.format("%s:agent:bili", tostring(global.get_appname()))
    local bili = r:get(k) or 0
    local money = tonumber(bili) * order.payment
    local col = db:get_col("agent")
    col:update({_id=user.parent_id},{["$inc"]={money=money}})

    local log={
        order_no=order_no,
        uid=order.uid,
        agent_id=user.parent_id,
        money=money,
        description=order.description,
        payment=order.payment,
        created_at=os.date("%Y-%m-%d %H:%M:%S")
    }
    local col = db:get_col("order_rebate_log")
    local r, err = col:insert({log}, nil, true)
    if not r then ngx.say(cjson.encode({errcode=0, errmsg="insert failed err ".. err , data={}})) return end
end

local r = redis:new(global.get_redis_queue_conf())
local queuename= "leshusanguo:pay:queue"
local cmd={
    uuid=genid.genuuid(),
    order_no=order_no,
    uid=order.uid,
}
r:lpush(queuename, cjson.encode(cmd))

local col = db:get_col("recharge_order")
col:update({order_no=order_no},{["$set"]={pay_status=1, pay_at=os.date("%Y-%m-%d %H:%M:%S")}})

mgo:set_keepalive(10000, 100)
ngx.say(cjson.encode({errcode=0, errmsg="callback success", data={}}))