local global   = require "global"
local mysql    = require "mysql"
local cjson    = require "cjson"
local genid    = require "genid"
local redis    = require "redis"
local mongo    = require "mongo"


local pattern = "(%d+)-(%d+)-(%d+) (%d+):(%d+):(%d+)"

local function get_timestamp_by_datetime(datetime, pattern)
    local year, month, day, hour, min, sec = datetime:match(pattern)
    return os.time({day=day,month=month,year=year,hour=hour,min=min,sec=sec})
end

ngx.header['Content-Type'] = 'application/json; charset=utf-8'
local arg   =   ngx.req.get_uri_args()

local order_no = arg.order_no
if not order_no then
    return ngx.say(cjson.encode({errcode=10001, errmsg="参数错误", data={}}))
end

local mgo = mongo:new(global.get_mongo_conf())
local db  = mgo:new_db_handle("leshusanguo")
local col = db:get_col("recharge_order")
local order = col:find_one({order_no=order_no})

if not order then
    mgo:set_keepalive(10000, 100)
    return ngx.say(cjson.encode({errcode=10002, errmsg="订单号错误", data={}}))
end

if order.pay_status == 1 then
    mgo:set_keepalive(10000, 100)
    return ngx.say(cjson.encode({errcode=10003, errmsg="订单已支付", data={}}))
end

if get_timestamp_by_datetime(order.created_at, pattern) + 10*60 < os.time() then
    mgo:set_keepalive(10000, 100)
    return ngx.say(cjson.encode({errcode=10004, errmsg="订单超时", data={}}))
end

if not order.payment or order.payment == "" or checkint(order.payment) == 0 then
    mgo:set_keepalive(10000, 100)
    return ngx.say(cjson.encode({errcode=10005, errmsg="订单金额错误", data={}}))
end

if not order.description or order.description == "" then
    mgo:set_keepalive(10000, 100)
    return ngx.say(cjson.encode({errcode=10006, errmsg="订单描述错误", data={}}))
end

local resp = {
    order_no=order.order_no,
    payment=order.payment,
    description=order.description,
    created_at=order.created_at
}

mgo:set_keepalive(10000, 100)
ngx.say(cjson.encode({errcode=0, errmsg="", data={order=resp}}))