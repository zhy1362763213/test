local cjson     = require "cjson"
local string    = require "string"
local table_new = require "table.new"
local table     = require "table"
local waf       = require "waf"

require "functions"

local _M={}

local function say_json(errcode,errmsg)
    ngx.header['Content-Type'] = 'application/json; charset=utf-8'
    ngx.status = ngx.HTTP_FORBIDDEN
    ngx.say(cjson.encode({errcode=errcode,errmsg=errmsg}))
    ngx.exit(ngx.status)
end

function _M.access(flag)
    if not flag then
        return
    end

    local content_length=tonumber(ngx.req.get_headers()['content-length'])
    local method=ngx.req.get_method()
    local ngxmatch=ngx.re.match

    if ngx.var.http_Acunetix_Aspect then
        ngx.exit(444)
    elseif ngx.var.http_X_Scan_Memo then
        ngx.exit(444)
    elseif waf.url() then
        say_json(403,"WAF禁止访问")
    end
end


return _M
