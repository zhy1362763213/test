local skynet = require "skynet"
local cjson  = require "cjson"
local mc     = require "skynet.multicast"

local CMD = {}

--加载所有服务器
local function loadallserver()

end

function CMD.getserver()
end

skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        local f = assert(CMD[command])
        skynet.retpack(f(...))
    end)
end)


skynet.info_func(function()
    local mqlen = skynet.stat("mqlen")
    local message = skynet.stat("message")
    local cpu = skynet.stat("cpu")
    return {
        mqlen = mqlen,
        message = message,
        cpu = cpu,
    }
end)

