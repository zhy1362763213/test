local skynet = require 'skynet'
local cjson  = require 'cjson'
local httpc  = require("http.httpc")
local settings = require 'settings'
local crypto = require "crypto"
local crypt = require "skynet.crypt"
local b64encode = crypt.base64encode
local b64decode = crypt.base64decode


local M = {}

local header = {
    ["content-type"] = "application/json"
}

function M.wx_auth(openid, access_token)
    local respheader = {}
    local url = string.format("/sns/userinfo?access_token=%s&openid=%s&lang=zh_CN",access_token, openid)
    local _, body = httpc.request("GET", "https://api.weixin.qq.com", url, respheader)
    local ok, resp = pcall(cjson.decode, body)
    if not ok then
        error("wx_auth decode error")
    end
    return resp
end


function M.code2Session(app, code)
    local appid = settings.mini_conf.appid
    local secret = settings.mini_conf.secret
    local respheader = {}
    local url = string.format("/sns/jscode2session?appid=%s&secret=%s&js_code=%s&grant_type=authorization_code", appid, secret, code)
    local _, body = httpc.request("GET", "https://api.weixin.qq.com", url, respheader)
    local ok, resp = pcall(cjson.decode, body)
    if not ok then
        error("code2Session decode error")
    end
    return resp
end

function M.decryptData(encryptedData,iv,sessionKey)

    if #sessionKey ~= 24 then
        error("sessionKey len err")
    end

    local aesKey = base64decode(sessionKey)
    if #iv ~= 24 then
        error("iv len err")
    end

    local aesIV = base64decode(iv)
    local aesCipher = base64decode(encryptedData)
    local result = crypto.decrypt("aes128", aesCipher, aesKey, aesIV)

    local ok, dataObj = pcall(cjson.decode, result)
    if not ok then
        error("result decode err")
    end

    if dataObj.watermark.appid ~= settings.mini_conf.appid then
       error("appid err")
    end

    return dataObj
end


function M.cal_node_name(serverId)
    --return "gameserver"..math.floor(serverId)
    return "gameserver1"
end

function M.cal_protocol(protocol)
    if protocol and protocol == 'ws' then
        return 'ws'
    end
    return 'tcp'
end

function M.get_server(serverId, protocol)
    local node_name = M.cal_node_name(serverId)
    local lobbyInfo = settings.nodes[tostring(node_name)]
    local port = lobbyInfo[tostring('gate_port_' .. M.cal_protocol(protocol))]
    return node_name, lobbyInfo.host, port
end

function M.get_server_cfg(serverId, protocol)
    local node_name = M.cal_node_name(serverId)
    local lobbyInfo = settings.nodes[tostring(node_name)]
    local port = lobbyInfo[tostring('gate_port_' .. M.cal_protocol(protocol))]
    return node_name, lobbyInfo.host, port
end

function M.get_online_count()
    return skynet.call(".sessionmgr", "lua", "get_online_count")
end

function M.get_user_online(uid)
    return skynet.call(".sessionmgr", "lua", "get_user_online", uid)
end

function M.add_user_online(uid, user)
    return skynet.call(".sessionmgr", "lua", "add_user_online", uid, user)
end

function M.del_user_online(uid)
    return skynet.call(".sessionmgr", "lua", "del_user_online", uid)
end


return M