local skynet = require "skynet"
local cluster= require "skynet.cluster"
local cjson  = require "cjson"

skynet.start(function()

    -- skynet.error("Unknown OS: " , tostring(ffi.os))

    skynet.error("Login Server start")
    local settings = require "settings"
    local cfg = settings.login_conf
    skynet.error("login config = ", cjson.encode(cfg))

    skynet.newservice("debug_console", cfg.console_port)
    skynet.uniqueservice("dbproxy", cfg.node_name)

    skynet.uniqueservice("loginw")

    skynet.uniqueservice("redisd")

    skynet.uniqueservice("sessionmgr")

	cluster.open(cfg.node_name)

	skynet.exit()
end)
