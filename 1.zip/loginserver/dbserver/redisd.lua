local skynet    = require "skynet"
local cjson     = require "cjson"
local redis     = require 'skynet.db.redis'
local settings  = require "settings"
local keysutils = require "keysutils"
local rediscli

require "skynet.manager"


local CMD = {}

function CMD.genid()
    local min = 100001
    local max= 999999
    local script = [[
        local k = ARGV[1]
        local r = ARGV[2]
        local v = redis.call('exists',k)
        if v==1 then
            return nil
        end
        redis.call('set',k,r)
        return r
    ]]
    while true do
        local r = math.random(min, max)
        local k = string.format("%s-useruid-%d",settings.appname, r)
        local a = rediscli:eval(script,2,"k","r",k,r)
        if a then
            return r
        end
    end
end

function CMD.getserverid(openid)
    local k = keysutils.user_choose_server_key(settings.appname, openid)
    local serverid = rediscli:get(k) or 0
    return serverid
end

function CMD.setserverid(openid, serverid)
    local k = keysutils.user_choose_server_key(settings.appname, openid)
    return rediscli:set(k, serverid)
end

function CMD.addinvitenum(uid)
    local k = keysutils.user_invite_num_key(settings.appname, uid)
    local n = rediscli:incr(k)
end

skynet.start(function()
    skynet.dispatch("lua", function(_, _, command, ...)
        skynet.error("redis despatch command = ", command)
        local f = assert(CMD[command])
        skynet.ret(skynet.pack(f(...)))
    end)

    rediscli = redis.connect(settings.db_cnf.loginserver.redisdb_cnf)

    if not rediscli then
        error(" rediscli 连接失败")
    end

    skynet.fork(function()
        while true do
            if true then
                rediscli:ping()
                skynet.sleep(1000)
            end
        end
    end)
    collectgarbage()

    skynet.register ".redisd"
end)
