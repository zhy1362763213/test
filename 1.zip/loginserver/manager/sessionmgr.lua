local skynet = require "skynet"
local cjson = require "cjson"
local datacenter = require "skynet.datacenter"
require "skynet.manager"

local CMD   = {}

local user_online = {}  -- 记录玩家所登录的服务器

function CMD.get_online_count()
    local c = 0
    for _,v in pairs(user_online) do
        c = c + 1
    end
    return c
end

function CMD.get_user_online(uid)
    return user_online[uid]
end

function CMD.del_user_online(uid)
    user_online[uid] = nil
    return "ok"
end

function CMD.add_user_online(uid, user)
    user_online[uid] = user
    return "ok"
end

skynet.start(function()
    skynet.dispatch("lua", function(_,_, command, ...)
        -- skynet.trace()
        local f = CMD[command]
        skynet.ret(skynet.pack(f(...)))
    end)

    skynet.register('.' .. SERVICE_NAME)
end)
