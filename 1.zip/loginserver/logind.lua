local login = require "snax.loginserver"
local crypt = require "skynet.crypt"
local skynet = require "skynet"
local cluster = require "skynet.cluster"
local httpc      = require("http.httpc")
local cjson      = require "cjson"
local settings = require "settings"

require "functions"
local server = {
	host = "0.0.0.0",
	port = settings.login_conf.login_port_tcp,
	multilogin = false,	-- disallow multilogin
	name = "login_master",
    instance = settings.login_conf.login_slave_count,
}

local server_list = {}
local user_online = {}
local user_login = {}

--保存一个服务器上的所有的房间得个数
local server_room_map={}
local cluster_info = {}
local cluster_proxy = {}


function server.auth_handler(token)
	-- the token is base64(user)@base64(server):base64(password)
	local user, server, password = token:match("([^@]+)@([^:]+):(.+)")
	user = crypt.base64decode(user)
	server = crypt.base64decode(server)
	password = crypt.base64decode(password)
	return server, user
end

function server.login_handler(server, uid, secret)
	print(string.format("%s@%s is login, secret is %s", uid, server, crypt.hexencode(secret)))

	local server = findServer()
	skynet.error("server=",server)
	assert(server_list[server], "Unknown server")

	-- only one can login, because disallow multilogin
	local last = user_online[uid]
	if last then
        skynet.error("only one can login, because disallow multilogin uid =", uid, ' subid = ', last.subid)
		local proxy = cluster_proxy[last.server]
		skynet.call(proxy, "lua", "kick", uid, last.subid)
	end
	if user_online[uid] then
		error(string.format("user %s is already online", uid))
	end

	local proxy = cluster_proxy[server]
	skynet.error("proxy=",proxy)
	local subid = tostring(skynet.call(proxy, "lua", "login", uid, secret))
	user_online[uid] = { subid = subid , server = server}
    server_room_map[server] = server_room_map[server] + 1
	return string.format("%s:%s", server, tostring(subid))
end

local CMD = {}

function CMD.register_gate(server,cluster_config)
	skynet.error("register_gate=",server,cluster_config,skynet.self())
    server_room_map[server] = 0

	server_list[server] = server

	skynet.error("cluster_config=",cluster_config)
	cluster_info[server] = cluster_config
	cluster.reload(cluster_info)
	local s = string.format("%s@watchdog",server)
	local proxy = cluster.proxy(s)

	cluster_proxy[server] = proxy

    return "ok"
end


function CMD.logout(uid, subid)
	local u = user_online[uid]
	if u then
        local server = u.server
        server_room_map[server] = math.max(0, server_room_map[server] - 1)
		print(string.format("%s@%s is logout", uid, u.server))
		user_online[uid] = nil
	end
end


function server.command_handler(command, ...)
	local f = assert(CMD[command])
	return f(...)
end

login(server)
